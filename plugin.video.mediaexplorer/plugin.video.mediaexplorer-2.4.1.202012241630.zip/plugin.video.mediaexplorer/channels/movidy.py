# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://movidy.co/'

LNG = Languages({
    Languages.es: ['1'],
    Languages.la: ['2'],
    Languages.sub_es: ['3'],
    Languages.en: ['4']
})

QLT = Qualities({
    Qualities.hd_full: ['1080p'],
    Qualities.hd: ['720p'],
    Qualities.sd: ['480p', '360p'],

    Qualities.rip: ['rip', 'hdrip', 'hdrvrip'],
    Qualities.scr: ['screener']
})


def mainlist(item):
    logger.trace()
    itemlist = list()

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        banner='banner/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    new_item = item.clone(
        type='label',
        label="Series",
        category='tvshow',
        banner='banner/tvshow.png',
        icon='icon/tvshow.png',
        poster='poster/tvshow.png',
    )
    itemlist.append(new_item)
    itemlist.extend(menuseries(new_item))

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label='Novedades',
        action='content',
        content_type='movies',
        url=HOST + 'peliculas',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Estrenos',
        action='content',
        content_type='movies',
        url=HOST + 'peliculas/estrenos',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Actualizadas',
        action='content',
        content_type='movies',
        url=HOST + 'actualizado/peliculas',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Recomendadas',
        action='content',
        content_type='movies',
        url=HOST + 'peliculas/mejor-valoradas',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Buscar',
        action='search',
        query=True,
        content_type='movies',
        type="search",
        group=True
    ))

    return itemlist


def menuseries(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label='Nuevos episodios',
        action='content',
        content_type='episodes',
        url=HOST + 'series/novedades',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Nuevas series',
        action='content',
        content_type='tvshows',
        url=HOST + 'series',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Series actualizadas',
        action='content',
        content_type='tvshows',
        url=HOST + 'actualizado/series',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Recomendadas',
        action='content',
        content_type='tvshows',
        url=HOST + 'series/mejor-valoradas',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Buscar',
        action='search',
        query=True,
        content_type='tvshows',
        type="search",
        group=True
    ))

    return itemlist


def content(item):
    logger.trace()
    itemlist = list()

    if not item.url.startswith(HOST):
        item.url = HOST + item.url

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    if item.query:
        patron = r'<article class="Cards\s*(?:carPerf|)"><a href="(?P<url>[^"]+)".*?<b class="tng2">(?P<aux>[^<]+).*?' \
                 r'data-echo="(?P<poster>[^"]+).*?title="(?P<title>[^"]+)"></div>'
    else:
        patron = r'<article class="Cards\s*(?:carPerf|)"><a href="(?P<url>[^"]+)".*?data-echo="(?P<poster>[^"]+).*?' \
                 r'title="(?P<title>[^"]+)"></div>'

        if item.content_type == 'episodes':
            patron += r'<div class="CInfo noHide2"><h2><b>(?P<aux>[^<]+)'
        else:
            patron += r'<div class="CInfo noHidetho"><p>(?P<aux>\d+)'

    for result in re.compile(patron, re.DOTALL).finditer(data):
        if item.query and ((item.category == 'movie' and result.group('aux').lower() != 'pelicula') or (
                item.category == 'tvshow' and result.group('aux').lower() != 'serie')):
            continue

        new_item = item.clone(
            title=result.group('title'),
            poster=result.group('poster'),
            url=result.group('url')
        )

        if item.content_type == 'movies':
            new_item.year = result.group('aux') if not item.query else None
            new_item.action = 'findvideos'
            new_item.content_type = 'servers'
            new_item.type = 'movie'

        elif item.content_type == 'tvshows':
            new_item.year = result.group('aux') if not item.query else None
            new_item.action = 'seasons'
            new_item.content_type = 'seasons'
            new_item.type = 'tvshow'

        elif item.content_type == 'episodes':
            new_item.action = 'findvideos'
            new_item.content_type = 'servers'
            new_item.type = 'episode'
            num_season, num_episode = scrapertools.get_season_and_episode(result.group('aux').replace(' - ', 'x'))
            new_item.season = num_season
            new_item.episode = num_episode

        itemlist.append(new_item)

    if itemlist:
        next_url = scrapertools.find_single_match(data, '<a href="([^"]+)" up-target="body">Pagina siguiente')
        if next_url:
            itemlist.append(item.clone(url=next_url, type='next', action='content'))

    return itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    for season in scrapertools.find_multiple_matches(data, r'<div class="season temporada-(\d+)'):
        itemlist.append(item.clone(
            season=int(season),
            title="Temporada %s" % season,
            tvshowtitle=item.title,
            action="episodes",
            type='season',
            content_type='episodes'
        ))

    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron = '<li ><a href="([^"]+)".*?data-echo="([^"]*)"></div><h2>([^<]+)</h2><div class="startEp"><span>([^<]+)'
    for url, thumb, title, season_and_episode in scrapertools.find_multiple_matches(data, patron):
        num_season, num_episode = scrapertools.get_season_and_episode(season_and_episode.replace(' - ', 'x'))
        if item.season == num_season:
            itemlist.append(item.clone(
                title=title,
                url=url,
                thumb=thumb.replace('/w154/', '/original/'),
                action="findvideos",
                episode=num_episode,
                type='episode',
                content_type='servers'
            ))

    return itemlist


def search(item):
    logger.trace()
    item.url = HOST + 'search?go=' + item.query.replace(" ", "+")

    return content(item)


def findvideos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    # enlaces usuarios aqui
    patron = r'<li><a href="([^"]+)" rel="nofollow noopener" target="_blank">.*?<span><[^>]+>([^<]+)<b>([^<]+).*?' \
             r'src=".*?(\d+)\.png"'

    for url, server, qlt, lang in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            type='server',
            action='play',
            url=url,
            server=server.split('.', 1)[0],
            lang=LNG.get(lang),
            quality=QLT.get(qlt)
        ))

    # Enlaces OFICIAL
    oficiales = []

    if item.category == 'movie':
        movie_id = scrapertools.find_single_match(data, r'<div id="movidyMain".*?secid="([^"]+)">')
    else:
        movie_id = scrapertools.find_single_match(data, r'<iframe src="https://wmovies.co/ifr/([^"]+)')

    data = check_cpt({'id': movie_id, 'type': 1}, HOST)
    patron = r'<div class="[^"]*OD_(\d)[^"]*">(.*?)</div>'

    for idioma, videos in scrapertools.find_multiple_matches(data, patron):

        patron = r'<li.*?"go_to_player\(\'([^\']+)\', (\d)(?:, (\d))?\);".*?' \
                 r'<img src=".*?/([^./]+).png">.*?<span>([^<]+)</span>'

        for url, _type, load, logo, server in scrapertools.find_multiple_matches(videos, patron):
            it = item.clone(
                    type='server',
                    action='play',
                    url=url,
                    lang=LNG.get(idioma),
                    movidy_id=movie_id,
                    movidy_type=_type,
                    label_extra={'sublabel': ' [%s]', 'value': 'OFICIAL', 'color':"color4"}
                )

            if _type == '1':
                if logo == 'dKVrnLI':
                    logo = 'googledrive'
                it.server = logo
            elif _type == '2':
                it.server = server.lower()
            else:
                it.server = 'movidy'
                it.servername = 'Movidy'

            oficiales.append(it)

    return servertools.get_servers_from_id(oficiales + itemlist)


def check_cpt(post, referer):
    data = httptools.downloadpage(
        HOST + 'cpt', #HOST + 'cpt/check_cpt',
        post=post,
        headers={
            'Referer': referer
        }
    ).data

    json_data = jsontools.load_json(data)
    if json_data["status"] == 404:
        post["cpt"] = platformtools.show_recaptcha(HOST, "6Lesp90UAAAAAMTD9rPVwdfSGB8pJyybx8kfBgiZ", "peticiones")
        data = httptools.downloadpage(
            HOST + 'cpt', #HOST + 'cpt/send_cpt',
            post=post,
            headers={
                'Referer': referer
            }
        ).data

    return jsontools.load_json(data)['data']


def play(item):
    logger.trace()

    if item.movidy_type == '2': # Procesador!
        check_cpt({'id': item.movidy_id, 'type': 2}, HOST)
        data = jsontools.load_json(httptools.downloadpage(
            HOST + item.url,
            headers={'Referer': HOST}
        ).data)

        url = 'get-player/' + data['data']
        item.url = httptools.downloadpage(
            HOST + url,
            headers={'Referer': HOST},
            follow_redirects=False
        ).headers.get('location')

        servertools.normalize_url(item)
        return item

    elif item.movidy_type == '1':
        check_cpt({'id': item.movidy_id, 'type': 2}, HOST)
        item.url = httptools.downloadpage(
            HOST + item.url,
            headers={'Referer': HOST},
            follow_redirects=False
        ).headers.get('location')
        servertools.normalize_url(item)
        return item

    elif item.movidy_type == '3': # Recolector
        check_cpt({'id': item.movidy_id, 'type': 2}, HOST)
        data = jsontools.load_json(httptools.downloadpage(
            HOST + item.url,
            headers={'Referer': HOST}
        ).data)
        data = httptools.downloadpage(
            HOST + 'get-player/' + data["data"]["data"],
            headers={'Referer': HOST}
        ).data
        sources = jsontools.load_json(
            scrapertools.find_single_match(data, r'"sources": (\[.*?\])').replace(',]', ']'))
        itemlist = list()
        for source in sources:
            video = Video(url=source['file'])
            if source.get('label'):
                video.res= '%sp' % source.get('label')
            itemlist.append(video)

        item.video_urls = itemlist
        return item

    else:
        headers = {'Referer': item.referer}
        data = httptools.downloadpage(item.url, headers=headers).data

        sitekey = scrapertools.find_single_match(data, 'data-sitekey="([^"]+)')
        if sitekey:
            response = platformtools.show_recaptcha(siteurl=item.url, sitekey=sitekey)

            post = {'g-recaptcha-response': response, 'submit': 'Ir al enlace'}
            resp = httptools.downloadpage(item.url, post=post, follow_redirects=False)
            item.url = resp.headers.get('location')
        else:
            item.url = scrapertools.find_single_match(data,'<a class="Go_V2" href="([^"]+)')

        if item.url:
            servertools.normalize_url(item)

        return item
