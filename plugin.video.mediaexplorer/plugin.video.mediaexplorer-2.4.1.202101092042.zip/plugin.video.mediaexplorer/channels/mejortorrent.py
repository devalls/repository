# -*- coding: utf-8 -*-
from core.libs import *
import unicodedata

QLT = Qualities({
    Qualities.rip: ['dvdrip', 'rhdtv', 'hdrip'],
    Qualities.hd_full: ['1080p', 'fullbluray'],
    Qualities.uhd: ['4k hdr', '4k'],
    Qualities.hd: ['hdtv', '720p', 'bluray-720p', 'microhd-720p'],
    Qualities.scr: ['dvdscr', 'br-screener', 'br screener', 'dvdscreener', 'brscreener'],
    Qualities.sd: ['sd'],
    Qualities.m3d: ['3d']
})

HOST = 'https://www.mejortorrents.net'


def mainlist(item):
    logger.trace()
    itemlist = list()

    # SubMenu Peliculas
    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        thumb='thumb/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    # SubMenu Series
    new_item = item.clone(
        type='label',
        label="Series",
        category='tvshow',
        thumb='thumb/tvshow.png',
        icon='icon/tvshow.png',
        poster='poster/tvshow.png',
    )
    itemlist.append(new_item)
    itemlist.extend(menuseries(new_item))

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label="Películas HD",
        action="movies_list",
        content_type='movies',
        type="item",
        group=True,
        url=HOST + '/torrents-de-peliculas-hd-alta-definicion.html'
    ))

    itemlist.append(item.clone(
        label="Películas",
        action="movies_list",
        content_type='movies',
        type="item",
        group=True,
        url=HOST + '/torrents-de-peliculas.html'
    ))

    itemlist.append(item.clone(
        label="Novedades",
        action="novedades",
        content_type='movies',
        type="item",
        group=True,
        url=HOST + '/secciones.php?sec=ultimos_torrents'
    ))

    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        content_type='movies'
    ))

    return itemlist


def menuseries(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label="Series HD",
        action="tvshows_list",
        content_type='tvshows',
        type="item",
        group=True,
        url=HOST + '/torrents-de-series-hd-alta-definicion.html'
    ))

    itemlist.append(item.clone(
        label="Series",
        action="tvshows_list",
        content_type='tvshows',
        type="item",
        group=True,
        url=HOST + '/torrents-de-series.html'
    ))

    itemlist.append(item.clone(
        label="Nuevos episodios",
        action="novedades",
        content_type='episodes',
        type="item",
        group=True,
        url=HOST + '/secciones.php?sec=ultimos_torrents'
    ))

    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        content_type='tvshows'
    ))

    return itemlist


def novedades(item):
    logger.trace()
    itemlist = list()
    
    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
    
    if item.category == 'movie':
        mov = "SERIES" if "SERIES" in data else "JUEGOS"
        if mov == "JUEGOS" and not "JUEGOS" in data:
            mov = "<footer>"
        data = scrapertools.find_single_match(data, r"PELÍCULAS(.*?)%s" % mov)
        dif = "'>([^<]+)<"
    else:
        tvs = "JUEGOS" if "JUEGOS" in data else "<footer>"
        data = scrapertools.find_single_match(data, r"SERIES(.*?)%s" % tvs)
        dif = ">([^<]+)?<"
    
    patron = r"href='([^']+)'.*?>([^<]+).*?%s" % dif

    for url, title, qlt in scrapertools.find_multiple_matches(data, patron):
        qlt = re.sub(r"\(|\)", "", qlt.lower())
        if item.category == 'movie':
            title = title.split('-')[0].strip()
            title = re.sub(r" \(.*?\)", "", title)
            itemlist.append(item.clone(
                title=title,
                url=HOST + '/' + url,
                type='movie',
                content_type='servers',
                action='findvideos',
                quality=QLT.get(qlt) if qlt else None
            ))
        else:
            if '720p' in title or 'HDTV' in title:
                qlt = '720p'
            elif '1080p' in title:
                qlt = '1080p'
            else:
                qlt = None
            
            multi = scrapertools.find_single_match(title, r": (\d+[x|X]\d+.*?\d+[x|X]\d+)")
            season, episode = scrapertools.get_season_and_episode(title)
            title = title.split('-')[0].strip()
            title = re.sub(r" \(.*?\)", "", title)
            con = '[x|X]0' if len(str(episode)) == 1 else '[x|X]'

            itemlist.append(item.clone(
                tvshowtitle=title,
                url=HOST + '/' + url,
                label=title,
                type='episode',
                episode=int(episode),
                season=int(season),
                cat='new',
                cap=str(season) + con + str(episode),
                label_extra = {"sublabel": " (" + multi + ")",
                           "color": "yellow",
                           "value": "True"} if multi else None,
                content_type='servers',
                action='episodes',
                quality=QLT.get(qlt) if qlt else None
            ))

    return itemlist


def search(item):
    logger.trace()

    if item.tvl == "tvl":
        item.url = item.url
    else:
        item.url = HOST + '/secciones.php?sec=buscador&valor=%s' % item.query.replace(' ', '+')
    data = httptools.downloadpage(item.url).data
    logger.debug(data)
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
    data = scrapertools.find_single_match(data, r"Se han encontrado <b>(.*?)<td id='main_td_right'>")
    # data = unicode(data, "iso-8859-1", errors="replace").encode("utf-8")

    patron = r"<a href='([^']+)[^>]+>(.*?)</a>(.*?)</td></tr>"

    listado = []
    for url, title, quality in scrapertools.find_multiple_matches(data, patron):
        title = re.sub(r"\[.*?\]|\(.*?\)", "", title)
        if item.category == 'movie' and 'Película' in quality:
            # Simplificar quality
            quality = scrapertools.find_single_match(re.sub(r'<.*?>|Película|Serie|-', '', quality), '\w+').lower()
            if '3d' in quality:
                quality = '3d'
            elif '1080p' in quality:
                quality = '1080p'
            elif '720p' in quality:
                quality = '720p'
            elif "4K" in quality:
                quality = '4k'

            title = re.sub(r'<.*?>', '', title)
            title += '#|#' + quality
            listado.append((url, title))

        if item.category == 'tvshow' and 'Serie' in quality:
            title = re.sub(r'<.*?>', '', title)
            listado.append((url, title))

    if item.category == 'movie':
        return filtrar_peliculas(item, listado)
    else:
        return filtrar_series(item, listado)


def movies_list(item):
    logger.trace()
    itemlist = list()
    
    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    #patron = r"<br>\s+<a href='([^']+)'>([^<]+)</"
    patron = r'href="([^"]+)">([^<]+)</'
    
    for url, title in scrapertools.find_multiple_matches(data, patron):
        title = title.split('-')[0].strip()
        qlt = "4k" if "4K" in title else "hdtv" if item.label == "Películas HD" else None
        title = re.sub(r" \(.*?\).$| \(4K\)", "", title)
        itemlist.append(item.clone(
            title=title,
            url=HOST + url,
            type='movie',
            content_type='servers',
            action='findvideos',
            quality=QLT.get(qlt) if qlt else None
        ))

    next_page = scrapertools.find_single_match(data, "href='([^']+)'.class='paginar'>.Siguiente")
    if next_page:
        itemlist.append(item.clone(type='next', url=HOST + next_page))

    return itemlist


'''def tvshows_list(item):
    logger.trace()

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
    
    patron = r'href="([^"]+)">([^<]+)</'

    listado = []
    for url, title in scrapertools.find_multiple_matches(data, patron):
        title = re.sub(r"\[.*?\]|\(.*?\)", "", title)
        title = re.sub(r'<.*?>', '', title)
        listado.append((url, title))

    return filtrar_series(item, listado)'''


def tvshows_list(item):
    logger.trace()
    itemlist = list()
    
    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron = r'href="([^"]+)">([^<]+)</'
    auxlist = set()
    for url, title in scrapertools.find_multiple_matches(data, patron):
        if '720p' in title or 'HDTV' in title:
            qlt = '720p'
        elif '1080p' in title:
            qlt = '1080p'
        else:
            qlt = None
            
        title = title.split('-')[0].strip()
        title = re.sub(r" \(.*?\)", "", title)
        
        if not title in auxlist:
            auxlist.add(title)
            itemlist.append(item.clone(
                tvshowtitle=title,
                #url=HOST + url,
                url=HOST + '/secciones.php?sec=buscador&valor=%s' % title.replace(' ', '+'),
                title=title,
                tvl="tvl",
                type='tvshow',
                content_type='tvshows',
                action='search',
                quality=QLT.get(qlt) if qlt else None
            ))

    next_page = scrapertools.find_single_match(data, "href='([^']+)'.class='paginar'>.Siguiente")
    if next_page:
        itemlist.append(item.clone(type='next', url=HOST + next_page))

    return itemlist


def filtrar_series(item, series):
    logger.trace()
    itemlist = list()
    listado = {}
    for url, title in series:
        try:
            title = title.split('-')
            tvshowtitle = re.sub(r'\s?\.?\s?$', '', re.sub(r'[\(|\[].*[\)|\]]', '', title[0]))
            temporada = re.sub(r'\s?\.?\s?$', '', re.sub(r'[\(|\[].*[\)|\]]', '', title[1]))
            if 'miniserie' in temporada.lower():
                temporada = 1
            else:
                temporada = int(scrapertools.find_single_match(temporada, r'(\d+)'))
        except:
            continue

        listado_temporadas = listado.get(tvshowtitle, {})
        listado_urls = listado_temporadas.get(temporada, [])
        listado_urls.append(HOST + url)
        listado_temporadas[temporada] = listado_urls
        listado[tvshowtitle] = listado_temporadas

    if item.ini:
        ini = item.ini
        del item.ini
    else:
        ini = 0

    for k in sorted(listado.keys())[ini:ini + 40]:
        itemlist.append(item.clone(
            tvshowtitle=k,
            title=k,
            temporadas=listado[k],
            type='tvshow',
            content_type='seasons',
            action='seasons'
        ))

    # paginacion
    if ini + 40 < len(listado):
        itemlist.append(item.clone(
            ini=ini + 40,
            type='next'))

    return itemlist


def normalizar(s):
    """
    Devuelve la cadena s en minusculas y sin marcas diacríticas como tildes, dieresis, etc...
    :param s: str o unicode a normalizar
    :return: cadena sin marcas diacriticas
    """

    s = six.ensure_text(s.lower())
    return ''.join((c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn'))


def filtrar_peliculas(item, peliculas):
    logger.trace()
    itemlist = list()
    listado = dict()
    i = -1

    for url, title in peliculas:
        try:
            title, quality = title.split('#|#')
        except:
            quality = ''

        title = re.sub(r'\s?\.?\s?$', '', title)
        key = normalizar(title)
        if key in listado:
            orden, title_old, listado_urls, listado_calidades = listado[key]
        else:
            i += 1
            orden, title_old, listado_urls, listado_calidades = (i, '', [], [])

        listado_urls.append(HOST + url)
        listado_calidades.append(quality)
        listado[key] = (orden, title, listado_urls, listado_calidades)

    ini = item.ini if item.ini else 0

    for orden, title, listado_urls, listado_calidades in sorted(listado.values(), key=lambda x: x[0])[ini:ini + 40]:
        quality = list()
        for q in listado_calidades:
            if QLT.get(q) not in quality:
                quality.append(QLT.get(q))

        itemlist.append(item.clone(
            title=title,
            url=listado_urls,
            type='movie',
            content_type='servers',
            action='findvideos',
            quality=quality if quality else None
        ))

    # paginacion
    if ini + 40 < len(listado):
        itemlist.append(item.clone(
            ini=ini + 40,
            type='next'))

    return itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    for s in sorted(item.temporadas.keys()):
        itemlist.append(item.clone(
            action="episodes",
            season=s,
            type='season',
            url=item.temporadas[s],
            content_type='episodes'
        ))

    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()
    listado = {}

    if not isinstance(item.url, list):
        item.url = [item.url]

    for url in item.url:
        data = httptools.downloadpage(url).data
        # data = unicode(data, "iso-8859-1", errors="replace").encode("utf-8")
        data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

        if item.cat == 'new':
            patron = r"<a href='(/serie-episodio-descargar-torrent[^']+)'>(%s)" % item.cap
        else:
            patron = r"<a href='(/serie-episodio-descargar-torrent[^']+)'>([^<]+)"
        for url, episode in scrapertools.find_multiple_matches(data, patron):
            num_episode = scrapertools.find_multiple_matches(episode, r"\d+[x|X](\d+)")
            if len(num_episode) == 1:
                n = int(num_episode[0])
                listado_urls = listado.get(n, [])
                listado_urls.append(HOST + url)
                listado[n] = listado_urls

            else:
                if 'al' in episode or 'y' in episode and len(num_episode) == 2:
                    multi_episodes = range(int(num_episode[0]), int(num_episode[1]) + 1)
                else:
                    multi_episodes = [int(n) for n in num_episode]
                    multi_episodes.sort()

                for n in multi_episodes:
                    listado_urls = listado.get(n, [])
                    listado_urls.append(HOST + url)
                    listado[n] = listado_urls

    if listado:
        if item.ini:
            ini = item.ini
            del item.ini
        else:
            ini = 0

        for k in sorted(listado.keys())[ini:ini + 40]:
            if item.cat != 'new':
                itemlist.append(item.clone(
                    url=listado[k],
                    episode=k,
                    action="findvideos",
                    label_extra=item.label_extra if item.label_extra else None,
                    type='episode',
                    content_type='servers'
                ))
            else:
                for url in listado[k]:
                    data = httptools.downloadpage(url).data
                    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;|<br>", "", data)
                    patron = r"<img border=.*?src='([^']+).*?<b>Formato:?</b>:?\s*([^<]+).*?<b>Torrent.*?href='([^']+)"
                    poster, quality, url = scrapertools.find_single_match(data, patron)
                    
                    url_t = scrapertools.find_single_match(
                    httptools.downloadpage(HOST + "/" + url).data, r"name: '([^']+)")
        
                    itemlist.append(item.clone(
                        url=HOST + "/tor/series/" + url_t,
                        quality=item.quality,
                        action="play",
                        type='server',
                        server='torrent'
                    ))

        # paginacion
        if ini + 40 < len(listado):
            itemlist.append(item.clone(
                ini=ini + 40,
                type='next'))

    return itemlist if item.cat != 'new' else servertools.get_servers_from_id(itemlist)


def findvideos(item):
    logger.trace()
    itemlist = list()

    if not isinstance(item.url, list):
        item.url = [item.url]

    for url in item.url:
        data = httptools.downloadpage(url).data
        # data = unicode(data, "iso-8859-1", errors="replace").encode("utf-8")

        data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;|<br>", "", data)
        patron = r"<img border=.*?src='([^']+).*?<b>Formato:?</b>:?\s*([^<]+).*?<b>Torrent.*?href='([^']+)"
        poster, quality, url = scrapertools.find_single_match(data, patron)

        # Simplificar quality
        quality = quality.replace('-', ' ').lower()
        if scrapertools.find_single_match(quality + ' ', ' 3d '):
            quality = '3d'
        elif scrapertools.find_single_match(quality + ' ', ' 1080p? '):
            quality = '1080p'
        elif scrapertools.find_single_match(quality + ' ', ' 720p? '):
            quality = '720p'
        else:
            quality = re.sub(chr(194), " ", quality)
            quality = re.sub(chr(160), " ", quality).strip()


        url_t = scrapertools.find_single_match(
            httptools.downloadpage(HOST + "/" + url).data,
            r"name: '([^']+)")
        tag = "/tor/peliculas/" if item.type == 'movie' else "/tor/series/"

        new_item = item.clone(
            action="play",
            url=HOST + tag + url_t,
            quality=QLT.get(quality.strip()),
            poster=item.poster if item.poster.startswith(HOST) else poster.replace(' ', '%20'),
            type='server',
            server='torrent'
        )

        size = scrapertools.find_single_match(data, r'Tamaño:</b>(.*?)<').replace(',', '.')
        if not '.' in size:
            size=None
        if size:
            n = float(scrapertools.find_single_match(size, '(\d[.\d]*)')) * 1024
            new_item.size = n * 1024 if 'gb' in size.lower() else n

        itemlist.append(new_item)

    return servertools.get_servers_from_id(itemlist)
