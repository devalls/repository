# -*- coding: utf-8 -*-
from core.libs import *
import unicodedata

LNG = Languages({
    Languages.es: ['es']
})

QLT = Qualities({
    Qualities.hd_full: ['fullhd', 'microhd'],
    Qualities.uhd: ['cuatrok'],
    Qualities.m3d: ['tresd']
})


magnet = 'magnet:?xt=urn:btih:'


def mainlist(item):
    logger.trace()
    itemlist = list()

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        thumb='thumb/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label="Cine destacado",
        action="selection",
        content_type='movies',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label="Cine de culto",
        action="selection",
        content_type='movies',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label="Listado aleatorio",
        action="movies",
        content_type='movies',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label="Listado alfabético",
        action="movies",
        content_type='movies',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label="Sagas",
        action="sagas",
        content_type='movies',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        content_type='movies'
    ))

    return itemlist


@LimitResults
def movies(item):
    logger.trace()
    itemlist = list()

    alea = "LA" if item.label == "Listado aleatorio" else "NO"
    
    url = 'https://raw.githubusercontent.com/darkozma/tacones/main/nuevo'
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<microhd>([^<]+)</.*?<fullhd>([^<]+)</.*?<tresd>([^<]+)<' \
             r'/.*?<cuatrok>([^<]+)</.*?<thumbnail>([^<]+)</.*?<fanart>([^<]+)</.*?<date>([^<]+)<' \
             r'/.*?<info>([^<]+)</'
    
    for tit, cal1, cal2, cal3, cal4, poster, fanart, year, plot in scrapertools.find_multiple_matches(data, patron):
        title = normalizar(tit)
        cals = set()
        if cal1 != 'NA':
                cals.add(QLT.get('microhd'))
        if cal2 != 'NA':
                cals.add(QLT.get('fullhd'))
        if cal3 != 'NA':
                cals.add(QLT.get('tresd'))
        if cal4 != 'NA':
                cals.add(QLT.get('cuatrok'))
        
        if alea == "LA":
                item.alea = "LA"

        itemlist.append(item.clone(
                title=title,
                type='movie',
                lab=tit,
                poster=poster,
                fanart=fanart,
                plot=plot,
                lang=LNG.get('es'),
                year=year,
                action='findvideos',
                quality=list(cals)
        ))

    return sorted(itemlist) if item.alea == "LA" else itemlist


def normalizar(t):

    t = t.title()
    
    t = re.sub(r"ÑA", "ña", t)
    t = re.sub(r"ÑE", "ñe", t)
    t = re.sub(r"ÑI", "ñi", t)
    t = re.sub(r"ÑO", "ño", t)
    t = re.sub(r"ÑU", "ñu", t)

    return t


@LimitResults
def search(item):
    logger.trace()
    itemlist = list()

    url = 'https://raw.githubusercontent.com/darkozma/tacones/main/nuevo'
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<microhd>([^<]+)</.*?<fullhd>([^<]+)</.*?<tresd>([^<]+)<' \
             r'/.*?<cuatrok>([^<]+)</.*?<thumbnail>([^<]+)</.*?<fanart>([^<]+)</.*?<date>([^<]+)<' \
             r'/.*?<genre>([^<]+)</.*?<info>([^<]+)</'
    
    for tit, cal1, cal2, cal3, cal4, poster, fanart, year, genre, plot in scrapertools.find_multiple_matches(data, patron):
        title = normalizar(tit)
        cals = set()

        if item.lab == 's':
            if 'Saga' in genre:
                if item.query.lower() in title.lower():
                    if cal1 != 'NA':
                        cals.add(QLT.get('microhd'))
                    if cal2 != 'NA':
                        cals.add(QLT.get('fullhd'))
                    if cal3 != 'NA':
                        cals.add(QLT.get('tresd'))
                    if cal4 != 'NA':
                        cals.add(QLT.get('cuatrok'))

                    itemlist.append(item.clone(
                        title=title,
                        type='movie',
                        lab=tit,
                        poster=poster,
                        fanart=fanart,
                        plot=plot,
                        lang=LNG.get('es'),
                        year=year,
                        action='findvideos',
                        quality=list(cals)
                    ))

        else:
            if item.query.lower() in title.lower():
                if cal1 != 'NA':
                    cals.add(QLT.get('microhd'))
                if cal2 != 'NA':
                    cals.add(QLT.get('fullhd'))
                if cal3 != 'NA':
                    cals.add(QLT.get('tresd'))
                if cal4 != 'NA':
                    cals.add(QLT.get('cuatrok'))

                itemlist.append(item.clone(
                    title=title,
                    type='movie',
                    lab=tit,
                    poster=poster,
                    fanart=fanart,
                    plot=plot,
                    lang=LNG.get('es'),
                    year=year,
                    action='findvideos',
                    quality=list(cals)
                ))

    return itemlist


@LimitResults
def selection(item):
    logger.trace()
    itemlist = list()

    if item.label == 'Cine destacado':
        item.com = 'Estreno'
    elif item.label == 'Cine de culto':
        item.com = 'Culto'

    url = 'https://raw.githubusercontent.com/darkozma/tacones/main/nuevo'
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<microhd>([^<]+)</.*?<fullhd>([^<]+)</.*?<tresd>([^<]+)<' \
             r'/.*?<cuatrok>([^<]+)</.*?<thumbnail>([^<]+)</.*?<fanart>([^<]+)</.*?<date>([^<]+)<' \
             r'/.*?<extra>([^<]+)</.*?<info>([^<]+)</'
    
    for tit, cal1, cal2, cal3, cal4, poster, fanart, year, extra, plot in scrapertools.find_multiple_matches(data, patron):
        title = normalizar(tit)
        cals = set()
        if extra == item.com:
            if cal1 != 'NA':
                cals.add(QLT.get('microhd'))
            if cal2 != 'NA':
                cals.add(QLT.get('fullhd'))
            if cal3 != 'NA':
                cals.add(QLT.get('tresd'))
            if cal4 != 'NA':
                cals.add(QLT.get('cuatrok'))
                
            itemlist.append(item.clone(
                title=title,
                type='movie',
                lab=tit,
                poster=poster,
                fanart=fanart,
                plot=plot,
                lang=LNG.get('es'),
                year=year,
                action='findvideos',
                quality=list(cals)
            ))

    return itemlist


def sagas(item):
    logger.trace()
    itemlist = list()

    sagas = ['Alien', 'Batman', 'Bourne', 'Cincuenta sombras', 'Cube', 'Divergente',
             'El corredor del laberinto', 'El padrino', 'El señor de los anillos', 'Expediente Warren',
             'Fast and Furious', 'Feliz dia de tu muerte', 'Harry Potter', 'Ice age', 'Insidious',
             'Jack Reacher', 'James Bond', 'John Wick', 'Jurassic Park', 'La jungla de cristal',
             'La noche de las bestias', 'La profecía', 'Los mercenarios', 'Mad Max', 'Maléfica', 
             'Marvel', 'Matrix', 'Misión imposible', 'Objetivo', 'Pacific Rim', 'Padre no hay mas que uno',
             'Perdiendo...', 'Piratas del caribe', 'Psicosis', 'Rambo', 'Regreso al futuro', 
             'Resident evil', 'Riddick', 'Sherlock Holmes', 'Shrek', 'Star Trek', 'Star Wars',
             'Terminator', 'Trilogía Baztan', 'X-Men', 'Zombieland']

    for s in sagas:
        r = s
        r = re.sub(r"é", "e", r)
        r = re.sub(r"í", "i", r)
        r = re.sub(r"ó", "o", r)
        r = re.sub(r"\.\.\.", "", r)

        itemlist.append(item.clone(
            label=s,
            query=r.upper(),
            lab='s',
            action='search'
        ))

    return itemlist


def findvideos(item):
    logger.trace()
    itemlist = list()

    url = 'https://raw.githubusercontent.com/darkozma/tacones/main/nuevo'
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|\(|\)|<b>|\s{2}|&nbsp;", "", data)
    item.lab =re.sub(r"\(|\)", "", item.lab)

    patron = r'<item.*?<title>%s</.*?tle>(.*?)<thumb' % item.lab

    cal = scrapertools.find_single_match(data, patron)
    
    for calidad, url in scrapertools.find_multiple_matches(cal, r'<([^<]+)>([^<]+)</'):

        if url != 'NA':
            cal = QLT.get(calidad)
            
            itemlist.append(item.clone(
                    action="play",
                    url=magnet + url,
                    quality=cal,
                    poster=item.poster,
                    fanart=item.fanart,
                    lang=item.lang,
                    type='server',
                    server='torrent'
            ))


    return servertools.get_servers_from_id(itemlist)

