# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://pelismag.net/'
URP = 'https://pelismag.net/peliculas/'
URS = 'https://pelismag.net/serie/'

LNG = Languages({
    Languages.es: ['Castellano']
})

QLT = Qualities({
    Qualities.sd: ['480p'],
    Qualities.m3d: ['3d'],
    Qualities.hd_full: ['1080p'],
    Qualities.hd: ['720p']
})


def mainlist(item):
    logger.trace()
    itemlist = list()
    item.fanart = "fanart/pelismagnet.jpg"

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        banner='banner/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menu_movies(new_item))

    new_item = item.clone(
        type='label',
        label="Series",
        category='tvshow',
        banner='banner/tvshow.png',
        icon='icon/tvshow.png',
        poster='poster/tvshow.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menu_tvshows(new_item))

    return itemlist


def menu_movies(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="list_all",
        label="Novedades",
        url=HOST + 'api?sort_by=date_added&page=0',
        type="item",
        group=True,
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="list_all",
        label="Populares",
        url=HOST + 'api?page=0',
        type="item",
        group=True,
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="genres",
        label="Géneros",
        url=HOST + '/principal/',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        action="movie_search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        content_type='movies'
    ))

    return itemlist


def menu_tvshows(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="list_all",
        label="Novedades",
        url=HOST + 'seapi?sort_by=date_added&page=0',
        type="item",
        group=True,
        content_type='tvshows'
    ))

    itemlist.append(item.clone(
        action="list_all",
        label="Populares",
        url=HOST + 'seapi?page=0',
        type="item",
        group=True,
        content_type='tvshows'
    ))

    itemlist.append(item.clone(
        action="genres",
        label="Géneros",
        url=HOST + 'series',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        action="tv_search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        content_type='tvshows'
    ))

    return itemlist


def genres(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"F", r"f", data)
    patron = '<a href="(?P<url>[^"?#y]+)">(?P<genre>[^"<\nPS]+[^\d])<'

    for result in re.compile(patron, re.DOTALL).finditer(data):
        itemlist.append(item.clone(
            action="list_all",
            label=result.group('genre'),
            url=HOST + 'api?genre=%s&page=0' % result.group('genre') if
                item.category == 'movie' else HOST + 'seapi?genre=%s&page=0'
                % result.group('genre'),
            type='item',
            content_type='movies' if item.category == 'movie' else 'tvshows'
        ))

    return itemlist


def list_all(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    fichas_list = jsontools.load_json(data)

    for ficha in fichas_list:
        new_item = item.clone(
            action="findvideos" if item.category == 'movie' else "seasons",
            title=ficha.get('nom'),
            poster='poster/pelismagnet.png' if not ficha.get('posterurl') else
                   'http://image.tmdb.org/t/p/original'
                   + ficha.get('posterurl'),
            fanart='fanart/pelismagnet.jpg' if not ficha.get('backurl') else
                   'http://image.tmdb.org/t/p/original' + ficha.get('backurl'),
            plot='Información no disponible.' if not ficha.get('info') else
                ficha.get('info'),
            lang=LNG.get('Castellano'),
            year=ficha.get('year'),
            url=URP + str(ficha.get('id')) + '/' + ficha.get('nom') if
                item.category == 'movie' else URS + str(ficha.get('id')) + '/'
                + ficha.get('nom'),
            quality=QLT.get(ficha.get('quality')),
            type='movie' if item.category == 'movie' else 'tvshow',
            content_type='servers' if item.category == 'movie' else 'seasons'
        )
        itemlist.append(new_item)

    next_page = scrapertools.find_single_match(item.url, 'page=(\d+)')
    next_page = int(next_page) + 1
    if len(itemlist) == 50:
        itemlist.append(item.clone(
            url=re.sub(r'page=(\d+)', r'page=%s', item.url) % next_page,
            type='next'))

    return itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = 'group-[\d]+">(?P<not>Temporada\s)' \
             '(?P<season>[\d]+)(?P<qlt>[^<]+)?</label>'

    year = scrapertools.find_single_match(data, 'calendar-o"></i>.*?'
            '([\d{4}]+)</div>')
    plot = scrapertools.find_single_match(data, 'info"><h3>([^<]+)</h3>')

    auxlist = set()
    for result in re.compile(patron, re.DOTALL).finditer(data):
        if not result.group('season') in auxlist:
            auxlist.add(result.group('season'))
            itemlist.append(item.clone(
                action='episodes',
                label=result.group('not') + '%s' % int(result.group('season')),
                year=year,
                plot=plot,
                url=item.url,
                season=int(result.group('season')),
                type='season',
                content_type='episodes'
            ))

    return sorted(itemlist, key=lambda i: i.season)


def episodes(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = 'group-[\d]+">%sx(?P<episode>[\d]+)[^\w]+(?P<title>[^<]+)' \
             '</label>\s+.*?href="(?P<url>[^"]+)' % item.season

    auxlist = set()
    for result in re.compile(patron, re.DOTALL).finditer(data):
        if not result.group('episode') in auxlist:
            auxlist.add(result.group('episode'))
            itemlist.append(item.clone(
                action='findvideos',
                episode=int(result.group('episode')),
                title=result.group('title').strip(),
                type='episode',
                content_type='servers'
            ))

    return sorted(itemlist, key=lambda i: i.episode)


def findvideos(item):
    logger.trace()
    itemlist = list()

    if item.category == 'movie':
        data = httptools.downloadpage(item.url).data
        patron = 'bttns\sa\.(?P<qlt>[\d]+p?d?).*?href=(?P<url>[^"]+)\s'

        for result in re.compile(patron, re.DOTALL).finditer(data):
            itemlist.append(item.clone(
                action='play',
                lang=item.lang,
                url=result.group('url'),
                server='torrent',
                quality=QLT.get(result.group('qlt')),
                type='server'
            ))

    else:
        data = httptools.downloadpage(item.url).data
        patron = 'for="group-[\d]+">Temporada\s%s\s?\[?(?P<qlt>[\w]+)?.*?for' \
             '="sub-group-[\d]+">%sx%s[^\w]+(?P<title>[^<]+)</label>\s+.*?' \
             'href="(?P<url>[^"]+)' % (item.season, item.season, item.episode)

        for result in re.compile(patron, re.DOTALL).finditer(data):
            if not result.group('qlt'):
                item.quality = QLT.get('480p')
            elif result.group('qlt'):
                item.quality = QLT.get(result.group('qlt'))
            itemlist.append(item.clone(
                action='play',
                lang=item.lang,
                url='magnet:' + result.group('url'),
                server='torrent',
                type='server'
            ))

    return servertools.get_servers_from_id(itemlist)


def movie_search(item):
    logger.trace()
    itemlist = list()

    if not item.url:
        item.url = HOST + 'api?keywords=%s&page=0' % item.query.replace(" ",
                   "%20")

    data = httptools.downloadpage(item.url).data
    fichas_list = jsontools.load_json(data)

    for ficha in fichas_list:
        new_item = item.clone(
            action="findvideos",
            title=ficha.get('nom'),
            poster='poster/pelismagnet.png' if not ficha.get('posterurl') else
                   'http://image.tmdb.org/t/p/original'
                   + ficha.get('posterurl'),
            fanart='fanart/pelismagnet.jpg' if not ficha.get('backurl') else
                   'http://image.tmdb.org/t/p/original' + ficha.get('backurl'),
            plot='Información no disponible.' if not ficha.get('info') else
                ficha.get('info'),
            lang=LNG.get('Castellano'),
            year=ficha.get('year'),
            url=URP + str(ficha.get('id')) + '/' + ficha.get('nom'),
            type='movie',
            content_type='servers'
        )
        itemlist.append(new_item)

    next_page = scrapertools.find_single_match(item.url, 'page=(\d+)')
    next_page = int(next_page) + 1
    if len(itemlist) == 50:
        itemlist.append(item.clone(
            url=re.sub(r'page=(\d+)', r'page=%s', item.url) % next_page,
            type='next'))

    return itemlist


def tv_search(item):
    logger.trace()
    itemlist = list()

    if not item.url:
        item.url = HOST + 'seapi?keywords' \
                  '=%s&page=0' % item.query.replace(" ", "%20")

    data = httptools.downloadpage(item.url).data
    fichas_list = jsontools.load_json(data)

    for ficha in fichas_list:
        new_item = item.clone(
            action="seasons",
            title=ficha.get('nom'),
            poster='poster/pelismagnet.png' if not ficha.get('posterurl') else
                   'http://image.tmdb.org/t/p/original'
                   + ficha.get('posterurl'),
            fanart='fanart/pelismagnet.jpg' if not ficha.get('backurl') else
                   'http://image.tmdb.org/t/p/original' + ficha.get('backurl'),
            plot='Información no disponible.' if not ficha.get('info') else
                ficha.get('info'),
            lang=LNG.get('Castellano'),
            year=ficha.get('year'),
            url=URS + str(ficha.get('id')) + '/' + ficha.get('nom'),
            type='tvshow',
            content_type='seasons'
        )
        itemlist.append(new_item)

    next_page = scrapertools.find_single_match(item.url, 'page=(\d+)')
    next_page = int(next_page) + 1
    if len(itemlist) == 50:
        itemlist.append(item.clone(
            url=re.sub(r'page=(\d+)', r'page=%s', item.url) % next_page,
            type='next'))

    return itemlist


