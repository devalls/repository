# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    if "File is no longer available" in data:
        return ResolveError(0)

    m3u8 = scrapertools.find_single_match(data, r'src: "([^"]+)"')
    m3u8_data = httptools.downloadpage(m3u8).data

    for res, url in scrapertools.find_multiple_matches(m3u8_data, r'RESOLUTION=(\d+)x\d+.*?URI="([^"]+)"'):
        itemlist.append(Video(url=url, res=res))

    return itemlist
