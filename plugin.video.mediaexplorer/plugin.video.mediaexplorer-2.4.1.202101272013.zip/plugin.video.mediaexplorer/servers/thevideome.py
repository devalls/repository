# -*- coding: utf-8 -*-
from core.libs import *
from servers.vev import get_video_url as vev


def get_video_url(item):
    logger.trace()

    item.url = httptools.downloadpage(item.url, follow_redirects=False, only_headers=True).headers.get("location", "")

    return vev(item)
