# -*- coding: utf-8 -*-
from core.libs import *
from lib import jsbeautifier


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url, cookies={'sugamun': "1", 'invn': "1", 'pfm': "1"}).data

    if 'File was deleted' in data or 'File was locked by administrator' in data:
        return ResolveError(0)
    elif 'Video is processing now' in data:
        return ResolveError(1)
    elif "File is awaiting for moderation" in data:
        return ResolveError(1)
    elif 'Video encoding error' in data:
        return ResolveError(5)

    packed = scrapertools.find_single_match(data, "<script type='text/javascript'>(eval.*?)</script>")

    if packed:
        unpacked = jsbeautifier.beautify(packed)

        video_url = scrapertools.find_single_match(unpacked, 'file: "([^"]+v.mp4)"')
        # logger.debug(video_url)
        if video_url:
            itemlist.append(Video(url=video_url))

        rtmp = scrapertools.find_single_match(unpacked, 'file: "(rtmp://.*?)/(mp4:[^"]+)"')
        # logger.debug(rtmp)
        if len(rtmp) == 2:
            itemlist.append(Video(
                url=rtmp[0] + "/ playpath=" + rtmp[1] + " swfUrl=http://gamovideo.com/player61/jwplayer.flash.swf"
            ))

    return itemlist
