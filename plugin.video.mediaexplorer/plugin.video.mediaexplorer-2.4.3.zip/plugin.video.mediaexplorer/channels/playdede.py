# -*- coding: utf-8 -*-
from core.libs import *

HOST = "https://playdede.com/"


LNG = Languages({
    Languages.es: ['esp'],
    Languages.la: ['lat'],
    Languages.sub_es: ['espsub'],
    Languages.sub_en: ['engsub'],
    Languages.en: ['eng']
})

QLT = Qualities({
    Qualities.hd_full: ['hd1080'],
    Qualities.hd: ['hd720','hdtv','rhdtv'],
    Qualities.sd: ['hd320'],
    Qualities.rip: ['dvdrip', 'dvdscr', 'hdrvrip'],
    Qualities.scr: ['ts', 'cam']
})

def mainlist(item):
    logger.trace()
    itemlist = []

    if not login():
        itemlist.append(item.clone(
            action="config",
            label="Configuración",
            folder=False,
            type='setting'
        ))
    else:
        new_item = item.clone(
            type='label',
            label="Películas",
            category='movie',
            thumb='thumb/movie.png',
            icon='icon/movie.png',
            poster='poster/movie.png'
        )
        itemlist.append(new_item)
        itemlist.extend(menupeliculas(new_item))

        new_item = item.clone(
            type='label',
            label="Series",
            category='tvshow',
            thumb='thumb/tvshow.png',
            icon='icon/tvshow.png',
            poster='poster/tvshow.png',
        )
        itemlist.append(new_item)
        itemlist.extend(menuseries(new_item))

        itemlist.append(item.clone(
            action="config",
            label="Configuración",
            folder=False,
            category='all',
            type='setting'
        ))
    return itemlist


def menupeliculas(item):
    logger.trace()

    itemlist = list()

    itemlist.append(item.clone(
        label='Novedades',
        action='content',
        url= HOST + 'peliculas/',
        content_type='movies',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Género',
        action='genero',
        url=HOST + 'peliculas/',
        content_type='movies',
        type="item",
        group=True
    ))


    itemlist.append(item.clone(
        label='Buscar',
        action='search',
        content_type='movies',
        query=True,
        group=True,
        type='search'
    ))
    return itemlist


def menuseries(item):
    logger.trace()

    itemlist = list()

    itemlist.append(item.clone(
        label='Actualizadas',
        action='content',
        url= HOST + 'series/',
        type="item",
        group=True,
        content_type='tvshows'
    ))

    itemlist.append(item.clone(
        label='Nuevas Series',
        action='content',
        url=HOST + 'series/novedades',
        type="item",
        group=True,
        content_type='tvshows'
    ))

    itemlist.append(item.clone(
        label='Género',
        action='genero',
        url=HOST + 'series',
        content_type='tvshows',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Buscar',
        action='search',
        content_type='tvshows',
        query=True,
        group=True,
        type='search'
    ))
    return itemlist


def config(item):
    v = platformtools.show_settings()
    platformtools.itemlist_refresh()
    return v


def login():
    logger.trace()
    try:
        user = settings.get_setting('user', __file__)
        password = settings.get_setting('password', __file__)
        if user and password:
            post = {'user': user,
                    'pass': password,
                    '_method': 'auth/login'
                    }

            data = jsontools.load_json(httptools.downloadpage(HOST + '/ajax.php', post=post).data)
            if not data['alert']:
                return True
            else:
                platformtools.dialog_notification('Playdede',  data['alert'].get('text', 'Login incorrecto'))
    except:
        pass

    return False


@LimitResults
def content(item):
    logger.trace()
    itemlist = []

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    patron = '<article id="([^"]+)".*?<a href="([^"]+)">.*?<img src="([^"]+).*?<p>(\d+)</p>\s*<h3>([^<]+)'
    for id, url, poster, year, title in scrapertools.find_multiple_matches(data, patron):
        new_item = item.clone(
            label=title,
            url=url + '/',
            poster=poster,
            title=title,
            year=year,
            playdedeid=id
        )

        if item.content_type == 'movies' and '/pelicula/' in url:
            new_item.action='findvideos'
            new_item.content_type='servers'
            new_item.type = 'movie'

        elif item.content_type == 'tvshows' and '/serie/' in url:
            new_item.action = 'seasons'
            new_item.content_type = 'seasons'
            new_item.type = 'tvshow'

        else:
            continue

        itemlist.append(new_item)

    # Paginador
    next_page = scrapertools.find_single_match(data, r'<a href="([^"]+)" data-ajax="main">Pagina Siguiente')
    if next_page:
        itemlist.append(item.clone(type='next', url=next_page))

    return itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)
    for season in scrapertools.find_multiple_matches(data, r"<div class='clickSeason .*? data-season='(\d+)'"):
        itemlist.append(item.clone(
            season=int(season),
            title="Temporada %s" % season,
            tvshowtitle=item.title,
            action="episodes",
            type='season',
            content_type='episodes'
        ))
    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    patron = '<a href="([^"]+)".*?<img src="([^"]+)"></div><div class="episodiotitle"><div class="epst">([^<]+)</div><div class="numerando">([^<]+)'
    for url, thumb, title, season_and_episode in scrapertools.find_multiple_matches(data, patron):
        num_season, num_episode = scrapertools.get_season_and_episode(season_and_episode.replace(' - ', 'x'))
        if item.season == num_season:
            itemlist.append(item.clone(
                title=title,
                url=url,
                thumb=thumb,#.replace('/w154/', '/original/'),
                action="findvideos",
                episode=num_episode,
                type='episode',
                content_type='servers'
            ))
    return itemlist


def search(item):
    logger.trace()
    item.url = HOST + '/search/?s=' + item.query.replace(" ", "+")
    return content(item)


def genero(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    patron = '<li class="cfilter " data-type="genre" data-value="([^"]+)".*?<b>([^<]+)'
    for value, title in scrapertools.find_multiple_matches(data, patron):
        tipo = 'peliculas' if item.content_type== 'movies' else 'series'
        itemlist.append(item.clone(
            label=title,
            action='content',
            url=HOST + '%s/?genre=%s' % (tipo,value),
            type="item"
        ))

    return itemlist


def findvideos(item):
    logger.trace()
    itemlist = []

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    # enlaces usuarios
    patron = '<li><a href="([^"]+).*?>([^<]+)<b>([^<]+)</b> </span><span> <img src="assets/image/languages/([^_]+)'
    stream = True
    for subdata in data.split('<div class="contEP contepID_3">'):
        for url, server, qlt, lang in scrapertools.find_multiple_matches(subdata, patron):
            itemlist.append(item.clone(
                type='server',
                action='play',
                url= url,
                stream=stream,
                server=server.strip(),
                lang=LNG.get(lang),
                quality=QLT.get(qlt.strip())
            ))
        stream = False

    # Enlaces OFICIAL
    oficiales = []
    patron = '<div class="playerItem.*?data-lang="([^"]+)" data-loadPlayer="([^"]+)".*?<h3>([^<]+)</h3><p>Calidad:([^<]+)'
    for lang, id, server, qlt in scrapertools.find_multiple_matches(data, patron):
        oficiales.append(item.clone(
            type='server',
            action='play',
            id=id,
            url='',
            server=server,
            lang=LNG.get(lang),
            quality=QLT.get(qlt.strip())
        ))

    return servertools.get_servers_from_id(oficiales + itemlist)

def play(item):
    logger.trace()

    if not item.url:
        post = {'_method': 'getPlayer', 'id':item.id}
        data = httptools.downloadpage(HOST +'/ajax.php', post=post).data
        item.url = scrapertools.find_single_match(data, r"src='([^']+)").replace('\\','')

    servertools.normalize_url(item)
    return item

