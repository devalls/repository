# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    file_name = scrapertools.find_single_match(data, '<input type="hidden" id="file_name" value="([^"]+)">')
    server = scrapertools.find_single_match(data, '<input type="hidden" id="srv" value="([^"]+)">')
    url = server + '/v2/schema/' + file_name + '/'
    itemlist.append(Video(url=url + 'med.m3u8', res='720p', type='m3u8'))
    itemlist.append(Video(url=url + 'low.m3u8', res='480p', type='m3u8'))
    itemlist.append(Video(url=url + 'min.m3u8', res='360p', type='m3u8'))

    return itemlist
