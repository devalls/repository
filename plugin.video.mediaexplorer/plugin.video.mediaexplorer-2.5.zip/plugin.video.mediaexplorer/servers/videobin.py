# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()

    itemlist = list()

    data = httptools.downloadpage(item.url).data

    sources = eval(scrapertools.find_single_match(data, r'sources: (\[.*?\])'))

    for url in sources:
        itemlist.append(Video(url=url.strip()))

    itemlist.sort(key=lambda i: i.type == '.m3u8')

    return itemlist
