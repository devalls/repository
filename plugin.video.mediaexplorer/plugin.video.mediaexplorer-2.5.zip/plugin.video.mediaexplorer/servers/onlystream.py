# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    if '404 Error' in data:
        return ResolveError(0)

    for  url, type, res in scrapertools.find_multiple_matches(data, r'src:\s*"([^"]+)",\s*type:\s*"([^"]+)",\s*res:\s*(\d+)'):
        logger.debug(url)
        itemlist.append(Video(url=url, res=res + 'p', type=type.replace('video/','').capitalize()))

    return itemlist
