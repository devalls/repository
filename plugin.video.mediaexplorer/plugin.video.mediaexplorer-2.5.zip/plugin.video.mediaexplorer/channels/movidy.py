# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://movidy.nz/'

LNG = Languages({
    Languages.es: ['castellano', 'español castellano'],
    Languages.la: ['latino'],
    Languages.sub_es: ['subtitulado', 'ingles subtitulado'],
    Languages.en: ['ingles']
})

QLT = Qualities({
    Qualities.hd_full: ['1080p'],
    Qualities.hd: ['720p','HDTV'],
    Qualities.sd: ['480p', '360p'],
    Qualities.rip: ['rip', 'hdrip', 'hdrvrip'],
    Qualities.scr: ['screener', 'TS']
})


def mainlist(item):
    logger.trace()
    itemlist = list()

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        banner='banner/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    new_item = item.clone(
        type='label',
        label="Series",
        category='tvshow',
        banner='banner/tvshow.png',
        icon='icon/tvshow.png',
        poster='poster/tvshow.png',
    )
    itemlist.append(new_item)
    itemlist.extend(menuseries(new_item))

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label='Novedades',
        action='content',
        content_type='movies',
        url=HOST + 'peliculas',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Recomendadas',
        action='content',
        content_type='movies',
        url=HOST + 'peliculas/?mejor-valoradas',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Género',
        action='genero',
        content_type='items',
        url=HOST + 'peliculas',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Buscar',
        action='search',
        query=True,
        content_type='movies',
        type="search",
        group=True
    ))

    return itemlist


def menuseries(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label='Nuevos episodios',
        action='content',
        content_type='episodes',
        url=HOST + 'series/?novedades',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Nuevas series',
        action='content',
        content_type='tvshows',
        url=HOST + 'series',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Series actualizadas',
        action='content',
        content_type='tvshows',
        url=HOST + 'series/?actualizadas',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Recomendadas',
        action='content',
        content_type='tvshows',
        url=HOST + 'series/?mejor-valoradas',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Buscar',
        action='search',
        query=True,
        content_type='tvshows',
        type="search",
        group=True
    ))

    return itemlist


def genero(item):
    logger.trace()
    itemlist = list()

    generos= ['Acción', 'Animación', 'Misterio', 'Bélica', 'Ciencia ficción', 'Comedia', 'Crimen', 'Drama',
              'Suspense', 'Familia', 'Música', 'Romance', 'Terror', 'Wester']
    for g in generos:
        url = HOST + 'peliculas/?genero[]=%s&estreno[]=' % g.replace(' ', '%20')

        itemlist.append(item.clone(
            label=g,
            action='content',
            content_type='movies',
            url=url,
            type="item"
        ))
    return itemlist


def content(item):
    logger.trace()
    itemlist = list()

    if not item.url.startswith(HOST):
        item.url = HOST + item.url

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    if item.query:
        patron = r'<article class="Cards\s*(?:carPerf|)"><a href="(?P<url>[^"]+)".*?<b class="tng2">(?P<aux>[^<]+).*?' \
                 r'data-echo="(?P<poster>[^"]+).*?title="(?P<title>[^"]+)"></div>'
    else:
        patron = r'<article class="Cards\s*(?:carPerf|)"><a href="(?P<url>[^"]+)".*?data-echo="(?P<poster>[^"]+).*?' \
                 r'title="(?P<title>[^"]+)"></div>'

        if item.content_type == 'episodes':
            patron += r'<div class="CInfo noHide2"><h2><b>(?P<aux>[^<]+)'
        else:
            patron += r'<div class="CInfo noHidetho"><p>(?P<aux>\d+)'

    for result in re.compile(patron, re.DOTALL).finditer(data):
        if item.query and ((item.category == 'movie' and result.group('aux').lower() != 'pelicula') or (
                item.category == 'tvshow' and result.group('aux').lower() != 'serie')):
            continue

        new_item = item.clone(
            title=result.group('title'),
            poster=result.group('poster'),
            url=result.group('url')
        )

        if item.content_type == 'movies':
            new_item.year = result.group('aux') if not item.query else None
            new_item.action = 'findvideos'
            new_item.content_type = 'servers'
            new_item.type = 'movie'

        elif item.content_type == 'tvshows':
            new_item.year = result.group('aux') if not item.query else None
            new_item.action = 'seasons'
            new_item.content_type = 'seasons'
            new_item.type = 'tvshow'

        elif item.content_type == 'episodes':
            new_item.action = 'findvideos'
            new_item.content_type = 'servers'
            new_item.type = 'episode'
            num_season, num_episode = scrapertools.get_season_and_episode(result.group('aux').replace(' - ', 'x'))
            new_item.season = num_season
            new_item.episode = num_episode

        itemlist.append(new_item)

    if itemlist:
        next_url = scrapertools.find_single_match(data, '<a href="([^"]+)" up-target="body">Pagina siguiente')
        if next_url:
            itemlist.append(item.clone(url=next_url, type='next', action='content'))

    return itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    for season in scrapertools.find_multiple_matches(data, r'<div class="season temporada-(\d+)'):
        itemlist.append(item.clone(
            season=int(season),
            title="Temporada %s" % season,
            tvshowtitle=item.title,
            action="episodes",
            type='season',
            content_type='episodes'
        ))

    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)
    patron = '<li><a href="([^"]+)".*?data-echo="([^"]*)"></div><h2>([^<]+)</h2><div class="startEp"><span>([^<]+)'
    for url, thumb, title, season_and_episode in scrapertools.find_multiple_matches(data, patron):
        num_season, num_episode = scrapertools.get_season_and_episode(season_and_episode.replace(' - ', 'x'))
        if item.season == num_season:
            itemlist.append(item.clone(
                title=title,
                url=url,
                thumb=thumb.replace('/w154/', '/original/'),
                action="findvideos",
                episode=num_episode,
                type='episode',
                content_type='servers'
            ))

    return itemlist


def search(item):
    logger.trace()
    item.url = HOST + '?s=' + item.query.replace(" ", "+")
    return content(item)


def findvideos(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    # enlaces usuarios
    patron = r'<li><a href="([^"]+)" rel="nofollow noopener" target="_blank">.*?<span><[^>]+>([^<]+)<b>([^<]+).*?' \
             r'src="https://movidy\.tv/wp-content/themes/Movidy/images/(.*?)\.png"'
    stream = True
    for subdata in data.split('<div class="contEP contepID_3">'):
        for url, server, qlt, lang in scrapertools.find_multiple_matches(subdata, patron):
            itemlist.append(item.clone(
                type='server',
                action='play',
                url=HOST[:-1] + url,
                stream = stream,
                server=server.split('.', 1)[0],
                lang=LNG.get(lang),
                quality=QLT.get(qlt)
            ))
        stream = False

    # Enlaces OFICIAL
    oficiales = []

    src = scrapertools.remove_white_spaces(httptools.downloadpage(HOST + scrapertools.find_single_match(data, 'src="(/video/\d+.mp4)')).data)
    patron = '<li id="([^"]+).*?<span>([^<]+)</span><p>([^<]+)'
    for opt, server, qlt in scrapertools.find_multiple_matches(src, patron):
        oficiales.append(item.clone(
            type='server',
            action='play',
            url=HOST[:-1] + scrapertools.find_single_match(data, "getElementById\('%s'\).setAttribute\('onclick', 'go_to_player\(.'([^']+)" % opt)[:-1],
            server=server.lower(),
            opt = opt,
            lang=LNG.get(scrapertools.find_single_match(opt,'opt_([^_]+)')),
            quality=QLT.get(qlt)
        ))

    return servertools.get_servers_from_id(oficiales + itemlist)


def play(item):
    logger.trace()
    url = None

    headers = {'Referer': item.referer}
    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url, headers=headers).data)
    sitekey = scrapertools.find_single_match(data, 'data-sitekey="([^"]+)')

    response = platformtools.show_recaptcha(item.url, sitekey)
    headers = {'Referer': item.url}

    if '/enlace/' in item.url:
        post = {'g-recaptcha-response': response, 'id': scrapertools.find_single_match(data, 'input name="id" value="([^"]+)"')}
        resp = httptools.downloadpage(item.url, post=post, headers=headers, follow_redirects=False)
        url = resp.headers.get('location')

    else:
        post = {'token': response, 'id': scrapertools.find_single_match(data, "player.id='([^']+)") , 'ajax': 'true'}
        resp = httptools.downloadpage(item.url, post=post, headers=headers)
        url = scrapertools.find_single_match(resp.data,'link":"([^"]+)').replace('\\','')

    if url:
        item.url = url
        servertools.normalize_url(item)

    return item
