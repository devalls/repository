# -*- coding: utf-8 -*-
from core.libs import *


def mainlist(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label='Novedades',
        action='movies',
        type="item",
        content_type='movies',
        url='/espana/'
    ))

    itemlist.append(item.clone(
        label='Generos',
        action='categorias',
        type="item",
        content_type='items',
        url='/espana/'
    ))

    itemlist.append(item.clone(
        label='Buscar',
        action='search',
        content_type='movies',
        query=True,
        type='search'
    ))

    return itemlist


def config(item):
    platformtools.show_settings(item=item)


def search(item):
    logger.trace()
    item.url = '/espana/?s=%s' % item.query
    return movies(item)


def categorias(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    patron = '<li id="menu-item-[^>]+><a href="([^>]+)">([^<]+)</a></li>'

    for url, label in sorted(scrapertools.find_multiple_matches(data, patron), key=lambda x: x[1]):
        if label in ['× Cerrar', '☰ Menú', 'Películas por Año']:
            continue

        itemlist.append(item.clone(
            action='movies',
            label=label.strip(),
            url=url,
            content_type='movies'
        ))

    return itemlist


@LimitResults
def movies(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    patron = r'<h3 style="padding: 15.4px; color: white; width: 220px; font-size: 18px; position: absolute; ' \
             r'margin: 0px; display: none;"><div class="home_post_content"><div class="in_title">(?P<title>[^<]+)' \
             r'(?P<year>\(\d+\))</div>.*?<img.*?src="(?P<poster>[^"]+)".*?<a href=\'(?P<url>[^>\']+)\''

    for result in re.compile(patron, re.DOTALL).finditer(data):
        itemlist.append(item.clone(
            action='findvideos',
            title=result.group('title').strip(),
            url=result.group('url').strip("'"),
            poster=result.group('poster'),
            type='movie',
            content_type='servers',
            year=result.group('year').strip('()')
        ))

    # Paginador

    next_url = scrapertools.find_single_match(data, '<a class="nextpostslink" rel="next[^>]+href="([^"]+)">')
    if next_url:
        itemlist.append(item.clone(
            action='movies',
            url=next_url,
            type='next'
        ))

    return itemlist


def findvideos(item):
    logger.trace()
    itemlist = list()
    logger.debug(item.url)
    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    patron = r'<a href="([^"]+)" target="_blank"><li>([^<]+)</li> </a>'

    for url, server in re.compile(patron, re.DOTALL).findall(data):
        if '/protect/v.' in url:
            link_data = scrapertools.remove_white_spaces(httptools.downloadpage(url).data)
            url = scrapertools.find_single_match(link_data, '<a href="([^"]+)" rel="noreferrer"')

        itemlist.append(item.clone(
            action='play',
            url=url,
            type='server'
        ))

    for server, url in scrapertools.find_multiple_matches(data, "data-host='([^'+]+)' data-url='([^'+]+)'"):
        url = ''.join(map(chr, [int(x) - 2 for x in url.split(' ')]))
        if url:
            itemlist.append(item.clone(
                action='play',
                url=url,
                type='server'
            ))

    return servertools.get_servers_itemlist(itemlist)
