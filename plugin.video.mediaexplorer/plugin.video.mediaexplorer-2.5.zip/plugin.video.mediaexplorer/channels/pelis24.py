# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://repelis24.co'

services = {'EvoPlay': 'evoload',
            'MePlay': 'netutv',
            'PlaySTP': 'streamtape',
            'Stream': 'mystream',
            'MixDrop': 'mixdrop',
            'UpStream': 'upstream',
            'Fembed': 'fembed',
            'UqLoad': 'uqload'}


LNG = Languages({
    Languages.es: ['castellano', 'español'],
    Languages.la: ['latino'],
    Languages.sub_es: ['subtitulado']
})

QLT = Qualities({
    #Qualities.hd_full: ['HD 1080p'],
    Qualities.hd: ['HD'],
    Qualities.rip: ['DVD'],
    Qualities.scr: ['CINE']
})


def mainlist(item):
    logger.trace()
    itemlist = list()

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        banner='banner/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    """new_item = item.clone(
        type='label',
        label="Series",
        category='tvshow',
        banner='banner/tvshow.png',
        icon='icon/tvshow.png',
        poster='poster/tvshow.png',
    )
    itemlist.append(new_item)
    itemlist.extend(menuseries(new_item))"""

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="movies",
        label="Novedades",
        url=HOST + "/pelicula/",
        type="item",
        group=True,
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="movies",
        label="Castellano",
        url=HOST + '/idioma/castellano/',
        lang=LNG.get('castellano'),
        type="item",
        group=True,
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="movies",
        label="Latino",
        url=HOST + '/idioma/latino/',
        lang=LNG.get('latino'),
        type="item",
        group=True,
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="movies",
        label="Subtituladas",
        url=HOST + '/idioma/subtituladas/',
        lang=LNG.get('subtitulado'),
        type="item",
        group=True,
        content_type='movies'
    ))

    itemlist.append(item.clone(
        label='Generos',
        action='generos',
        type="item",
        group=True,
        content_type='items',
        url=HOST
    ))

    itemlist.append(item.clone(
        label='Buscar',
        action='search',
        query=True,
        content_type='movies',
        type="search",
        group=True
    ))

    return itemlist


def generos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = '(?<=<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-.{4}"><a href=)(https://repelis24.co/genero/.*?/)>([^<]+)'
    for url, title in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            label=title,
            url=url,
            action='movies',
            content_type='movies',
        ))

    return sorted(itemlist, key=lambda x: x.label)


def search(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage( HOST + '?s=%s' % item.query.replace(' ', '+')).data)

    patron = r'<article .*?data-src=(.*?) .*?div class=mepo>(.*?)<div class=see>.*?<a href=([^>]+)>([^<]+)</a></h3> <span>(\d+)'
    for poster, qlt, url, title, year in scrapertools.find_multiple_matches(data, patron):
        if 'serie' in qlt:
            continue

        qlt = scrapertools.find_single_match(qlt, r'<span class=quality>([^<]+)</span>')

        itemlist.append(item.clone(
            title=title,
            year=year,
            poster=poster if poster.startswith('http') else 'https:' + poster,
            type='movie',
            quality=QLT.get(qlt),
            action='findvideos',
            url=url,
            content_type='servers'
        ))

    return itemlist


def movies(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)
    patron = '<article id=post-\d+.*?data-src=(.*?) .*?span class=quality>([^<]+).*?<a href=([^>]+)>.*?<div class=title><h4>([^<]+).*?<span>(\d{4}).*?<div class=audio>(.*?)<div class=texto>(.*?)</div>'

    for poster, qlt, url, title, year, lng, plot in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            title=title,
            year=year,
            poster= poster if poster.startswith('http') else 'https:' + poster,
            type='movie',
            action='findvideos',
            quality=QLT.get(qlt),
            lang=[LNG.get(x) for x in scrapertools.find_multiple_matches(lng, r'class=([^>]+)')] if not item.lang else item.lang,
            url=url,
            plot=plot,
            content_type='servers'
        ))

    # Paginador
    next_page = scrapertools.find_single_match(data, r'<a class=arrow_pag href=([^>]+)><i id=nextpagination')
    if next_page:
        itemlist.append(item.clone(type='next', url=next_page))

    return itemlist


def findvideos(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)
    for options in scrapertools.find_multiple_matches(data,
                r"<li id=player-option-\d+ class=dooplay_player_option data-type=(\w+) data-post=(\d+) data-nume=(\d+).*?(Castellano|Latino|Subtitulado|Español)</span>"):
        data = httptools.downloadpage(
            HOST + '/wp-admin/admin-ajax.php',
            post={
                'action': 'doo_player_ajax',
                'type': options[0],
                'post': options[1],
                'nume': options[2]
            }
        ).data
        lang = options[3]

        url = scrapertools.find_single_match(data, "src='([^']+)'")
        data = scrapertools.remove_white_spaces(httptools.downloadpage(url, headers={'Referer': item.url}).data)


        if 'IdiomaSet' in data:
            patron = 'onclick="IdiomaSet\(this, \'(\d)\'\);" class="select.*?"><span class="title"><img src="/assets/player/lang/([^.]+)'

            for n, lang in scrapertools.find_multiple_matches(data, patron):
                data1 = scrapertools.find_single_match(data, '<div class="Player%s(.*?)</div></div>' % n)
                patron = "go_to_player\('([^']+).*?<span class=\"serverx\">([^<]+)"
                for embed, server in scrapertools.find_multiple_matches(data1, patron):
                    if '/download/' in embed:
                        it = play(item.clone(
                            embed=embed.replace('/download/',''),
                            type='server',
                            action='play',
                            stream=False,
                            lang=LNG.get(lang.lower())
                        ))
                        itemlist.extend(servertools.get_servers_itemlist([it]))

                    else:
                        itemlist.append(item.clone(
                            embed=embed.replace('/playerdir/',''),
                            server=services.get(server, server),
                            type='server',
                            action='play',
                            stream=True,
                            lang=LNG.get(lang.lower())
                        ))

        else:
            patron = 'data-embed="([^"]+)" .*? <span class="serverx">([^<]+)</span>'
            for embed, server in scrapertools.find_multiple_matches(data, patron):
                itemlist.append(item.clone(
                    embed=embed,
                    server=services.get(server, server),
                    type='server',
                    action='play',
                    stream=True,
                    lang=LNG.get(lang.lower())
                ))


    return servertools.get_servers_from_id(itemlist)


def play(item):
    logger.trace()

    if item.embed.startswith('https://go.megaplay.cc'):
        data = httptools.downloadpage(item.embed).data
        key, value = scrapertools.find_single_match(data, r'name="([^"]+)" value="([^"]+)"')
        resp = httptools.downloadpage('https://go.megaplay.cc/r.php', post={key: value}, follow_redirects=False)
        item.url = resp.headers['location']

    else:
        url = "https://player.repelis24.co/playdir/" + item.embed
        data = httptools.downloadpage(url.split('&')[0], headers={'Referer': url}).data

        item.url = scrapertools.find_single_match(data, r'<iframe .*?src="([^"]+)')
        if item.url and not item.url.startswith("http"):
            data = httptools.downloadpage("https://play.repelis24.co" + item.url, headers={'Referer': url}).data
            item.url = scrapertools.find_single_match(data, r'<iframe .*?src="([^"]+)')


    if item.url:
        servertools.normalize_url(item)

    return item