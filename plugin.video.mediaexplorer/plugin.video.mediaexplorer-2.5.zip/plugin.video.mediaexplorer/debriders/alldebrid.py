# -*- coding: utf-8 -*-
from core.libs import *

def authorize_resolver():
    def _getToken(check_url):
        ret = False
        data = httptools.downloadpage(check_url).data
        # logger.debug(data)
        if "success" in data:
            data = jsontools.load_json(data).get('data')
            if data.get("activated"):
                settings.set_setting('Alldebrid_apikey', data.get('apikey', ''), __file__)
                ret = True
        elif data.get('error'):
            looger(data.get('message', 'Alldebrid Pin Error'))
        return ret

    authorize = msg_notification = False
    timedown = -1
    data = httptools.downloadpage("https://api.alldebrid.com/v4/pin/get?agent=MediaExplorer").data

    if "success" in data:
        data = jsontools.load_json(data).get('data')
        dialog = platformtools.dialog_progress("MediaExplorer", "")

        if data.get("check_url"):
            settings.set_setting('Alldebrid_apikey', '', __file__)
            timedown = data.get("expires_in", 130)
            #timedown = 60
            porcentaje = 100 / timedown
            msg = "Entra en [COLOR blue]'%s'[/COLOR] con tus datos de usuario y pon el pin [COLOR red]%s[/COLOR] " % (data.get("base_url", ""), data.get("pin", ""))
            msg += "antes de %s minutos y %s segundos."

            while not dialog.iscanceled() and timedown > 0:
                if timedown % 5 == 0 and _getToken(data.get("check_url")):
                    authorize = True
                    break
                time.sleep(1)
                timedown -= 1
                dialog.update(int(timedown * porcentaje), msg % divmod(timedown, 60))

        dialog.close()

        if authorize:
            msg_notification = "Su cuenta de Alldebrid ha sido emparejada con MediaExplorer"
        elif timedown == 0:
            msg_notification = "Tiempo excedido"
        elif not dialog.iscanceled():
            msg_notification = "Error al emparejar su cuenta de Alldebrid"
        if msg_notification:
            platformtools.dialog_notification("MediaExplorer", msg_notification)

        return authorize


def get_video_url(item):
    logger.trace()
    itemlist = list()

    if settings.get_setting('account', __file__) and (settings.get_setting('Alldebrid_apikey', __file__) or authorize_resolver()):
        url = "https://api.alldebrid.com/v4/link/unlock?agent=MediaExplorer&apikey=%s&link=%s" %(
            settings.get_setting('Alldebrid_apikey', __file__),  urllib_parse.quote_plus(item.url))

        data = jsontools.load_json(httptools.downloadpage(url, headers={'User-Agent': 'MediaExplorer'}).data)
        if data.get("status", "error") == 'success' and data['data'].get('link'):
            itemlist.append(Video(url=data['data'].get('link'), res='Original', ))
        else:
            logger.error(data)
            itemlist = ResolveError(data['error'])
    else:
        itemlist = ResolveError(2)

    return itemlist
