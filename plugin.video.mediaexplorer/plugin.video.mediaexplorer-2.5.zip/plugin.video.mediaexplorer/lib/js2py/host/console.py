from ..base import *

@Js
def console():
    pass

@Js
def log():
    try:
        print(arguments[0])
    except:
        print(repr(arguments[0].value))

console.put('log', log)
console.put('debug', log)
console.put('info', log)
console.put('warn', log)
console.put('error', log)
