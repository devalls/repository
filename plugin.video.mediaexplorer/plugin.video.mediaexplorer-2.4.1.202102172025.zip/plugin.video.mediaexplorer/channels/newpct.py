# -*- coding: utf-8 -*-
from core.libs import *

LNG = Languages({
    Languages.es: ['Español Castellano', 'Castellano', 'Spanish', 'Espa', 'Español'],
    Languages.la: ['Español Latino'],
    Languages.sub_en: ['Ingles Subtitulado', 'Ingles+Subs', '5.1-Ingles+Subs'],
    Languages.vos: ['V.O. Subt. Castellano', 'Chino+Subs']
})

QLT = Qualities({
    Qualities.hd_full: ['bluray 1080p', 'bluray microhd', 'bdremux', 'hdtv 1080p ac3 5.1', 'microhd'],
    Qualities.uhd: ['4kultrahd', '4k', '4kuhdrip', '4kuhdremux', '4k uhdmicro', 'fulluhd4k'],
    Qualities.m3d: ['bluray 3d 1080p'],
    Qualities.rip: ['blurayrip ac3 5.1', 'blurayrip', 'dvdrip', 'rip', 'dvdrip ac3 5.1'],
    Qualities.sd: ['hdtv'],
    Qualities.scr: ['bluray-screeener', 'ts-screener', 'dvd-screener', 'hdtv-screener', 'camrip'],
    Qualities.hd: ['hdtv 720p ac3 5.1', 'hdtv 720p']
})

HOST = moduletools.get_channel_host(__file__)

def mainlist(item):
    logger.trace()
    itemlist = list()

    #itemlist.append(item.clone(type='label', label=HOST))

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        thumb='thumb/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    new_item = item.clone(
        type='label',
        label="Series",
        category='tvshow',
        thumb='thumb/tvshow.png',
        icon='icon/tvshow.png',
        poster='poster/tvshow.png',
    )
    itemlist.append(new_item)
    itemlist.extend(menuseries(new_item))

    itemlist.append(item.clone(
        action="config",
        label="Configuración",
        folder=False,
        category='all',
        type='setting'
    ))

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="movies",
        label="Películas en Español",
        categoryIDR=757,
        type="item",
        group=True,
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="movies",
        label="Películas en Latino",
        categoryIDR=1527,
        type="item",
        group=True,
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="movies",
        label="Películas subtituladas",
        categoryIDR=778,
        type="item",
        group=True,
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="movies",
        label="Películas HD",
        categoryIDR=1027,
        type="item",
        group=True,
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="movies",
        label="Películas 3D",
        categoryIDR=1599,
        type="item",
        group=True,
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        content_type='movies'
    ))

    return itemlist


def menuseries(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="newest_episodes",
        label="Nuevos episodios",
        url='/ultimas-descargas/',
        categoryIDR=767,
        type="item",
        group=True,
        content_type='episodes'
    ))

    itemlist.append(item.clone(
        action="newest_episodes",
        label="Nuevos episodios VO",
        url='/ultimas-descargas/',
        categoryIDR=775,
        type="item",
        group=True,
        content_type='episodes'
    ))

    itemlist.append(item.clone(
        action="newest_episodes",
        label="Nuevos episodios HD",
        url='/ultimas-descargas/',
        categoryIDR=1469,
        type="item",
        group=True,
        content_type='episodes'
    ))

    itemlist.append(item.clone(
        action="tvshows",
        label="Series SD",
        url='/series/',
        type="item",
        group=True,
        content_type='tvshows'
    ))

    itemlist.append(item.clone(
        action="tvshows",
        label="Series HD",
        url='/series-hd/',
        type="item",
        group=True,
        content_type='tvshows'
    ))

    itemlist.append(item.clone(
        action="tvshows",
        label="Series subtituladas",
        url='/series-vo/',
        type="item",
        group=True,
        content_type='tvshows'
    ))

    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        content_type='tvshows'
    ))

    return itemlist

def search(item):
    logger.trace()
    itemlist = list()
    listado = list()

    if item.content_type == 'movies':
        list_pages = [757,1027]
    else:
        list_pages = [767,1469]

    for categoryIDR in list_pages:
        post={'categoryIDR': categoryIDR,
              'ordenar': 'Lo+Ultimo',
              'inon': 'Descendente',
              's': item.query.replace(' ', '+')}

        data = httptools.downloadpage('/get/result/',post=post).data
        try:
            data_json = jsontools.load_json(data)['data']['torrents']['0']
            if not data_json:
                raise()
        except:
            continue

        for t in data_json.values():
            t['calidad']= str(t['calidad'])
            if '/' + t['guid'] in listado or t['calidad'].strip().lower() == 'fullbluray':
                # El contenido completo del BluRay no se puede reproducir
                continue

            size = float(scrapertools.find_single_match(t['torrentSize'], r'(\d[.\d]*)')) * 1024
            info_label = re.split(r'\[', t['torrentName'].replace(']', ''))

            new_item = item.clone(
                url='/' + t['guid'],
                title = info_label[0].strip(),
                poster=HOST + t['imagen'].replace('/thumbs/','/mediums/'),
                date=t['torrentDateAdded'],
                quality=QLT.get(t['calidad'].strip().lower()),
                size=size * 1024 if 'gb' in t['torrentSize'].lower() else size
            )

            if item.content_type == 'movies':
                new_item.year = scrapertools.find_single_match(info_label[-1], '(\d{4})')
                if not new_item.year:
                    new_item.year = scrapertools.find_single_match(new_item.title, r'\((\d{4})\)')
                if new_item.year:
                    new_item.title.replace("(%s)" % new_item.year, '')

                new_item.lang = [LNG.get(info_label[2].split(' ')[-1].strip())]
                new_item.type = 'movie'
                new_item.content_type = 'servers'
                new_item.action = 'findvideos'
            else:
                new_item.title = re.sub(r' - Temporada \d+','',new_item.title)
                new_item.tvshowtitle = new_item.title
                new_item.type = 'tvshow'
                new_item.content_type = 'seasons'
                new_item.action = 'seasons'

            listado.append(new_item.url)
            itemlist.append(new_item)

    # Ordenar por fecha de publicacion
    itemlist.sort(key=lambda x: datetime.datetime.strptime(x.date, '%d/%m/%Y'))

    return itemlist


def movies(item):
    logger.trace()
    itemlist = list()

    if not item.url:
        item.url = '/ultimas-descargas/'

    data = httptools.downloadpage(item.url, post={'categoryIDR': item.categoryIDR, 'date': 'Siempre'}).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron = r'<li><a href="([^"]+)" title="([^"]+)"[^>]*><img (?:style="width:160px;height:230px;" |)src="([^"]+)".*?<span id="deco" style="[^"]+">([^<]+)<strong style="float:right;">Tamaño ([^<]+).*?Idioma : </span>\s*<strong style="display:inline-block;width:200px;color:red;border:solid 1px red;padding:1px 5px;">(.*?)</strong></div>'

    for url, title, poster, qlt, size, lang in scrapertools.find_multiple_matches(data, patron):
        n = float(scrapertools.find_single_match(size, r'(\d[.\d]*)')) * 1024

        title = re.sub(r'^(descarg\w)', '', title, flags=re.I)
        if item.categoryIDR == 1599:
            title = re.sub(r'3D', '', title)

        if qlt.strip().lower() == 'fullbluray':
            # El contenido completo del BluRay no se puede reproducir
            continue

        itemlist.append(item.clone(
            title=title.strip(),
            url=url,
            poster=poster if poster.startswith('http') else ('https:' + poster),
            size=n * 1024 if 'gb' in size.lower() else n,
            quality=QLT.get(qlt.strip().lower()),
            lang=[LNG.get(lang)],
            type='movie',
            content_type='servers',
            action='findvideos'
        ))

    # paginacion
    next_page = scrapertools.find_single_match(data, '<li><a href="([^"]+)">Next</a></li>')
    if next_page:
        itemlist.append(item.clone(
            url=next_page,
            type='next'))

    return itemlist


def newest_episodes(item):
    logger.trace()
    itemlist = list()

    if not item.url:
        item.url = '/ultimas-descargas/'

    data = httptools.downloadpage(item.url, post={'categoryIDR': item.categoryIDR, 'date': 'Siempre'}).data
    data = scrapertools.find_single_match(data, '<ul class="noticias-series">(.*?)</ul>')
    patron = r'src="(?P<poster>[^"]+)".*?<a href="(?P<url>[^"]+)".*?<h2 style="font-size:18px;">(?P<title>[^<]+)</h2> </a> <span id="deco" style="margin-bottom:10px;">(?P<qlt>[^<]+)<strong style="float:right;">Tamaño (?P<size>[^<]+).*?Idioma : </span>(?P<lang>.*?)</strong></div>'

    for result in re.compile(patron, re.DOTALL).finditer(data):
        season_episode = scrapertools.find_single_match(result.group('title'),
                                                        r'temp\w*\.?\s*(\d+).*?cap\w*\.?\s*(\d+ al \d+)',
                                                        flags=re.DOTALL | re.IGNORECASE)
        if not season_episode:
            season_episode = scrapertools.find_single_match(result.group('title'),
                                                            r'temp\w*\.?\s*(\d+).*?cap\w*\.?\s*([^\s]+)',
                                                            flags=re.DOTALL | re.IGNORECASE)
        if not season_episode:
            season_episode = scrapertools.get_season_and_episode(result.group('title'))

        if season_episode:
            tvshowtitle = result.group('title').split('-')[0].strip()
            num_episode = [int(n) for n in scrapertools.find_multiple_matches(season_episode[1], r"(\d+)")]
            n = float(scrapertools.find_single_match(result.group('size'), r'(\d[.\d]*)')) * 1024
            poster = result.group('poster') if result.group('poster').startswith('http') else (
                    'https:' + result.group('poster'))

            new_item = item.clone(
                tvshowtitle=tvshowtitle,
                label=tvshowtitle,
                url=result.group('url'),
                # poster=poster,
                thumb=poster,
                episode=num_episode[0],
                season=int(season_episode[0]),
                size=n * 1024 if 'gb' in result.group('size').lower() else n,
                quality=QLT.get(result.group('qlt').strip().lower()),
                lang=[LNG.get(re.sub(r'(<.*?>)', '', result.group('lang')))],
                type='episode',
                content_type='servers',
                action='findvideos'
            )

            # Renumerar episodio si es necesario
            if new_item.episode > 99 and new_item.episode / 100 == new_item.season:
                new_item.episode -= (new_item.episode / 100) * 100

            # Multiepisodios
            if len(num_episode) > 1:
                new_item.multi_episode = list()
                if 'al' in season_episode[1] and len(num_episode) == 2:
                    multi_episodes = range(num_episode[0], num_episode[1] + 1)
                else:
                    multi_episodes = num_episode

                # Renumerar Multiepisodios si es necesario
                for n_episodio in multi_episodes:
                    if n_episodio > 99 and n_episodio / 100 == new_item.season:
                        new_item.multi_episodes.append(n_episodio - (n_episodio / 100) * 100)
                    else:
                        new_item.multi_episodes = multi_episodes
                        break

            itemlist.append(new_item)

        else:
            logger.debug("Temporada y episodio no encontrado: %s" % (result.group('title')))

    return itemlist


def tvshows(item):
    logger.trace()
    itemlist = list()

    if not item.url:
        item.url = '/series-hd/'

    if not item.subpage:
        item.subpage = 1

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    pelilist = scrapertools.find_single_match(data, r'<ul class="pelilist">.*?<ul class="pagination">')
    for url, ficha in scrapertools.find_multiple_matches(pelilist, r'<li>\s*<a href="([^"]+)"(.*?)</li>'):
        if url[:-1] == item.url:
            continue

        patron = r'<img src="([^"]+).*?<h2 style="height:28px;">([^<]+)</h2>\s*<span>([^<]+)'
        for poster, title, qlt in scrapertools.find_multiple_matches(ficha, patron):
            itemlist.append(item.clone(
                action='seasons',
                label=title,
                tvshowtitle=title,
                title=title,
                url=url,
                poster=poster if poster.startswith('http') else ('https:' + poster),
                quality=QLT.get(qlt.lower()),
                type='tvshow',
                content_type='seasons'
            ))

    # paginacion
    ini = (item.subpage - 1) * 20
    fin = item.subpage * 20

    if fin < len(itemlist) - 1:
        itemlist = itemlist[ini:fin]
        itemlist.append(item.clone(
            subpage=item.subpage + 1,
            type='next'))
    else:
        next_page = scrapertools.find_single_match(data, '<li><a href="([^"]+)">Next</a></li>')
        if next_page:
            itemlist = itemlist[ini:fin]
            itemlist.append(item.clone(
                url=next_page,
                subpage=1,
                type='next'))

    return itemlist


def read_episodes(item, pages):
    logger.trace()
    itemlist = list()

    def get_episodes(_item, url_page, _itemlist):
        data = httptools.downloadpage(url_page).data
        patron = r'<div class="info">\s+<a href="([^"]+)" title="[^"]+"><h2 style="padding:0;">(.*?)</h2></a>\s+' \
                 r'<span>[^<]+</span>\s+<span>([^<]+)</span>'

        for url, info_label, size in scrapertools.find_multiple_matches(data, patron):
            info_label = re.sub(r'(<.*?>)|\[|]', ' ', info_label)
            # Metodo 1: info_label='Serie  The Walking Dead - Temporada 1 COMPLETA  Capitulos 1 al 6  -
            # Español Castellano  Calidad    BluRayRip AC3 5.1'
            season_episode = scrapertools.find_single_match(
                info_label,
                r'temp\w*\.?\s*(\d+).*?cap\w*\.?\s*(\d+ al \d+)',
                flags=re.DOTALL | re.IGNORECASE
            )

            if not season_episode:
                # Metodo 2: 'Padre De Familia - Temp.10  HDTV  Cap.1016_1018  Spanish '
                #           'Padre De Familia - Temporada 6  DVDRIP  Caps.604-605-606-607  Spanish '
                #           'Padre De Familia - Temporada 6  DVDRIP  Capit. 4'
                season_episode = scrapertools.find_single_match(
                    info_label,
                    r'temp\w*\.?\s*(\d+).*?cap\w*\.?\s*([^\s]+)',
                    flags=re.DOTALL | re.IGNORECASE
                )

            if not season_episode:
                # Metodo 3: info_label= "Serie The Walking Dead  season 4 episode 2 - Español Castellano Calidad  HDTV'
                season_episode = scrapertools.get_season_and_episode(info_label)

            if season_episode:
                num_episode = [int(n) for n in scrapertools.find_multiple_matches(season_episode[1], r"(\d+)")]
                n = float(scrapertools.find_single_match(size, r'(\d[.\d]*)')) * 1024

                new_item = _item.clone(
                    title=_item.tvshowtitle,
                    url=url,
                    action="findvideos",
                    episode=num_episode[0],
                    season=int(season_episode[0]),
                    size=n * 1024 if 'gb' in size.lower() else n,
                    type='episode',
                    content_type='servers'
                )

                # Renumerar episodio si es necesario
                if new_item.episode > 99 and new_item.episode / 100 == new_item.season:
                    new_item.episode -= (new_item.episode / 100) * 100

                # Multiepisodios
                if len(num_episode) > 1:
                    new_item.multi_episode = list()
                    if 'al' in season_episode[1] and len(num_episode) == 2:
                        multi_episodes = range(num_episode[0], num_episode[1] + 1)
                    else:
                        multi_episodes = num_episode

                    # Renumerar Multiepisodios si es necesario
                    for n_episodio in multi_episodes:
                        if n_episodio > 99 and n_episodio / 100 == new_item.season:
                            new_item.multi_episodes.append(n_episodio - (n_episodio / 100) * 100)
                        else:
                            new_item.multi_episodes = multi_episodes
                            break

                # Idioma
                for k in sorted(LNG.values.keys(), key=lambda x: len(x), reverse=True):
                    if ' %s ' % k in info_label:
                        new_item.lang = LNG.values.get(k)
                        break

                # Calidad
                for k in sorted(QLT.values.keys(), key=lambda x: len(x), reverse=True):
                    if ' %s ' % k in info_label:
                        new_item.quality = QLT.values.get(k)
                        break

                _itemlist.append(new_item)

            else:
                logger.debug("Temporada y episodio no encontrado: %s - %s" % (info_label, url_page))

    threads = list()

    for p in pages:
        t = Thread(target=get_episodes, args=[item, item.url + '/pg/%s' % p, itemlist])
        t.setDaemon(True)
        t.start()
        threads.append(t)

    while [t for t in threads if t.isAlive()]:
        time.sleep(0.5)

    return itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    last = scrapertools.find_single_match(data, r'<li><a href="%s/pg/(\d+)">Last</a></li>' % item.url)

    pages = (range(1, int(last) + 1)) if last else [1]
    for t in sorted(set(e.season for e in read_episodes(item, pages))):
        itemlist.append(item.clone(
            pages=pages,
            season=t,
            action="episodes",
            type='season',
            content_type='episodes'
        ))

    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()

    if item.pages:
        itemlist = [e for e in read_episodes(item, item.pages) if e.season == item.season]

    return sorted(itemlist, key=lambda e: e.episode)


def findvideos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    # Torrent
    new_item = item.clone(
        action="play",
        url="https:" + scrapertools.find_single_match(data, r'window.location.href\s+=\s+"([^"]+)";'),
        type='server',
        server='torrent'
    )

    try:
        new_item.lang = item.lang[0]
    except Exception:
        pass
    itemlist.append(new_item)

    # Ver y descargar en 1 Link
    patron = """<div class="box2">([^<]+)</div>\s*<div class="box3">([^<]+)</div>\s*<div class="box4">([^<]+)</div>\s*<div class="box5"><a href='([^']+)'[^>]+>([^<]+)</a></div>\s*<div class="box6">([^<]+)</div>"""

    for server, lang, quality, url, _type, links in scrapertools.find_multiple_matches(data, patron):
        if '1 Link' in links:
            itemlist.append(item.clone(
                url=url,
                action='play',
                type='server',
                lang=LNG.get(lang),
                quality=QLT.get(quality.lower()),
                server=server,
                size=None,
                stream=False if 'DESCARGAR' in _type else True
            ))

    return servertools.get_servers_from_id(itemlist)


def play(item):
    logger.trace()

    if item.server == 'powvideo':
        servertools.normalize_url(item)

    return item


def config(item):
    v = platformtools.show_settings(item=item)
    platformtools.itemlist_refresh()
    return v
