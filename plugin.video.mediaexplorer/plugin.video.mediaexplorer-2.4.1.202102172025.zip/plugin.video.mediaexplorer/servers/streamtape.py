# -*- coding: utf-8 -*-
from core.libs import *

def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    if "Video not found!" in data:
        return ResolveError(0)
    url = scrapertools.find_single_match(data, r'videolink.+?innerHTML = "([^"]+)') + "&stream=1"
    if url.startswith('//'): url = 'https:' + url
    url = httptools.downloadpage(url, follow_redirects=False).headers['location']

    itemlist.append(Video(url=url))

    return itemlist
