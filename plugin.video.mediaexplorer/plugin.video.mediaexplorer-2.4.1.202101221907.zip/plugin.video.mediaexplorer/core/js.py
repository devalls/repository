# -*- coding: utf-8 -*-
# -*- protect
# <protect>
from core.libs import *
from core import ziptools
import stat
from core.app import AndroidAPP
import subprocess
import traceback
import platform
from six import BytesIO
from six.moves import urllib_request


class JS:
    def __init__(self, interpreter=None):
        self.node = NodeJS()
        self.android = AndroidJS()
        self.python = Js2PY()
        self.interpreters = ['node', 'android', 'python']
        self.interpreter = interpreter

        if not self.interpreter:
            p = settings.get_setting('mode', __file__)
            if p > 0:
                self.interpreter = self.interpreters[p - 1]
        else:
            if self.interpreter not in self.interpreters:
                raise NotImplementedError('Unknow prefered intrepreter')

    def run_js(self, value, **kwargs):
        if self.interpreter:
            interpreters = [self.interpreter]
        else:
            interpreters = self.interpreters

        for val in interpreters:
            interpreter = getattr(self, val)
            if len(self.interpreters) == 1 or interpreter.is_avaiable:
                logger.debug('Running JavaScript in: %s' % interpreter.__class__)
                result = interpreter.run_js(value=value, **kwargs)
                self.interpreter = val
                if interpreter.error:
                    logger.debug('Error ejecuntado JavaScript')
                    for l in result.splitlines():
                        logger.debug(l)
                    return ''
                else:
                    return result


class Js2PY:
    def __init__(self):
        self.response = None
        self.error = False
        self.js = None

    def new(self):
        try:
            import js2py
            self.js = js2py.EvalJs()
        except Exception:
            pass

    @property
    def is_avaiable(self):
        self.new()
        return self.js is not None

    def add_objects(self, **kwargs):
        def sendResponse(val):
            self.response = val.to_python()

        self.js['window'].python = {'sendResponse': sendResponse}
        self.js['window'].navigator = {}
        if 'userAgent' in kwargs:
            self.js['window'].navigator['userAgent'] = kwargs['userAgent']
        else:
            self.js['window'].navigator['userAgent'] = httptools.default_headers['User-Agent']

    def run_js(self, **kwargs):
        self.new()
        self.add_objects(**kwargs)

        try:
            self.js.eval(kwargs['value'])
        except Exception:
            self.error = True
            self.response = traceback.format_exc()

        return self.response


class NodeJS:
    def __init__(self):
        self.response = None
        self.error = False
        self.js = ''

    @property
    def is_avaiable(self):
        path = self.get_node_path()  # Obtenemos la ruta de node.js
        if path == 'node':  # Si la ruta es 'node' significa que esta instalado en el sistema
            return True

        self.download_if_not_exists()  # Intentamos descargar node si no existe

        return os.path.isfile(path)  # Si el archivo se ha descargado es que está disponible

    def download_node(self, node_path):
        variant = self.get_variant()  # Obtenemos el nomvre del archivo
        url = 'https://www.mediaexplorer.tk/content/bin/node/%s.zip' % variant
        dialog = platformtools.dialog_progress("Descargando Node.js", "Conectando...")

        try:
            handle = urllib_request.urlopen(url)  # Abrimos la url
        except Exception:
            dialog.close()
            logger.debug('Node.js no disponible para %s' % variant)
            return

        # Obtenemos el tamaño si está disponible
        headers = dict(handle.headers.items())
        length = int(headers.get('content-length', "0"))

        # Descargamos los datos
        data = b''
        dialog.update(0, "Descargando datos...")
        while True:
            if length:
                dialog.update(int(len(data) * 100 / length),
                              'Descargando datos...\n%s de %s...' % (change_units(len(data)), change_units(length)))
            else:
                dialog.update(0, 'Descargando datos...\n%s...' % change_units(len(data)))
            buff = handle.read(102400)
            if buff:
                data += buff
                continue
            break

        # Creamos los directorios
        if not os.path.isdir(os.path.dirname(node_path)):
            os.makedirs(os.path.dirname(node_path))

        # Descomprimimos
        logger.debug('Node.js descargado con éxito, descomprimiendo...')
        try:
            ziptools.extract(BytesIO(data), os.path.dirname(node_path), silent=True)
        except Exception:
            logger.debug('Error al extraer Node.js')

        # Damos permisos
        if os.path.isfile(node_path) and os.name != 'nt':
            logger.debug('Node.js estableciendo permisos...')
            st = os.stat(node_path)
            os.chmod(node_path, st.st_mode | stat.S_IEXEC)

        # Fin
        dialog.close()

    def download_if_not_exists(self):

        # Obtenemos la ruta
        node_path = self.get_node_path()

        if node_path == 'node':  # Instalado en el sistema
            return
        elif not os.path.isfile(node_path):  # No esta disponible
            logger.debug('Node.js no está en MediaExplorer, intentando descargar...')
            self.download_node(node_path)
        else:  # Está disponible
            logger.debug('Node.js disponible en: %s, comprobando...' % node_path)
            if self.test_node():
                logger.debug('Node.js funciona correctamente.')
            else:
                os.remove(node_path)
                logger.debug('Node.js NO funciona correctamente, volviendo a descargar')
                self.download_node(node_path)

    def add_objects(self, **kwargs):
        self.js += 'var python = {\'sendResponse\': console.log};\n'
        self.js += 'console.log = function(){};\n'
        self.js += 'console.debug = function(){};\n'
        self.js += 'console.error = function(){};\n'
        self.js += 'console.warn = function(){};\n'
        self.js += 'console.info = function(){};\n'
        self.js += 'var navigator = {};\n'
        if 'userAgent' in kwargs:
            self.js += 'navigator.userAgent=\'%s\';\n' % kwargs['userAgent']
        else:
            self.js += 'navigator.userAgent=\'%s\';\n' % httptools.default_headers['User-Agent']

    @staticmethod
    def get_os_args():
        if os.name == 'nt':
            si = subprocess.STARTUPINFO()
            si.dwFlags = 1
            si.wShowWindow = 0
            return {
                'startupinfo': si,
                'shell': True
            }
        else:
            return {}

    def run_js(self, **kwargs):
        self.js = ''
        self.add_objects(**kwargs)
        self.js += kwargs['value']

        js_path = os.path.abspath(os.path.join(sysinfo.data_path, 'run.js'))

        open(js_path, 'w').write(self.js)
        process = subprocess.Popen(
            [self.get_node_path(), os.path.join(sysinfo.data_path, 'run.js')],
            stderr=subprocess.PIPE,
            stdout=subprocess.PIPE,
            **self.get_os_args()
        )

        result = process.stdout.read().strip(b'\n')
        error = process.stderr.read().strip(b'\n')

        os.remove(js_path)

        if error:
            self.error = True
            self.response = six.ensure_str(error)
        else:
            self.response = six.ensure_str(result)
        return self.response

    @staticmethod
    def get_os():
        if platform.system() == 'Windows':
            return 'windows'
        elif platform.system() == 'Darwin':
            return 'osx'
        elif 'ANDROID_ROOT' in os.environ:
            return 'android'
        elif platform.system() == 'Linux':
            return 'linux'

    @staticmethod
    def get_arch():
        if sys.maxsize > 2 ** 32:
            return 64
        else:
            return 32

    @staticmethod
    def get_processor():
        if 'aarch' in platform.machine() or 'arm' in platform.machine():
            return 'arm'
        else:
            return ''

    def get_variant(self):
        name = self.get_os()
        if name == 'android':
            if self.get_processor() == 'arm' and self.get_arch() == 64:
                name += '_arm64'
            elif self.get_processor() == 'arm' and self.get_arch() == 32:
                name += '_armv7'
            elif self.get_arch() == 64:
                name += '_x64'
            else:
                name += '_x32'
        elif name == 'windows':
            if self.get_arch() == 64:
                name += '_x64'
            else:
                name += '_x86'
        elif name == 'linux':
            if self.get_processor() == 'arm' and self.get_arch() == 64:
                name += '_arm64'
            elif self.get_processor() == 'arm' and self.get_arch() == 32:
                name += '_armv7l'
            elif self.get_arch() == 64:
                name += '_x64'
            else:
                name += '_x86'
        elif name == 'osx':
            if self.get_arch() == 64:
                name += '_x64'
            else:
                name += '_x86'

        return name

    def get_node_settings(self):
        node_path = self.get_node_path()

        self.download_if_not_exists()

        if node_path == 'node':
            return 'Instalado en el sistema'
        elif not os.path.isfile(node_path):
            return 'No encontrado'
        else:
            if 'ANDROID_ROOT' in os.environ:
                return '[kodi_data_path]' + node_path.split('plugin.video.mediaexplorer')[-1]
            else:
                return '[data_path]' + os.path.sep + os.path.relpath(node_path, sysinfo.data_path)

    def get_node_version(self):
        try:
            process = subprocess.Popen(
                [self.get_node_path(), "--version"],
                stderr=subprocess.PIPE,
                stdout=subprocess.PIPE,
                **self.get_os_args()
            )
        except OSError:
            return '-'
        else:
            result = process.stdout.read().strip(b'\n')
            return result or '-'

    def test_node(self):
        try:
            process = subprocess.Popen(
                [self.get_node_path(), "--version"],
                stderr=subprocess.PIPE,
                stdout=subprocess.PIPE,
                **self.get_os_args()
            )
        except OSError:
            return False
        else:
            return not bool(process.stderr.read())

    def get_node_path(self):
        try:
            process = subprocess.Popen(
                ['node', "--version"],
                stderr=subprocess.PIPE,
                stdout=subprocess.PIPE,
                **self.get_os_args()
            )
        except OSError:
            logger.debug('Node.js NO está instalado en el sistema, buscando ejecutable en MediaExplorer')
        else:
            if process.stderr.read():
                logger.debug('Node.js NO está instalado en el sistema, buscando ejecutable en MediaExplorer')
            else:
                logger.debug('Node.js usando versíón instalada en el sistema')
                return 'node'

        node_path = os.path.abspath(os.path.join(sysinfo.data_path, 'bin', 'node'))

        if os.name == 'nt':
            node_path += '.exe'
        elif 'ANDROID_ROOT' in os.environ:
            package = os.environ['HOME'].split('/')[-2]
            node_path = '/data/data/%s/files/plugin.video.mediaexplorer/bin/node' % package

        return node_path


class AndroidJS:
    def __init__(self):
        self.error = False
        self.dialog = AndroidAPP()

    @property
    def is_avaiable(self):
        self.dialog.discover_devices(2)
        return bool(self.dialog.avaiable_devices)

    def run_js(self, **kwargs):
        error = 'window.onerror = function myErrorHandler(errorMsg, url, lineNumber) {' \
                'python.sendError(' \
                '\'Line: \' + (lineNumber - 1) + \'\\n\' + errorMsg' \
                ');' \
                'return false;' \
                '}'

        data = {
            'url': '',
            'html': '<script>%s;\n%s</script>' % (error, kwargs.pop('value')),
            'description': 'Ejecuntando JS...',
            'ui': False,
            'timeout': 2
        }
        data.update(kwargs)
        self.dialog.run(data)
        self.error = self.dialog.error
        return self.dialog.response
# </protect>
