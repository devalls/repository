# -*- coding: utf-8 -*-
# -*- protect
from core.libs import *
import base64

# <protect>
class EstructuraInicial(object):
    def __init__(self, data):
        self.data = data

        self.funcion = ''  # nombre de la función js que resuelve la estructura
        self.lista = []  # lista de valores del array inicial del js

        self.detectado, self.msg = self._detectar_estructura()

        if self.detectado:
            matches = re.compile(r"(%s\('([^']*)',\s*'([^']*)'\))" % self.funcion).findall(self.data)

            for i, match in enumerate(matches):
                x = self.unhex(match[2]) if match[2][:2] == ("\\%s" % "x") else match[2]
                valor = self._resolver_funcion(int(match[1], 16), x)

                if "'" not in valor:
                    self.data = self.data.replace(match[0], "'" + valor + "'")
                elif '"' not in valor:
                    self.data = self.data.replace(match[0], '"' + valor + '"')
                else:
                    logger.debug('problema cometes no previst! ' + valor)
                    return

            # crides a resolver amb dos paràmetres dins algun eval('')
            matches = re.compile("(%s\(\\\\'(.*?)\\\\',\s*\\\\'(.*?)\\\\'\))" % self.funcion).findall(self.data)
            for i, match in enumerate(matches):
                x = self.unhex(match[2]) if match[2][:2] == ("\\%s" % "x") else match[2]
                valor = self._resolver_funcion(int(match[1], 16), x)

                if "'" not in valor:
                    self.data = self.data.replace(match[0], "\\'" + valor + "\\'")
                elif '"' not in valor:
                    self.data = self.data.replace(match[0], '\\"' + valor + '\\"')
                else:
                    logger.debug('problema cometes no previst! ' + valor)
                    return

            # crides a resolver amb un paràmetre
            matches = re.compile("(%s\('([^']*)'\))" % self.funcion).findall(self.data)
            for i, match in enumerate(matches):
                valor = self._resolver_funcion(int(match[1], 16), '')

                if "'" not in valor:
                    self.data = self.data.replace(match[0], "'" + valor + "'")
                elif '"' not in valor:
                    self.data = self.data.replace(match[0], '"' + valor + '"')
                else:
                    logger.debug('problema cometes no previst! ' + valor)
                    return

            # crides a resolver amb un paràmetre dins algun eval('')
            matches = re.compile("(%s\(\\\\'(.*?)\\\\'\))" % self.funcion).findall(self.data)
            for i, match in enumerate(matches):
                valor = self._resolver_funcion(int(match[1], 16), '')

                if "'" not in valor:
                    self.data = self.data.replace(match[0], "\\'" + valor + "\\'")
                elif '"' not in valor:
                    self.data = self.data.replace(match[0], '\\"' + valor + '\\"')
                else:
                    logger.debug('problema cometes no previst! ' + valor)
                    return

    # Detectar si hay lo que se espera
    # --------------------------------
    def _detectar_estructura(self):
        # 1- Variable con lista de valores (guardar valores en self.lista y eliminar la variable del js)
        # --------------------------------
        m = re.search('var (\w*)\s*=\s*\[(.*?)\];', self.data)
        if not m: return False, ''  # 'No se encuentra el array inicial de valores!'

        nombre = m.group(1)
        self.lista = m.group(2).split(',')
        for i, v in enumerate(self.lista): self.lista[i] = v.strip()[1:-1]  # eliminar entre-comillado

        if self.lista[0][:2] == ("\\%s" % "x"):  # si los textos estan en hexa convertir a texto
            for i, v in enumerate(self.lista): self.lista[i] = self.unhex(v)

        self.data = self.data.replace(m.group(0), '')  # eliminar bloque entero
        # ~ print nombre, m.group(1), m.group(2), m.group(3)
        # ~ logger.info('Nombre: %s' % nombre)

        # 2- Self-Invoking Anonymous Function (buscar número para rotar self.lista y eliminar función del js)
        # -----------------------------------
        m = re.search('\(function\(.*?}\(%s,\s*([^\)]*)\)\);' % nombre, self.data, flags=re.DOTALL)
        if not m: return False, ''  # 'No se encuentra la función anónima autoinvocada!'

        numero = int(m.group(1), 0)
        # ~ logger.info('Numero: %d' % numero)

        self.data = self.data.replace(m.group(0), '')  # eliminar bloque entero

        for x in list(range(numero)): self.lista.append(self.lista.pop(0))
        # 3- Función resolver que recibe dos parámetros (guardar nombre de la función y eliminar función del js)
        # ---------------------------------------------
        m = re.search(
            'var (\w*)\s*=\s*function\s*\(\s*[^,]*,\s*[^\)]*\)\s*\{.*?\}\s*else\{\s*\w*\s*=\s*\w*;\s*\}\s*return \w*;\s*\};',
            self.data)
        if not m: return False, ''  # 'No se encuentra la función que resuelve!'
        self.funcion = m.group(1).strip()

        self.novedad = ''
        if '=(0x3+_0x' in m.group(0): self.novedad = '1'
        if "=(0x3+Math['pow'](0x7c,0x0)+_0x" in m.group(0): self.novedad = '2'

        self.data = self.data.replace(m.group(0), '')  # eliminar bloque entero

        return True, ''  # '*) Detectada estructura para desofuscar.\nVariable con %d elementos (rotación inicial de %d)\nFunción resolver: %s' % (len(self.lista), numero, self.funcion)

    # Resolver función principal
    # --------------------------
    def _resolver_funcion(self, num, s=''):
        r = str(self.lista[num])
        r = six.ensure_binary(base64.b64decode(r))

        x = ''
        for y in list(range(len(r))):
            x += '%' + ('00' + hex(ord(r[y:y+1]))[2:])[-2:]

        r = six.ensure_text(urllib_parse.unquote(x), 'utf8')
        if s == '': return r

        t = list(range(256))
        if self.novedad == '1':  # novetat 20190515
            for y in list(range(256)): t[y] = (3 + y) % 256
        elif self.novedad == '2':  # novetat 20190612
            for y in list(range(256)): t[y] = (4 + y) % 256

        u = 0
        w = ''
        for y in list(range(256)):
            i = (y % len(s))
            u = (u + t[y] + ord(s[i:i+1])) % 256
            v = t[y]
            t[y] = t[u]
            t[u] = v

        A = 0
        u = 0
        for y in list(range(len(r))):
            A = (A + 1) % 256
            u = (u + t[A]) % 256
            v = t[A]
            t[A] = t[u]
            t[u] = v
            w += six.unichr(ord(r[y:y+1]) ^ t[(t[A] + t[u]) % 256])

        return six.ensure_text(w, 'utf8')


    # Convertir de hexa a texto (Ej: '\x65\x66\x67' => 'efg')
    # -------------------------
    def unhex(self, txt):
        return re.sub("\\\\x[a-f0-9][a-f0-9]", lambda m: m.group()[2:].decode('hex'), txt)

def _uptostream_sumes(data):
    # ~ 'mPBM'+'A' => 'mPBMA'
    # [^.]+ per evitar "aa"+"bb".concat("cc")
    matches = re.findall("('([^']*)'\s*\+\s*'([^']*)')[^.]+", data, re.DOTALL)
    while matches:
        for tot, val1, val2 in matches:
            data = data.replace(tot, "'%s%s'" % (val1, val2))
        matches = re.findall("('([^']*)'\s*\+\s*'([^']*)')[^.]+", data, re.DOTALL)
    return data

def _uptostream_valors_directes(func, codi, data):
    # ~ 'bYGYc':'REAYB',
    m1 = re.findall("('[^']+'):('[^']+')", codi, re.DOTALL)
    for nom, valor in m1:
        # ~ logger.info('%s %s' % (nom, valor))
        # ~ _0x1aca6d['bYGYc'] => 'REAYB'
        data = data.replace("%s[%s]" % (func, nom), valor)
    return data

def _uptostream_funcio_simple(func, codi, data):
    # ~ 'seLyF':function(_0x5c1cc2){return _0x5c1cc2();},
    m1 = re.findall("('[^']+'):function\((\w+)\)\{return (\w+)\(\);\},", codi, re.DOTALL)
    for nom, p1, p2 in m1:
        # ~ logger.info('%s %s' % (nom, p1))
        if p1 == p2:
            # ~ _0x261dad['seLyF'](_0x1ec2fd) => _0x1ec2fd()
            data = re.sub("%s\[%s\]\(([^\)]+)\)" % (func, nom), chr(92) + '1()', data)
    return data

def _uptostream_funcio_doble(func, codi, data):
    # ~ 'pdNqF':function(_0x54c0ef,_0x11ddb6){return _0x54c0ef===_0x11ddb6;},
    # ~ 'aZuro':function(_0x4771a9,_0x362d75){return _0x4771a9+_0x362d75;},
    m1 = re.findall("('[^']+'):function\((\w+),(\w+)\)\{return (\w+)(\+|===|!==)(\w+);\},", codi, re.DOTALL)
    for nom, p1, p2, p3, op, p4 in m1:
        if p1 == p3 and p2 == p4:
            # ~ _0x261dad['pdNqF']('REAYB','REAYB') => 'REAYB'==='REAYB'
            # ~ _0x261dad['aZuro'](_0x1ec2fd()+'/',_0x2f451f()) => _0x1ec2fd()+'/'+_0x2f451f()
            data = re.sub("%s\[%s\]\(([^,]+),([^\)]+)\)" % (func, nom), lambda m: m.group(1) + op + m.group(2),
                          data)
    return data

def _uptostream_ifs_fake(data):
    # ~ if('ZvMGL'!=='EeXpc'){return'0';}else{return 'unknown 0';} => return'0';
    m1 = re.findall("(if\('([^']+)'(===|!==)'([^']+)'\)\{return\s*('[^']+');\}else\{return\s*('[^']+');\})", data,
                    re.DOTALL)
    for tot, p1, op, p2, v1, v2 in m1:
        if op == '===':
            cumple = (p1 == p2)
        else:
            cumple = (p1 != p2)
        data = data.replace(tot, 'return ' + (v1 if cumple else v2) + ';')
    return data

def _uptostream_funcions(data):
    # ~ var _0x5524aa=()=>{return '360';};
    m1 = re.findall("var (\w+)=\(\)=>\{return\s*('[^']+');\};", data, re.DOTALL)
    for nom, valor in m1:
        # ~ _0x5524aa() => '360'
        data = data.replace(nom + '()', valor)

    # ~ var _0x275daa=function(){return '360';};
    m1 = re.findall("var (\w+)=function\(\)\{return\s*('[^']+');\};", data, re.DOTALL)
    for nom, valor in m1:
        # ~ _0x275daa() => '360'
        data = data.replace(nom + '()', valor)

    # ~ function _0x1efe38(){return '0';}
    m1 = re.findall("function (\w+)\(\)\{return\s*('[^']+');\}", data, re.DOTALL)
    for nom, valor in m1:
        # ~ _0x1efe38() => '0'
        data = data.replace(nom + '()', valor)

    return data

def _uptostream_pilla_valor(data, valor):
    aux = list()
    for d in re.findall("\['%s'\]='?(\w+)'?;" % valor, data, re.DOTALL):
        try:
            if d.startswith('_0x'):
                aux.append(re.findall("var %s='([^']+)';" % d, data, re.DOTALL)[0])
            else:
                aux.append(d)
        except:
            pass
    return aux

def _getToken(refresh=False):
    token = settings.get_setting('TOP_token', __file__)
    type = settings.get_setting('TOP_type', __file__)
    if not token or not type or refresh:
        try:
            user = settings.get_setting('user', __file__)
            password = settings.get_setting('password', __file__)

            if user and password:
                httptools.downloadpage("https://uptobox.com/login?referer=homepage",
                                       post={'login': user, 'password': password})
                data = httptools.downloadpage("https://uptobox.com/my_account").data
                token = re.findall(r"Token:\s*<span class='to-clipboard'><span class='none'>([^<]+)</span></span>",
                                   data)[0]

            if not token: raise ()
            if re.search('Miembro Premium', data):
                type = 'premium'
            else:
                type = 'free'
            settings.set_setting('TOP_token', token, __file__)
            settings.set_setting('TOP_type', type, __file__)
        except:
            token = type = None
    return type, token
# </protect>

def get_video_url(item):
    logger.trace()
    itemlist = []
    lng = {'spa': u'Castellano', 'fre': u'Frances', 'eng': u'Ingles', 'rus': u'Ruso', 'ger': u'Aleman'}

    data = httptools.downloadpage(item.url).data
    if 'Archivo no encontrado' in data:
        return ResolveError(0)

    try:
        type, token = _getToken()
        id = item.url

        if token and type == 'premium':
            data = httptools.downloadpage('https://uptobox.com/api/link?token=%s&file_code=%s' % (token, id)).data
            dlink = re.findall('"dlLink":"([^"]+)', data)
            if dlink:
                itemlist.append(Video(res='Original', url=dlink[0].replace(chr(92), '')))
                if settings.get_setting('onlyOrigin',__file__):
                    return itemlist

        # <protect>
        if token:
            _url = 'https://uptobox.com/api/streaming?file_code=' + id
            data = httptools.downloadpage(_url).data
            pin = re.findall(r'"pin":"([^"]+)', data)

            if pin:
                check_url = re.findall(r'"check_url":"([^"]+)', data)[0].replace(chr(92), '')
                _url = 'https://uptobox.com/api/user/pin/validate?token=%s' % token
                data = httptools.downloadpage(_url, post='{"pin": "%s"}' % pin[0]).data
                if "Require an authenticated user" in data:
                    _url = 'https://uptobox.com/api/user/pin/validate?token=%s' % _getToken(True)(1)
                    data = httptools.downloadpage(_url, post='{"pin": "%s"}' % pin[0]).data

                data = httptools.downloadpage(check_url).data
                js_data = jsontools.load_json(data)['data']

                subtitles = list()
                for s in js_data.get('subs', []):
                    subtitles.append(s['src'])

                for res, v in js_data['streamLinks'].items():
                    for l, scr in v.items():
                        label = "Ver el video: %s[%sp]" % (lng.get(l[:3], ''), res)
                        itemlist.append(
                            Video(label=label, url=scr, res=res, subtitles=subtitles))

        else:
            data = httptools.downloadpage(
                'https://uptostream.com/api/streaming/source/get?token=null&file_code=' + id).data
            matches = re.compile("(var \w+\s*=\s*\[.*?\];\(function\(.*?)\\n").findall(data)
            if not matches:
                matches = re.compile("(var \w+\s*=\s*\[.*?\];\(function\(.*)$").findall(data)

            if not matches:
                logger.debug('Not detected 1')
                raise()

            net = EstructuraInicial(matches[0])
            if not net.detectado:
                logger.debug('Not detected 2')
                raise ()

            data = net.data
            data = _uptostream_sumes(data)

            for i in list(range(10)):
                ant = data
                matches = re.findall('(var (\w+)=\{(.*?)\};)', data, re.DOTALL)
                for tot, func, codi in matches:
                    data = _uptostream_valors_directes(func, codi, data)
                    data = _uptostream_funcio_simple(func, codi, data)
                    data = _uptostream_funcio_doble(func, codi, data)
                    if func + '[' not in data:
                        data = data.replace(tot, '')

                data = _uptostream_ifs_fake(data)
                if ant == data: break

        for i in list(range(10)):
            ant = data
            data = _uptostream_funcions(data)
            data = _uptostream_sumes(data)
            if ant == data: break

        resolucion = _uptostream_pilla_valor(data, 'res')
        lang = _uptostream_pilla_valor(data, 'lang')
        for i, url in enumerate(_uptostream_pilla_valor(data, 'src')):
            res = resolucion[i] if i < len(resolucion) else 'MP4'
            l = lang[i] if i < len(lang) else None
            if not l or 'unknown' in l:
                l = 'unk'

            label = "Ver el video: %s[%sp]" % (lng.get(l[:3],"Desconocido"), res)

            itemlist.append(Video(label=label, res=res, url=url.replace(chr(92), '')))
        # </protect>
    except Exception as e:
        return ResolveError(e)

    return itemlist

