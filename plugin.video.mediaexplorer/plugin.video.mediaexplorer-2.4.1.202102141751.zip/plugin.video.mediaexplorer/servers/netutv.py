# -*- coding: utf-8 -*-
from core.libs import *
from core.js import JS


def get_video_url(item):
    logger.trace()
    itemlist = []

    domain = urllib_parse.urlparse(item.url)[1]

    yield ResolveProgress(20, 0)
    data = httptools.downloadpage(item.url).data
    videokey = scrapertools.find_single_match(data, 'videokeyorig = "([^"]+)"')

    if not httptools.get_cookies(domain).get('gt'):
        yield ResolveProgress(30, 4)
        token = platformtools.show_recaptcha(
            "https://%s" % domain,
            "6Ldf5F0UAAAAALErn6bLEcv7JldhivPzb93Oy5t9",
            "watch_video"
        )
    else:
        token = ""

    yield ResolveProgress(40, 0)

    values = scrapertools.find_single_match(
        data,
        r'([^\s]+) = null;\s*}\s*(.*?)\n'
    )
    shh_hidden = values[1]
    shh_hidden = re.sub(r"\([^']+\) \['[^']+'] \( \(", 'python.sendResponse((', shh_hidden, flags=re.DOTALL)
    shh_hidden = re.sub(r"\('[^']+'\);", r';', shh_hidden, flags=re.UNICODE)
    js_code = JS().run_js(shh_hidden)
    shh = scrapertools.find_single_match(js_code, r"%s\('([^']+)'\)" % values[0])

    data = httptools.downloadpage(
        'https://%s/player/get_md5.php?sh=%s&ver=4&secure=0&adb=0/&v=%s&'
        'token=%s&gt=&embed_from=0&wasmcheck=1' % (
            domain,
            shh,
            videokey,
            token,
        ),
        headers={
            'Accept': '*/*',
        }).data

    json_data = jsontools.load_json(data)
    if 'obf_link' not in json_data:
        yield ResolveError(6)
        return

    yield ResolveProgress(60, 2)
    url = un(json_data['obf_link'])
    itemlist.append(Video(url=url, headers={'Accept': '*/*'}))

    yield itemlist


def un(link):
    from six import unichr
    s2 = ''
    for i in range(1, len(link), 3):
        s2 += unichr(int(link[i:i + 3], 16))

    return 'https:' + s2 + '.mp4.m3u8'
