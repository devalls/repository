# -*- coding: utf-8 -*-
from core.libs import *
import unicodedata

LNG = Languages({
    Languages.es: ['es']
})

QLT = Qualities({
    Qualities.hd_full: ['fullhd', 'microhd'],
    Qualities.uhd: ['cuatrok'],
    Qualities.m3d: ['tresd']
})


magnet = 'magnet:?xt=urn:btih:'


def mainlist(item):
    logger.trace()
    itemlist = list()

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        thumb='thumb/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label="Películas aleatorias",
        action="movies",
        content_type='movies',
        type="item",
        group=True,
        url='https://raw.githubusercontent.com/darkozma/tacones/main/nuevo'
    ))

    itemlist.append(item.clone(
        label="Películas por orden alfabético",
        action="movies",
        content_type='movies',
        type="item",
        group=True,
        url='https://raw.githubusercontent.com/darkozma/tacones/main/nuevo'
    ))

    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        content_type='movies'
    ))

    return itemlist


@LimitResults
def movies(item):
    logger.trace()
    itemlist = list()
    
    if item.label == "Películas aleatorias":
        alea = "PA" 
    else:
        alea = "NO"
    
    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<microhd>([^<]+)</.*?<fullhd>([^<]+)</.*?<tresd>([^<]+)<' \
             r'/.*?<cuatrok>([^<]+)</.*?<thumbnail>([^<]+)</.*?<fanart>([^<]+)</.*?<date>([^<]+)<' \
             r'/.*?<info>([^<]+)</'
    
    for title, cal1, cal2, cal3, cal4, poster, fanart, year, plot in scrapertools.find_multiple_matches(data, patron):
        if cal1 != 'NA':
            cal = 'microhd'
            uri = cal1
        elif cal1 == 'NA' and cal2 != 'NA':
            cal = 'fullhd'
            uri = cal2
        elif cal1 == 'NA' and cal2 == 'NA' and cal3 != 'NA':
            cal = 'tresd'
            uri = cal3
        elif cal1 == 'NA' and cal2 == 'NA' and cal3 == 'NA' and cal4 != 'NA':
            cal = 'cuatrok'
            uri = cal4
        
        title = normalizar(title)
        
        if alea == "PA":
            item.alea = "PA"
        lang = LNG.get('es')

        itemlist.append(item.clone(
            title=title,
            url=magnet + uri,
            type='movie',
            poster=poster,
            fanart=fanart,
            plot=plot,
            lang=lang,
            year=year,
            action='findvideos',
            quality=QLT.get(cal)
        ))

    return sorted(itemlist) if item.alea == "PA" else itemlist


def normalizar(t):

    t = t.title()
    
    t = re.sub(r"ÑA", "ña", t)
    t = re.sub(r"ÑE", "ñe", t)
    t = re.sub(r"ÑI", "ñi", t)
    t = re.sub(r"ÑO", "ño", t)
    t = re.sub(r"ÑU", "ñu", t)

    return t


def search(item):
    logger.trace()
    itemlist = list()

    url = 'https://raw.githubusercontent.com/darkozma/tacones/main/nuevo'
    data = httptools.downloadpage(url).data
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<microhd>([^<]+)</.*?<fullhd>([^<]+)</.*?<tresd>([^<]+)<' \
             r'/.*?<cuatrok>([^<]+)</.*?<thumbnail>([^<]+)</.*?<fanart>([^<]+)</.*?<date>([^<]+)<' \
             r'/.*?<info>([^<]+)</'
    
    for title, cal1, cal2, cal3, cal4, poster, fanart, year, plot in scrapertools.find_multiple_matches(data, patron):
        if cal1 != 'NA':
            cal = 'microhd'
            uri = cal1
        elif cal1 == 'NA' and cal2 != 'NA':
            cal = 'fullhd'
            uri = cal2
        elif cal1 == 'NA' and cal2 == 'NA' and cal3 != 'NA':
            cal = 'tresd'
            uri = cal3
        elif cal1 == 'NA' and cal2 == 'NA' and cal3 == 'NA' and cal4 != 'NA':
            cal = 'cuatrok'
            uri = cal4

        title = normalizar(title)
        
        if item.query.lower() in title.lower():
            itemlist.append(item.clone(
                title=title,
                url=magnet + uri,
                type='movie',
                poster=poster,
                fanart=fanart,
                plot=plot,
                lang=LNG.get('es'),
                year=year,
                action='findvideos',
                quality=QLT.get(cal)
            ))

    return itemlist


def findvideos(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="play",
        url=item.url,
        quality=item.quality,
        poster=item.poster,
        type='server',
        server='torrent'
    ))

    return servertools.get_servers_from_id(itemlist)

