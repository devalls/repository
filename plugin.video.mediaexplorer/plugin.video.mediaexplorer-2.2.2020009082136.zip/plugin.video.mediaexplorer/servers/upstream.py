# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    if 'Video is processing now.' in data:
        return ResolveError(1)

    sources = scrapertools.find_single_match(data, r'sources:([^\]]+)')

    for url, res in scrapertools.find_multiple_matches(sources, 'file:"([^"]+)",label:"([^"]+)"'):
        itemlist.append(Video(url=url,res=res))

    return itemlist
