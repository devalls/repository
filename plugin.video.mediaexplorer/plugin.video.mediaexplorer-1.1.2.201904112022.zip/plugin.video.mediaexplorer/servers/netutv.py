# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    import random
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
    data = jswise(scrapertools.find_single_match(data, "<script>\s*;?(eval.*?)</script>"))
    url = scrapertools.find_single_match(data, 'self\.location\.replace\("([^)]+)\)')

    rand = str(random.random())[2:]
    data= httptools.downloadpage('http://hqq.watch/player/ip.php?type=json&rand=%s' % rand).data
    data_ip= scrapertools.find_single_match(data, '"ip":"([^"]+)"')
    url = url.replace('"+rand+"', rand).replace('"+data.ip+"', data_ip).replace('"+need_captcha+"', '0').replace('"+token', '')

    headers = {"User-Agent": 'Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/533.4 (KHTML, like Gecko) '
                             'Chrome/5.0.375.127 Large Screen Safari/533.4 GoogleTV/162671'}
    data = httptools.downloadpage('http://hqq.watch' + url, headers=headers).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
    js_wise = jswise(scrapertools.find_single_match(data, "<script>\s*;?(eval.*?)</script>"))

    variables = {k: v for (k, v) in scrapertools.find_multiple_matches(js_wise, 'var ([^\W]+)\s?=\s?"([^"]+)"')}

    data = urllib.unquote(
        ''.join(scrapertools.find_multiple_matches(data, 'document.write\(unescape\("([^"]+)"')))

    # No probado: No he encontrado ningun enlace con subtitulos
    subtitle = scrapertools.find_single_match(data, 'value="sublangs=Spanish.*?sub=([^&]+)&') or \
               scrapertools.find_single_match(data, 'value="sublangs=English.*?sub=([^&]+)&')

    params = {
        'ver': 2,
        'b':1,
        'vid': scrapertools.find_single_match(data, '&vid="\+encodeURIComponent\("([^"]+)'),
        'adb': 0,
        'at': scrapertools.find_single_match(data, 'var at = "([^"]+)"'),
        'ext': '.mp4.m3u8',
        'link_1': variables.get(scrapertools.find_single_match(data, '&link_1="\+encodeURIComponent\(([^\W]+)')),
        'server_2': variables.get(scrapertools.find_single_match(data, '&server_2="\+encodeURIComponent\(([^\W]+)'))
    }
    link_m3u8 = "https://hqq.watch/player/get_md5.php?%s" % urllib.urlencode(params)

    itemlist.append(Video(url=link_m3u8, subtitle=subtitle))

    return itemlist


def jswise(wise):
    def js_wise(wise):
        w, i, s, e = wise

        v0 = 0
        v1 = 0
        v2 = 0
        v3 = []
        v4 = []

        while True:
            if v0 < 5:
                v4.append(w[v0])
            elif v0 < len(w):
                v3.append(w[v0])
            v0 += 1
            if v1 < 5:
                v4.append(i[v1])
            elif v1 < len(i):
                v3.append(i[v1])
            v1 += 1
            if v2 < 5:
                v4.append(s[v2])
            elif v2 < len(s):
                v3.append(s[v2])
            v2 += 1
            if len(w) + len(i) + len(s) + len(e) == len(v3) + len(v4) + len(e): break

        v5 = "".join(v3)
        v6 = "".join(v4)
        v1 = 0
        v7 = []

        for v0 in range(0, len(v3), 2):
            v8 = -1
            if ord(v6[v1]) % 2: v8 = 1
            v7.append(chr(int(v5[v0:v0 + 2], 36) - v8))
            v1 += 1
            if v1 >= len(v4): v1 = 0
        return "".join(v7)

    ## loop2unobfuscated
    ret = None
    while True:
        wise = re.search("var\s.+?\('([^']+)','([^']+)','([^']+)','([^']+)'\)", wise, re.DOTALL)
        if not wise: break
        ret = wise = js_wise(wise.groups())
    return ret
