# -*- coding: utf-8 -*-
from core.libs import *

from core.cloudflare import Cloudflare
from lib.dns.resolver import Resolver

from io import BytesIO
import gzip
import inspect
import hashlib
import ssl
import struct

from six.moves import queue
from six.moves.http_cookiejar import MozillaCookieJar
from six.moves.http_cookiejar import Cookie
from six.moves.html_parser import HTMLParser
from six.moves.urllib_error import HTTPError
from six.moves import urllib_request
from six.moves import http_client
from six.moves import urllib_response
from distutils.version import LooseVersion

proxies_fault = list()

cookies_lock = Lock()
cj = MozillaCookieJar()
cookies_path = os.path.join(sysinfo.data_path, "cookies.dat")

# Headers por defecto, si no se especifica nada
default_headers = dict()
default_headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0"
default_headers["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
default_headers["Accept-Language"] = "es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3"
default_headers["Accept-Encoding"] = "gzip"
default_headers["Accept-Charset"] = "UTF-8"
default_headers["Upgrade-Insecure-Requests"] = '1'

# No comprobar certificados
if hasattr(ssl, '_create_unverified_context'):
    ssl._create_default_https_context = getattr(ssl, '_create_unverified_context')


def get_cloudflare_headers(url):
    """
    Añade los headers para cloudflare
    :param url: Url
    :type url: str
    """
    domain_cookies = getattr(cj, '_cookies').get("." + urllib_parse.urlparse(url)[1], {}).get("/", {})

    if "cf_clearance" not in domain_cookies:
        return url

    headers = dict()
    headers["User-Agent"] = default_headers["User-Agent"]
    headers["Cookie"] = "; ".join(["%s=%s" % (c.name, c.value) for c in domain_cookies.values()])

    return url + '|%s' % '&'.join(['%s=%s' % (k, v) for k, v in headers.items()])


def load_cookies():
    """
    Carga el fichero de cookies
    """
    cookies_lock.acquire()

    if os.path.isfile(cookies_path):
        try:
            cj.load(cookies_path, ignore_discard=True)
        except Exception:
            logger.info("El fichero de cookies existe pero es ilegible, se borra")
            os.remove(cookies_path)

    cookies_lock.release()


def save_cookies():
    """
    Guarda las cookies
    """
    cookies_lock.acquire()
    cj.save(cookies_path, ignore_discard=True)
    cookies_lock.release()


def get_cookies(domain):
    cookies = dict((c.name, c.value) for c in getattr(cj, '_cookies').get(domain, {}).get("/", {}).values())
    cookies.update(dict((c.name, c.value) for c in getattr(cj, '_cookies').get("." + domain, {}).get("/", {}).values()))
    return cookies


def downloadpage(url, post=None, headers=None, timeout=None, follow_redirects=True, cookies=True, replace_headers=False,
                 add_referer=False, only_headers=False, bypass_cloudflare=True, bypass_testcookie=True, no_decode=False,
                 use_proxy=False, method=None):
    """
    Descarga una página web y devuelve los resultados
    :type url: str
    :type post: dict, str
    :type headers: dict, list
    :type timeout: int
    :type follow_redirects: bool
    :type cookies: bool, dict
    :type replace_headers: bool
    :type add_referer: bool
    :type only_headers: bool
    :type bypass_cloudflare: bool
    :type bypass_testcookie: bool
    :type no_decode: bool
    :type use_proxy: bool or str (IP:PORT)
    :type method: str
    :return: Resultado
    """
    logger.trace()
    arguments = locals().copy()

    # La url no contiene host
    if urllib_parse.urlparse(url)[0:2] == ('', ''):
        stack = inspect.stack()
        module = None
        for x in stack:
            if x[3] == 'downloadpage':
                continue
            module = x[1]
            break
        host = moduletools.get_channel_host(module)

        if not host:
            return HTTPResponse({
                'sucess': False,
                'code': '',
                'error': 'Ningún host funciona',
                'headers': {},
                'cookies': {},
                'data': '',
                'time': 0,
                'url': ''
            })

        kwargs = arguments.copy()
        kwargs['url'] = host + arguments['url']

        res = downloadpage(**kwargs)

        # La url no se puede cargar
        if not res.sucess:
            if settings.get_setting('host', module) == 0:  # Modo automatico: Volvemos a buscar
                settings.set_setting('aut_host', None, module)
                return downloadpage(**arguments)
            else:  # Modo manual: Mostramos aviso para cambio de servidor
                platformtools.dialog_ok(
                    moduletools.get_module_parameters(module)['name'],
                    "No se puede conectar con %s\n"
                    "Su proveedor de internet puede estar bloqueando la conexión\n"
                    "Elije otro domino en la configuración y vuelve a intentarlo" % host,

                )
        return res

    response = {}

    # Post tipo dict
    if type(post) == dict:
        post = urllib_parse.urlencode(post)

    # Url quote
    url = urllib_parse.quote(url, safe="%/:=&?~#+!$,;'@()*[]")

    # Headers por defecto, si no se especifica nada
    request_headers = default_headers.copy()

    # Headers pasados como parametros
    if headers is not None:
        if not replace_headers:
            request_headers.update(dict(headers))
        else:
            request_headers = dict(headers)

    # Referer
    if add_referer:
        request_headers["Referer"] = "/".join(url.split("/")[:3])

    logger.info("Headers:")
    logger.info(request_headers)

    # Handlers
    handlers = list()
    handlers.append(HTTPHandler(debuglevel=False))
    handlers.append(HTTPSHandler(debuglevel=False))

    # No redirects
    if not follow_redirects:
        handlers.append(NoRedirectHandler())
    else:
        handlers.append(HTTPRedirectHandler())

    # Dict con cookies para la sesión
    if type(cookies) == dict:
        for name, value in cookies.items():
            if not type(value) == dict:
                value = {'value': value}
            ck = Cookie(
                version=0,
                name=name,
                value=value.get('value', ''),
                port=None,
                port_specified=False,
                domain=value.get('domain', urllib_parse.urlparse(url)[1]),
                domain_specified=False,
                domain_initial_dot=False,
                path=value.get('path', '/'),
                path_specified=True,
                secure=False,
                expires=value.get('expires', time.time() + 3600 * 24),
                discard=True,
                comment=None,
                comment_url=None,
                rest={'HttpOnly': None},
                rfc2109=False
            )
            cj.set_cookie(ck)

    if cookies:
        handlers.append(urllib_request.HTTPCookieProcessor(cj))

    # Proxy
    if settings.get_setting('proxy_mode', __file__) == 2:  # Siempre
        if not use_proxy and 'search_proxies' not in [a[3] for a in inspect.stack()[1:]]:
            use_proxy = True

    elif settings.get_setting('proxy_mode', __file__) == 0:  # Nunca
        use_proxy = False

    elif settings.get_setting('proxy_mode', __file__) == 1:  # Solo modulos activados
        if not use_proxy:
            stack = inspect.stack()
            module = None
            for x in stack:
                if x[3] == 'downloadpage':
                    continue
                module = x[1]
                break
            use_proxy = is_proxy_enabled(module)

    if use_proxy:
        proxy_aut = settings.get_setting('proxy_aut', __file__)
        proxy_man = settings.get_setting('proxy_man', __file__)

        if isinstance(use_proxy, str):
            # uso del proxy forzado
            logger.info('Usando proxy: %s' % use_proxy)
            handlers.extend(ProxyHandler(use_proxy, 0))

        elif settings.get_setting('proxy_tipo', __file__) != 1:
            # seleccion del proxy manual
            logger.info('Usando proxy: %s' % proxy_man)
            handlers.extend(ProxyHandler(proxy_man, settings.get_setting('proxy_man_type', __file__)))

        elif proxy_aut:
            # seleccion del proxy automatica: prefijado
            logger.info('Usando proxy: %s' % proxy_aut)
            handlers.extend(ProxyHandler(proxy_aut, 0))

        else:
            # seleccion del proxy automatica: busqueda
            proxy_aut = search_proxies()
            if proxy_aut:
                logger.info('Usando proxy: %s' % proxy_aut)
                handlers.extend(ProxyHandler(proxy_aut, 0))
            else:
                use_proxy = False

    # Opener
    opener = urllib_request.build_opener(*handlers)

    # Contador
    inicio = time.time()

    # Request
    req = Request(url, six.ensure_binary(post) if post else None, request_headers, method=method)

    try:
        logger.info("Realizando Peticion")
        handle = opener.open(req, timeout=timeout)
        logger.info('Peticion realizada')

    except HTTPError as handle:
        logger.info('Peticion realizada con error')
        response["sucess"] = False
        response["code"] = handle.code
        response["error"] = handle.__dict__.get("reason", str(handle))
        response["headers"] = dict(handle.headers.items())
        response['cookies'] = get_cookies(urllib_parse.urlparse(url)[1])
        if not only_headers:
            logger.info('Descargando datos...')
            response["data"] = handle.read()
        else:
            response["data"] = b""
        response["time"] = time.time() - inicio
        response["url"] = handle.geturl()

    except Exception as e:
        logger.info('Peticion NO realizada')
        response["sucess"] = False
        response["code"] = e.__dict__.get("errno", e.__dict__.get("code", str(e)))
        response["error"] = e.__dict__.get("reason", str(e))
        response["headers"] = {}
        response['cookies'] = get_cookies(urllib_parse.urlparse(url)[1])
        response["data"] = b""
        response["time"] = time.time() - inicio
        response["url"] = url

    else:
        response["sucess"] = True
        response["code"] = handle.code
        response["error"] = None
        response["headers"] = dict(handle.headers.items())
        response['cookies'] = get_cookies(urllib_parse.urlparse(url)[1])
        if not only_headers:
            logger.info('Descargando datos...')
            response["data"] = handle.read()
        else:
            response["data"] = b""
        response["time"] = time.time() - inicio
        response["url"] = handle.geturl()

    response['headers'] = dict([(k.lower(), v) for k, v in response['headers'].items()])

    logger.info("Terminado en %.2f segundos" % (response["time"]))
    logger.info("Response sucess     : %s" % (response["sucess"]))
    logger.info("Response code       : %s" % (response["code"]))
    logger.info("Response error      : %s" % (response["error"]))
    logger.info("Response data length: %s" % (len(response["data"])))
    logger.info("Response headers:")
    logger.info(response['headers'])

    # Guardamos las cookies
    if cookies:
        save_cookies()

    # Gzip
    if response["headers"].get('content-encoding') == 'gzip':
        response["data"] = gzip.GzipFile(fileobj=BytesIO(response["data"])).read()

    # Binarios no se codifican ni se comprueba cloudflare, etc...
    if not is_binary(response):
        response['data'] = six.ensure_str(response['data'], errors='replace')

        if not no_decode:
            response["data"] = six.ensure_str(HTMLParser().unescape(
                six.ensure_text(response['data'], errors='replace')
            ))

        # Anti TestCookie
        if bypass_testcookie:
            if 'document.cookie="__test="+toHex(slowAES.decrypt(c,2,a,b))+"' in response['data']:
                a = scrapertools.find_single_match(response['data'], r'a=toNumbers\("([^"]+)"\)').decode("HEX")
                b = scrapertools.find_single_match(response['data'], r'b=toNumbers\("([^"]+)"\)').decode("HEX")
                c = scrapertools.find_single_match(response['data'], r'c=toNumbers\("([^"]+)"\)').decode("HEX")
                arguments['bypass_testcookie'] = False
                if not type(arguments['cookies']) == dict:
                    arguments['cookies'] = {'__test': aes.AESModeOfOperationCBC(a, b).decrypt(c).encode("HEX")}
                else:
                    arguments['cookies']['__test'] = aes.AESModeOfOperationCBC(a, b).decrypt(c).encode("HEX")
                response = downloadpage(**arguments).__dict__

        # Anti Cloudflare
        if bypass_cloudflare:
            response = retry_if_cloudflare(response, arguments)

    # Proxy Retry
    if use_proxy:
        response = retry_if_proxy_error(response, arguments)

    return HTTPResponse(response)


def is_binary(response):
    logger.trace()

    text_content_types = [
        'text/html',
        'application/json',
        'text/javascript'
    ]
    content_type = response['headers'].get('content-type', '')

    if 'charset' in content_type:
        charset = response['headers']['content-type'].split('=')[1]
        if charset.lower() != 'utf-8':
            response['data'] = response['data'].decode(charset, errors='replace')
        return False

    content_type = content_type.split(' ')[0]
    if content_type in text_content_types:
        return False

    if isinstance(response['data'], six.binary_type):
        try:
            response['data'].decode('utf8')
        except UnicodeDecodeError:
            return True
        else:
            return False

    if isinstance(response['data'], six.text_type):
        return False

    if '\0' not in response['data']:
        return False

    return True


def retry_if_cloudflare(response, args):
    def clear_cookies():
        cf_cookies = getattr(cj, '_cookies').get('.' + urllib_parse.urlparse(args['url'])[1], {}).get('/', {})
        cf_cookies.pop('__cfduid', None)
        cf_cookies.pop('cf_clearance', None)
        cf_cookies.pop('__cf_bm', None)
        save_cookies()

    cf = Cloudflare(response)
    if cf.is_cloudflare:
        logger.info("cloudflare detectado, esperando %s segundos..." % cf.wait_time)
        clear_cookies()
        auth_url, post = cf.get_url()
        logger.info("Autorizando... url: %s" % auth_url)
        auth_args = args.copy()
        auth_args['url'] = auth_url
        auth_args['follow_redirects'] = False
        auth_args['bypass_cloudflare'] = False
        if not isinstance(auth_args['headers'], dict):
            auth_args['headers'] = {}
        auth_args['headers']['Referer'] = args['url']
        auth_args['post'] = post
        resp = downloadpage(**auth_args)
        if resp.sucess and 'cf_clearance' in resp.cookies:
            logger.info("Autorización correcta, descargando página")
            args['bypass_cloudflare'] = False
            return downloadpage(**args).__dict__
        elif resp.code == 403 and resp.headers.get('cf-chl-bypass'):
            logger.info('cloudflare solicita captcha...')
            if [a[3] for a in inspect.stack()].count('retry_if_cloudflare') > 1:
                logger.info("No se ha podido autorizar. Captcha requerido")
                return response
            logger.info("Reintentando...")
            # Eliminamos cookies
            clear_cookies()
            return downloadpage(**args).__dict__
        else:
            logger.info("No se ha podido autorizar")
    return response


def retry_if_proxy_error(response, args):
    # Evitar comprobaciones recurrentes
    if 'test_proxy' in [a[3] for a in inspect.stack()[1:]]:
        return response

    if not response['sucess'] and settings.get_setting('proxy_tipo', __file__) == 1:
        logger.info('La petición no se ha realizado correctamtente, comprobando proxy...')
        if not settings.get_setting('proxy_aut', __file__) or not test_proxy():
            logger.info('El proxy actual no funciona: %s' % settings.get_setting('proxy_aut', __file__))
            if search_proxies(100):
                logger.info('Cambio de proxy automatico: %s' % settings.get_setting('proxy_aut', __file__))
                return downloadpage(**args).__dict__
            else:
                logger.info('No se ha encontrado ningun proxy que funcione')
        else:
            logger.info('El proxy actual funciona correctamente: %s' % settings.get_setting('proxy_aut', __file__))

    return response


def test_proxy(proxy=True, q=None, test_url='https://cloudflare.com'):
    # Probamos el proxy con una url que sepamos que funciona
    ret = httptools.downloadpage(test_url, use_proxy=proxy, timeout=2, only_headers=True).sucess

    if isinstance(q, queue.Queue):
        if ret:
            logger.info('Multihilo: Proxy %s SI funciona' % proxy)
            q.put(proxy)
        else:
            logger.info('Multihilo: Proxy %s NO funciona' % proxy)
            proxies_fault.append(proxy)

    return ret


def search_proxies(limit=None, test_url='https://cloudflare.com'):
    q = queue.Queue()
    ret = None
    threads = list()

    proxy_aut_list = settings.get_setting('proxy_aut_list', __file__) or "proxyscrape.com"
    dialog_background = set([a[1].split(os.sep)[-1][:-2] + a[3] for a in inspect.stack()[1:]]) & {
        'finder.channel_search',
        'newest.channel_search'}

    if dialog_background:
        dialog = platformtools.dialog_progress_bg('MediaExplorer: Buscando proxy', 'Iniciando búsqueda...')
        if not limit or limit > 30:
            limit = 30
    else:
        dialog = platformtools.dialog_progress('MediaExplorer: Buscando proxy', 'Iniciando búsqueda...')

    if proxy_aut_list == 'proxyscrape.com':
        resp = downloadpage(
            'https://api.proxyscrape.com/?request=displayproxies&proxytype=http&timeout=100')
        proxies = resp.data.split()

    elif proxy_aut_list == 'proxy-list.download':
        resp = downloadpage('https://www.proxy-list.download/api/v1/get?type=http')
        proxies = resp.data.split()

    else:  # settings.get_setting('proxy_aut_list', __file__) == 'spys.me'
        resp = downloadpage('http://spys.me/proxy.txt')
        proxies = scrapertools.find_multiple_matches(resp.data, r'(\d+\.\d+\.\d+\.\d+:\d+)')

    proxy_aut = settings.get_setting('proxy_aut', __file__)
    if proxy_aut:
        proxies_fault.append(proxy_aut)

    proxies = list(filter(lambda p: p not in proxies_fault, proxies))[:limit]

    for x in range(0, len(proxies), 10):
        if not ret:
            for proxy in proxies[x:x + 10]:
                t = Thread(target=test_proxy, args=(proxy, q, test_url))
                t.daemon = True
                t.start()
                threads.append(t)

                if not dialog_background and dialog.iscanceled():
                    dialog.close()
                    return ret

            dialog.update(int((x + 1) * 100 / len(proxies)),
                          'Buscando proxy en %s,\n'
                          'Comprobando proxy del %s al %s de %s' % (proxy_aut_list, x + 1, x + 10, len(proxies)))

            while [t for t in threads if t.isAlive()]:
                try:
                    ret = q.get(True, 1)
                    settings.set_setting('proxy_aut', ret, __file__)
                    break
                except queue.Empty:
                    if not dialog_background and dialog.iscanceled():
                        dialog.close()
                        return ret

    dialog.close()
    return ret


def Resolve(host, socks4=False):
    dnsmode = settings.get_setting('dns_mode', __file__)

    if validate_ip(host):  # IPs
        return host

    my_resolver = Resolver()
    cache_path = os.path.join(sysinfo.data_path, 'dnscache.json')
    encoded_host = hashlib.md5(six.ensure_binary(host)).hexdigest()

    if socks4 and not settings.get_setting('dns_proxy', __file__):
        # Socks4 requiere resolver la IP aqui, si dns_proxy = 0 se utilizan las dns del sistema por defecto
        # TODO: Parece que en android no obtiene las dns del sistema, por ahora usamos las de google.
        if my_resolver.nameservers == ['127.0.0.1']:
            my_resolver.nameservers = ['8.8.8.8', '8.8.4.4']

    elif dnsmode == 1:  # Cloudflare
        my_resolver.nameservers = ['1.1.1.1', '1.0.0.1']

    elif dnsmode == 2:  # Google
        my_resolver.nameservers = ['8.8.8.8', '8.8.4.4']

    elif dnsmode == 3:  # Personal
        primary = settings.get_setting('primary_dns', __file__)
        secondary = settings.get_setting('secondary_dns', __file__)
        dns = [primary]
        if secondary:
            dns.append(secondary)
        my_resolver.nameservers = dns

    try:
        dnscache = jsontools.load_file(cache_path)
        if dnscache.get('servers', '') != ', '.join(my_resolver.nameservers):
            dnscache = {
                'servers': ', '.join(my_resolver.nameservers),
                'records': {}
            }
    except Exception:
        dnscache = {
            'servers': ', '.join(my_resolver.nameservers),
            'records': {}
        }

    if encoded_host not in dnscache['records'] or dnscache['records'][encoded_host]['expires'] < time.time():
        logger.info('Solicitando DNS al servidor')
        response = my_resolver.query(host, 'a')
        dnscache['records'][encoded_host] = {
            'value': [a.to_text() for a in response],
            'expires': response.expiration
        }
        jsontools.dump_file(dnscache, cache_path)

    answer = dnscache['records'][encoded_host]['value']
    logger.info('Resolve: %s -> %s' % (host, answer))
    return answer


class HTTPSHandler(urllib_request.HTTPSHandler):
    def __init__(self, *args, **kwargs):
        urllib_request.HTTPSHandler.__init__(self, *args, **kwargs)

    def https_open(self, req):
        logger.trace()

        cipher_suite = [

            'ECDHE-ECDSA-AES128-GCM-SHA256',
            'ECDHE-RSA-AES128-GCM-SHA256',
            'ECDHE-ECDSA-CHACHA20-POLY1305',
            'ECDHE-RSA-CHACHA20-POLY1305',
            'ECDHE-ECDSA-AES256-GCM-SHA384',
            'ECDHE-RSA-AES256-GCM-SHA384',
            'ECDHE-ECDSA-AES256-SHA',
            'ECDHE-ECDSA-AES128-SHA',
            'ECDHE-RSA-AES256-SHA',
            'ECDH-ECDSA-AES128-GCM-SHA256',
            'ECDH-ECDSA-AES128-SHA',
            'ECDH-ECDSA-AES128-SHA256',
            'ECDH-ECDSA-AES256-GCM-SHA384',
            'ECDH-ECDSA-AES256-SHA',
            'ECDH-ECDSA-AES256-SHA384',
            'ECDH-ECDSA-DES-CBC3-SHA',
            'ECDH-ECDSA-RC4-SHA',
            'ECDH-RSA-AES128-GCM-SHA256',
            'ECDH-RSA-AES128-SHA',
            'ECDH-RSA-AES128-SHA256',
            'ECDH-RSA-AES256-GCM-SHA384',
            'ECDH-RSA-AES256-SHA',
            'ECDH-RSA-AES256-SHA384',
            'ECDH-RSA-DES-CBC3-SHA',
            'ECDH-RSA-RC4-SHA',
            'DES-CBC3-SHA',
            'DHE-DSS-AES128-GCM-SHA256',
            'DHE-DSS-AES128-SHA',
            'DHE-DSS-AES128-SHA256',
            'DHE-DSS-AES256-GCM-SHA384',
            'DHE-DSS-AES256-SHA',
            'DHE-DSS-AES256-SHA256',
            'DHE-DSS-CAMELLIA128-SHA',
            'DHE-DSS-CAMELLIA256-SHA',
            'DHE-DSS-SEED-SHA',
            'DHE-RSA-AES128-GCM-SHA256',
            'DHE-RSA-AES128-SHA256',
            'DHE-RSA-AES256-GCM-SHA384',
            'DHE-RSA-AES256-SHA256',
            'DHE-RSA-AES128-SHA',
            'DHE-RSA-AES256-SHA',
        ]

        context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
        context.set_ciphers(':'.join(cipher_suite))

        if six.PY3 and LooseVersion('.'.join(str(a) for a in ssl.OPENSSL_VERSION_INFO[:3])) < LooseVersion('1.1.1'):
            context.set_alpn_protocols(['http/1.1'])
        context.options |= (ssl.OP_NO_SSLv2 | ssl.OP_NO_SSLv3 | ssl.OP_NO_TLSv1 | ssl.OP_NO_TLSv1_1)

        return self.do_open(HTTPSConnection, req, context=context)


class HTTPSConnection(http_client.HTTPSConnection):
    def connect(self):
        if settings.get_setting('dns_mode', __file__):
            host = Resolve(self.host)
        else:
            host = self.host

        if isinstance(host, six.string_types):
            setattr(self, 'sock', self._create_connection((host, self.port), self.timeout, self.source_address))
        else:
            for h in host:
                try:
                    setattr(self, 'sock', self._create_connection((h, self.port), self.timeout, self.source_address))
                except Exception:
                    if host.index(h) == len(host) - 1:
                        raise
                else:
                    break

        if self._tunnel_host:
            server_hostname = self._tunnel_host
            if settings.get_setting('dns_proxy', __file__):  # Resolver DNS Local
                tunnel_host = Resolve(self._tunnel_host)
                if not isinstance(tunnel_host, six.string_types):
                    tunnel_host = tunnel_host[0]
                setattr(self, '_tunnel_host', tunnel_host)
            self._tunnel()
        else:
            server_hostname = self.host

        setattr(self, 'sock', self._context.wrap_socket(self.sock, server_hostname=server_hostname))


class HTTPHandler(urllib_request.HTTPHandler):
    def http_open(self, req):
        logger.trace()
        return self.do_open(HTTPConnection, req)


class HTTPConnection(http_client.HTTPConnection):
    def connect(self):
        if settings.get_setting('dns_mode', __file__):
            host = Resolve(self.host)
        else:
            host = self.host

        if isinstance(host, six.string_types):
            setattr(self, 'sock', self._create_connection((host, self.port), self.timeout, self.source_address))
        else:
            for h in host:
                try:
                    setattr(self, 'sock', self._create_connection((h, self.port), self.timeout, self.source_address))
                except Exception:
                    if host.index(h) == len(host) - 1:
                        raise
                else:
                    break

        if self._tunnel_host:
            if settings.get_setting('dns_proxy', __file__):  # Resolver DNS Local
                tunnel_host = Resolve(self._tunnel_host)
                if not isinstance(tunnel_host, six.string_types):
                    tunnel_host = tunnel_host[0]
                setattr(self, '_tunnel_host', tunnel_host)
            self._tunnel()

    def _send_request(self, *args, **kwargs):
        from collections import OrderedDict
        order = ["Host", 'User-Agent', 'Accept']
        if len(args) > 3:
            headers = args[3]
        else:
            headers = kwargs['headers']

        headers = OrderedDict([(k, v) for k, v in sorted(
            list(headers.items()),
            key=lambda head: order.index(head[0]) if head[0] in order else len(order),
        )])
        if len(args) > 3:
            args = list(args)
            args[3] = headers
        else:
            kwargs['headers'] = headers
        getattr(http_client.HTTPConnection, '_send_request')(self, *args, **kwargs)


class NoRedirectHandler(urllib_request.HTTPRedirectHandler):
    def __init__(self):
        pass

    def http_error_302(self, req, fp, code, msg, headers):
        infourl = urllib_response.addinfourl(fp, headers, req.get_full_url())
        infourl.status = code
        infourl.code = code
        return infourl

    http_error_300 = http_error_302
    http_error_301 = http_error_302
    http_error_303 = http_error_302
    http_error_307 = http_error_302


class HTTPRedirectHandler(urllib_request.HTTPRedirectHandler):
    def __init__(self):
        pass

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        logger.trace()
        if 'Authorization' in req.headers:
            req.headers.pop('Authorization')
        return urllib_request.HTTPRedirectHandler.redirect_request(self, req, fp, code, msg, headers, newurl)


def ProxyHandler(proxy, proxy_type):
    if proxy_type > 0:
        if proxy_type == 1:
            version = '4'
        elif proxy_type == 2:
            version = '4A'
        else:
            version = '5'
        return [ProxyHTTPHandler(proxy, version), ProxyHTTPSHandler(proxy, version)]
    else:
        return [urllib_request.ProxyHandler({'http': proxy, 'https': proxy})]


class ProxyHTTPHandler(HTTPHandler):
    handler_order = 100

    def __init__(self, proxy, version):
        HTTPHandler.__init__(self, 0)
        self.proxy = proxy
        self.version = version

    def http_open(self, req):
        logger.trace()
        req._tunnel_host = req.host
        req.host = self.proxy
        return self.do_open(ProxyHTTPConnection, req, version=self.version)


class ProxyHTTPSHandler(HTTPSHandler):
    handler_order = 100

    def __init__(self, proxy, version):
        HTTPSHandler.__init__(self, 0)
        self.proxy = proxy
        self.version = version

    def https_open(self, req):
        logger.trace()
        req._tunnel_host = req.host
        req.host = self.proxy
        return self.do_open(ProxyHTTPSConnection, req, version=self.version)


class ProxyConnection:
    @property
    def _tunnel_ip(self):
        ip = self._tunnel_host.split('.')
        return reduce(lambda a, b: int(a) * 256 + int(b), ip)

    def _tunnel(self):
        self._tunnel_host, self._tunnel_port = getattr(self, '_get_hostport')(self._tunnel_host, None)
        return getattr(self, '_socks%s_tunnel' % getattr(self, 'version'))()

    def _authenticate(self):
        assert getattr(self, 'version') == '5'

        auth_methods = [
            0  # NO AUTHENTICATION REQUIRED
        ]

        msg = struct.pack('!B', 5)  # Version
        msg += struct.pack('!B', len(auth_methods))  # lengh
        msg += ''.join(struct.pack('!B', m) for m in auth_methods)  # Auth methods

        getattr(self, 'send')(msg)

        response = getattr(self, 'sock').recv(2)
        assert len(response) == 2

        method = struct.unpack('!B', response[1:2])[0]

        if method == 0:  # No authentication required
            pass
        else:
            raise NotImplementedError('Authentication not implemented')

    def _socks5_tunnel(self):
        logger.trace()
        self._authenticate()

        msg = struct.pack('!B', 5)  # Version
        msg += struct.pack('!B', 1)  # COMMAND: Connect
        msg += struct.pack('!B', 0)  # Reserved
        if not validate_ip(self._tunnel_host):
            msg += struct.pack('!B', 3)  # Type: 1-> IPv4, 3-> Domain, 4-> IPv6
            msg += struct.pack('!B', len(self._tunnel_host))  # Length Host
            msg += self._tunnel_host  # Host
        else:
            msg += struct.pack('!B', 1)  # Type: 1-> IPv4, 3-> Domain, 4-> IPv6
            msg += struct.pack('!I', self._tunnel_ip)  # Host
        msg += struct.pack('!H', self._tunnel_port)  # Port

        getattr(self, 'send')(msg)

        response = getattr(self, 'sock').recv(10)
        cd = struct.unpack('!B', response[1:2])[0]

        if cd == 1:
            raise Exception('General SOCKS server failure')
        elif cd == 2:
            raise Exception('Connection not allowed by ruleset')
        elif cd == 3:
            raise Exception('Network unreachable')
        elif cd == 4:
            raise Exception('Host unreachable')
        elif cd == 5:
            raise Exception('Connection refused')
        elif cd == 6:
            raise Exception('TTL expired')
        elif cd == 7:
            raise Exception('Command not supported')
        elif cd == 8:
            raise Exception('Address type not supported')

    def _socks4_tunnel(self):
        logger.trace()
        if not validate_ip(self._tunnel_host):
            self._tunnel_host = Resolve(self._tunnel_host, True)[0]
        return self._socks4A_tunnel()

    def _socks4A_tunnel(self):
        logger.trace()
        msg = struct.pack('!B', 4)  # Version
        msg += struct.pack('!B', 1)  # COMMAND: Connect
        msg += struct.pack('!H', self._tunnel_port)  # Port
        if not validate_ip(self._tunnel_host):
            msg += struct.pack('!I', 1)  # Invalid IP
            msg += struct.pack('!B', 0)  # NULL
            msg += self._tunnel_host  # Host
            msg += struct.pack('!B', 0)  # NULL
        else:
            msg += struct.pack('!I', self._tunnel_ip)  # Host
            msg += struct.pack('!B', 0)  # NULL

        getattr(self, 'send')(msg)

        response = getattr(self, 'sock').recv(8)
        cd = struct.unpack('!B', response[1:2])[0]

        if cd == 91:
            raise Exception("Request rejected or failed")
        elif cd == 92:
            raise Exception("Request rejected becasue SOCKS server cannot connect to identd on the client")
        elif cd == 93:
            raise Exception("Request rejected because the client program and identd report different user-ids")


class ProxyHTTPConnection(ProxyConnection, HTTPConnection):
    def __init__(self, *args, **kwargs):
        self.version = kwargs.pop('version')
        HTTPConnection.__init__(self, *args, **kwargs)


class ProxyHTTPSConnection(ProxyConnection, HTTPSConnection):
    def __init__(self, *args, **kwargs):
        self.version = kwargs.pop('version')
        HTTPSConnection.__init__(self, *args, **kwargs)


class HTTPResponse:
    def __init__(self, response):
        self.sucess = None
        self.code = None
        self.error = None
        self.headers = None
        self.cookies = None
        self.data = None
        self.time = None
        self.url = None
        self.__dict__ = response


class Request(urllib_request.Request):
    def __init__(self, *args, **kwargs):
        if 'method' in kwargs:
            if kwargs.get('method'):
                self.method = kwargs.pop('method')
            else:
                kwargs.pop('method')

        urllib_request.Request.__init__(self, *args, **kwargs)

    def get_method(self):
        default_method = "POST" if self.data is not None else "GET"
        return getattr(self, 'method', default_method)


def validate_ip(value):
    if not len(scrapertools.find_single_match(value, r'^(\d*)\.(\d*)\.(\d*)\.(\d*)$')) == 4:
        return False
    for part in scrapertools.find_single_match(value, r'^(\d*)\.(\d*)\.(\d*)\.(\d*)$'):
        if int(part) > 255:
            return False
    return True


def validate_ip_port(value):
    if not validate_ip(value.split(":")[0]):
        return False

    if not len(value.split(':')) == 2 or int(scrapertools.find_single_match(value.split(':')[1], r'^(\d*)$')) > 65535:
        return False

    return True


def config(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label='Configuración DNS/Proxy',
        action='dns_proxy',
        description='Permite configurar un servidor DNS y un servidor Proxy para esquivar bloqueos de operadoras'
    ))
    itemlist.append(item.clone(
        label='Canales que usan proxy',
        action='modules_proxy',
        mode='channels',
        description='Elige los canales que usarán proxy en sus conexiónes'
    ))
    itemlist.append(item.clone(
        label='Servidores que usan proxy',
        action='modules_proxy',
        mode='servers',
        description='Elige los servidores que usarán proxy en sus conexiónes'
    ))
    return itemlist


def is_proxy_enabled(module):
    module = "%s.json" % os.path.splitext(module)[0]
    params = moduletools.get_module_parameters(module)
    if not params:
        return False
    saved = settings.get_setting('proxy_modules', __file__) or {}
    return saved.get('/'.join(module.split(os.sep)[-2:]), params.get('proxy', False))


def modules_proxy(item):
    controls = list()

    if item.mode == 'channels':
        modules = moduletools.get_channels()
    else:
        modules = moduletools.get_servers()

    for module in modules:
        controls.append({
            'id': '/'.join((module['path'].split(os.sep)[-2:])),
            'type': 'bool',
            'label': module['name'],
            'default': module.get('proxy', False),
            'value': is_proxy_enabled(module['path'])
        })

    platformtools.show_settings(callback="save_modules_proxy", title=item.label, controls=controls, item=item)
    return item


def save_modules_proxy(item, values):
    saved = settings.get_setting('proxy_modules', __file__) or {}
    saved.update(values)
    settings.set_setting('proxy_modules', saved, __file__)
    return item


def dns_proxy(item):
    platformtools.show_settings(callback="save_config", title=item.label)
    return item


def save_config(item, values):
    logger.trace()

    # Validar DNS
    if values['dns_mode'] == 3:
        if not validate_ip(values['primary_dns']) and not validate_ip(values['secondary_dns']):
            values.pop("dns_mode")
            values.pop('primary_dns')
            values.pop('secondary_dns')
            platformtools.dialog_ok('MediaExplorer', 'Debe especificar servidores DNS correctos')

    # Validar proxy_man
    if values['proxy_mode'] > 0 and values['proxy_tipo'] == 0:
        if not validate_ip_port(values['proxy_man']):
            values.pop("proxy_mode")
            values.pop('proxy_tipo')
            values.pop('proxy_man')
            platformtools.dialog_ok('MediaExplorer', 'Debe especificar un servidor proxy correcto')

    proxy_aut_search_now = values.pop('proxy_aut_search_now') and values["proxy_tipo"] == 1 and values['proxy_mode'] > 0
    settings.set_settings(values, __file__)

    if settings.get_setting('proxy_mode', __file__) > 0 and settings.get_setting('proxy_tipo', __file__) == 0:
        # Test proxy
        mode = settings.get_setting('proxy_mode', __file__)
        settings.set_setting('proxy_mode', 2, __file__)
        if not httptools.downloadpage('https://www.google.es', follow_redirects=False, only_headers=True).sucess:
            platformtools.dialog_ok(
                'MediaExplorer',
                'El proxy configurado parece no funcionar\n'
                'Comprueba la configuración o selecciona otro proxy'
            )
        settings.set_setting('proxy_mode', mode, __file__)

    # Buscar nuevo proxy automatico ahora?
    if proxy_aut_search_now:
        search_proxies()

    return item
