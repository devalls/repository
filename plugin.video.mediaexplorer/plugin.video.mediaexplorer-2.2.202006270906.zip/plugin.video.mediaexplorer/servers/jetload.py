# -*- coding: utf-8 -*-
from core.libs import *
# TODO: Queda desabilitado, obtiene la url correctamente pero por alguna razon no reproduce en kodi, en vlc si
#  ¿problemas con el formato?


def get_video_url(item):
    logger.trace()
    itemlist = list()

    video_id = scrapertools.find_single_match(item.url, '/e/([0-9a-zA-Z]+)')
    token = platformtools.show_recaptcha(item.url, '6Lc90MkUAAAAAOrqIJqt4iXY_fkXb7j3zwgRGtUI', 'secure_url')

    response = httptools.downloadpage(
        "https://jetload.net/jet_secure",
        post=jsontools.dump_json({
            'stream_code': video_id,
            'token': token
        }),
        headers={
            'Content-Type': 'application/json;charset=utf-8'
        },
        timeout=10
    )

    source = jsontools.load_json(response.data)

    logger.debug(source['src']['src'])
    itemlist.append(Video(url=source['src']['src']))

    return itemlist
