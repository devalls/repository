# -*- coding: utf-8 -*-
from core.libs import *


class CaptchaProgress(object):
    def __init__(self, start, estimated, timeout):
        self.start = start
        self.estimated = estimated
        self.timeout = timeout

    @property
    def message(self):
        remaining = 0.0
        if not self.estimated or not self.start:
            if self.start:
                if self.timeout:
                    remaining = self.start + self.timeout - time.time()
                else:
                    remaining = time.time() - self.start
        else:
            remaining = self.estimated - (time.time() - self.start)

        while remaining < 0:
            return 'Esperando...'

        return 'Esperando: %s' % time.strftime('%M:%S', time.gmtime(remaining))

    @property
    def percent(self):
        if self.timeout:
            return min((time.time() - self.start) * 100 / self.timeout, 100)
        elif self.estimated:
            return min((time.time() - self.start) * 100 / self.estimated, 100)
        else:
            return 0


def add_item(itemlist=None):
    """
    Añade un Item nuevo a itemlist si las credenciales o el saldo de la cuenta no son correctos
    :param itemlist: listado de Items
    :return: True si se ha añadido el item, False en caso contrario
    """

    try:
        CaptchaSolver()
    except Exception:
        logger.error()
        if itemlist is not None:
            itemlist.append(Item(
                label='Configura un servicio de solución de reCaptcha para poder continuar',
                type='highlight',
                action='recaptcha',
                channel='settings',
            ))
        return True

    return False


def CaptchaSolver():
    s_list = get_services()
    i = get_active_service()
    if not i:
        raise Exception('Ningún servicio activo')

    service_id = s_list[i - 1]['id']
    service_name = s_list[i - 1]['name']
    module = __import__('recaptcha.services.%s' % service_id, fromlist=['recaptcha.services.%s'])

    if not module.CaptchaSolver().get_balance():
        raise Exception('No hay dinero')

    timeout = [None, 60, 30, 15, 5][settings.get_setting('timeout', __file__)]
    service = module.CaptchaSolver(timeout)
    service.name = service_name

    return service


class BaseSolver(object):
    def __init__(self, timeout=None):
        self.timeout = timeout
        self.start_time = 0
        self.estimated_time = 0
        self.result = None
        self.name = ''
        self.canceled = False

    @property
    def is_timed_out(self):
        if not self.timeout or not self.start_time:
            return False
        return time.time() - self.start_time > self.timeout

    @property
    def remain_time(self):
        return CaptchaProgress(start=self.start_time, estimated=self.estimated_time, timeout=self.timeout)

    def get_balance(self):
        raise NotImplementedError()

    def is_enabled(self):
        raise NotImplementedError()

    def solve_v3(self, site_url, site_key, action):
        raise NotImplementedError()

    def solve_v2(self, site_url, site_key):
        raise NotImplementedError()

    def get_response(self):
        raise NotImplementedError()

    def threaded_response(self):
        try:
            self.get_response()
        except Exception as ex:
            self.result = ex

    def stop(self):
        self.canceled = True

    def solve(self, site_url, site_key, action=None, min_socre=None):
        self.start_time = time.time()
        self.canceled = False
        if action:
            self.solve_v3(site_url, site_key, action, min_socre)
        else:
            self.solve_v2(site_url, site_key)

        t = Thread(target=self.threaded_response)
        t.setDaemon(True)
        t.start()

        while self.result is None and t.isAlive():
            if self.is_timed_out:
                self.result = Exception('Tiempo de espera agotado')
                break
            if self.canceled:
                break
            yield self.remain_time
            time.sleep(1)

        yield self.result


def show_recaptcha(siteurl, sitekey, action=None, min_score=None, silent=False):
    try:
        solver = CaptchaSolver()
    except Exception:
        logger.error()
        platformtools.dialog_notification(
            "MediaExplorer - reCaptcha",
            'Configura un servicio de solución de reCaptcha para poder continuar',
            1,
            6000
        )
    else:
        if not silent:
            dialog = platformtools.dialog_progress('Mediaexplorer - reCaptcha', 'Conectando con %s...' % solver.name)
        else:
            dialog = platformtools.dialog_progress_bg('Mediaexplorer - reCaptcha', 'Conectando con %s...' % solver.name)

        for t in solver.solve(siteurl, sitekey, action, min_score):
            if not silent and dialog.iscanceled():
                solver.stop()

            if isinstance(t, CaptchaProgress):
                if dialog:
                    dialog.update(int(t.percent), 'Conectando con %s...\n%s' % (solver.name, t.message))
            elif isinstance(t, Exception):
                if dialog:
                    dialog.update(100, 'Conectando con %s...\nSe ha producido un error: %s' % (solver.name, t))
                    time.sleep(2)
                    dialog.close()
                return
            else:
                if dialog:
                    if t:
                        dialog.update(100, 'Conectando con %s...\nCompletado' % solver.name)
                        time.sleep(2)
                        dialog.close()
                    else:
                        dialog.update(100, 'Conectando con %s...\nCancelado' % solver.name)
                        time.sleep(2)
                        dialog.close()
                return t


def get_services():
    service_list = []
    for file in os.listdir(os.path.join(sysinfo.runtime_path, 'recaptcha', 'services')):
        if not file.endswith('.json'):
            continue
        try:
            path = os.path.join(sysinfo.runtime_path, 'recaptcha', 'services', file)
            data = jsontools.load_file(path)
            service_list.append({'id': file[:-5], 'name': data['name']})
        except Exception as e:
            logger.error()
            continue
    return service_list


def get_active_service():
    s_list = get_services()
    name = settings.get_setting('service', __file__)
    for s in s_list:
        if s['id'] == name:
            return s_list.index(s) + 1
    return 0


def config(item):
    logger.trace()
    platformtools.show_settings(item=item, callback='save_config', title='Ajustes reCaptcha')


def save_config(item, values):
    s_list = get_services()
    if values['service']:
        values['service'] = s_list[values['service'] - 1]['id']
    else:
        values['service'] = None

    if values['service'] is not None:
        values['hide_items'] = False
        
    settings.set_settings(values, __file__)
