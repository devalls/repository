# -*- coding: utf-8 -*-
import gzip
import ssl
from io import BytesIO

from six.moves import urllib_request
from six.moves.html_parser import HTMLParser
from six.moves.http_cookiejar import Cookie
from six.moves.http_cookiejar import MozillaCookieJar
from six.moves.urllib_error import HTTPError

from core.cloudflare import retry_if_cloudflare
from core.http.request import Request
from core.http.response import HTTPResponse
from core.libs import *
from core.proxytools import retry_if_proxy_error, get_default_handlers, validate_ip_port, validate_ip, \
    retry_with_proxy_if_error

cookies_lock = Lock()
cj = MozillaCookieJar()
cookies_path = os.path.join(sysinfo.data_path, "cookies.dat")

# Headers por defecto, si no se especifica nada
default_headers = dict()
default_headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0"
default_headers["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
default_headers["Accept-Language"] = "es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3"
default_headers["Accept-Encoding"] = "gzip"
default_headers["Accept-Charset"] = "UTF-8"
default_headers["Upgrade-Insecure-Requests"] = '1'

# No comprobar certificados
if hasattr(ssl, '_create_unverified_context'):
    ssl._create_default_https_context = getattr(ssl, '_create_unverified_context')


def load_cookies():
    """
    Carga el fichero de cookies
    """
    cookies_lock.acquire()

    if os.path.isfile(cookies_path):
        try:
            cj.load(cookies_path, ignore_discard=True)
        except Exception:
            logger.info("El fichero de cookies existe pero es ilegible, se borra")
            os.remove(cookies_path)

    cookies_lock.release()


def save_cookies():
    """
    Guarda las cookies
    """
    cookies_lock.acquire()
    cj.save(cookies_path, ignore_discard=True)
    cookies_lock.release()


def get_cookies(domain):
    cookies = dict((c.name, c.value) for c in getattr(cj, '_cookies').get(domain, {}).get("/", {}).values())
    cookies.update(dict((c.name, c.value) for c in getattr(cj, '_cookies').get("." + domain, {}).get("/", {}).values()))
    return cookies


def downloadpage(url, post=None, headers=None, timeout=None, follow_redirects=True, cookies=True, replace_headers=False,
                 add_referer=False, only_headers=False, bypass_cloudflare=True, bypass_testcookie=True, no_decode=False,
                 use_proxy=False, method=None):
    """
    Descarga una página web y devuelve los resultados
    :type url: str
    :type post: dict, str
    :type headers: dict, list
    :type timeout: int
    :type follow_redirects: bool
    :type cookies: bool, dict
    :type replace_headers: bool
    :type add_referer: bool
    :type only_headers: bool
    :type bypass_cloudflare: bool
    :type bypass_testcookie: bool
    :type no_decode: bool
    :type use_proxy: bool or str (IP:PORT)
    :type method: str
    :return: Resultado
    """
    logger.trace()
    arguments = locals().copy()

    # La url no contiene host
    if urllib_parse.urlparse(url)[0:2] == ('', ''):
        stack = inspect.stack()
        module = None
        for x in stack:
            if x[3] == 'downloadpage':
                continue
            module = x[1]
            break
        host = moduletools.get_channel_host(module)

        if not host:
            return HTTPResponse({
                'sucess': False,
                'code': '',
                'error': 'Ningún host funciona',
                'headers': {},
                'cookies': {},
                'data': '',
                'time': 0,
                'url': ''
            })

        kwargs = arguments.copy()
        kwargs['url'] = host + arguments['url']

        res = downloadpage(**kwargs)

        # La url no se puede cargar
        if not res.sucess:
            if settings.get_setting('host', module) == 0:  # Modo automatico: Volvemos a buscar
                settings.set_setting('aut_host', None, module)
                return downloadpage(**arguments)
            else:  # Modo manual: Mostramos aviso para cambio de servidor
                platformtools.dialog_ok(
                    moduletools.get_module_parameters(module)['name'],
                    "No se puede conectar con %s\n"
                    "Su proveedor de internet puede estar bloqueando la conexión\n"
                    "Elije otro domino en la configuración y vuelve a intentarlo" % host,

                )
        return res

    response = {}

    # Post tipo dict
    if type(post) == dict:
        post = urllib_parse.urlencode(post)

    # Url quote
    url = urllib_parse.quote(url, safe="%/:=&?~#+!$,;'@()*[]")

    # Headers por defecto, si no se especifica nada
    request_headers = default_headers.copy()

    # Headers pasados como parametros
    if headers is not None:
        if not replace_headers:
            request_headers.update(dict(headers))
        else:
            request_headers = dict(headers)

    # Referer
    if add_referer:
        request_headers["Referer"] = "/".join(url.split("/")[:3])

    logger.info("Headers:")
    logger.info(request_headers)

    # Dict con cookies para la sesión
    if type(cookies) == dict:
        for name, value in cookies.items():
            if not type(value) == dict:
                value = {'value': value}
            ck = Cookie(
                version=0,
                name=name,
                value=value.get('value', ''),
                port=None,
                port_specified=False,
                domain=value.get('domain', urllib_parse.urlparse(url)[1]),
                domain_specified=False,
                domain_initial_dot=False,
                path=value.get('path', '/'),
                path_specified=True,
                secure=False,
                expires=value.get('expires', time.time() + 3600 * 24),
                discard=True,
                comment=None,
                comment_url=None,
                rest={'HttpOnly': None},
                rfc2109=False
            )
            cj.set_cookie(ck)

    # Proxy: Determina si se debe usar proxy en funcion del parametro use_proxy y de la configuración
    use_proxy = proxytools.check_if_use_proxy(use_proxy, urllib_parse.urlparse(url)[1])

    # Handlers: Establece los handlers en funcion de si se usa proxy o no
    handlers, use_proxy = get_default_handlers(use_proxy)

    if cookies:
        handlers.append(urllib_request.HTTPCookieProcessor(cj))

    # No redirects
    if not follow_redirects:
        handlers.append(NoRedirectHandler())
    else:
        handlers.append(HTTPRedirectHandler())

    # Opener
    opener = urllib_request.build_opener(*handlers)

    # Contador
    inicio = time.time()

    # Request
    req = Request(url, six.ensure_binary(post) if post else None, request_headers, method=method)

    try:
        logger.info("Realizando Peticion")
        handle = opener.open(req, timeout=timeout)
        logger.info('Peticion realizada')

    except HTTPError as handle:
        logger.error()
        logger.info('Peticion realizada con error')
        response["sucess"] = False
        response["code"] = handle.code
        response["error"] = handle.__dict__.get("reason", str(handle))
        response["headers"] = dict(handle.headers.items())
        response['cookies'] = get_cookies(urllib_parse.urlparse(url)[1])
        if not only_headers:
            logger.info('Descargando datos...')
            response["data"] = handle.read()
        else:
            response["data"] = b""
        response["time"] = time.time() - inicio
        response["url"] = handle.geturl()

    except Exception as e:
        logger.error()
        logger.info('Peticion NO realizada')
        response["sucess"] = False
        response["code"] = e.__dict__.get("errno", e.__dict__.get("code", str(e)))
        response["error"] = e.__dict__.get("reason", str(e))
        response["headers"] = {}
        response['cookies'] = get_cookies(urllib_parse.urlparse(url)[1])
        response["data"] = b""
        response["time"] = time.time() - inicio
        response["url"] = url

    else:
        response["sucess"] = True
        response["code"] = handle.code
        response["error"] = None
        response["headers"] = dict(handle.headers.items())
        response['cookies'] = get_cookies(urllib_parse.urlparse(url)[1])
        if not only_headers:
            logger.info('Descargando datos...')
            response["data"] = handle.read()
        else:
            response["data"] = b""
        response["time"] = time.time() - inicio
        response["url"] = handle.geturl()

    response['headers'] = dict([(k.lower(), v) for k, v in response['headers'].items()])

    logger.info("Terminado en %.2f segundos" % (response["time"]))
    logger.info("Response sucess     : %s" % (response["sucess"]))
    logger.info("Response code       : %s" % (response["code"]))
    logger.info("Response error      : %s" % (response["error"]))
    logger.info("Response data length: %s" % (len(response["data"])))
    logger.info("Response headers:")
    logger.info(response['headers'])

    # Guardamos las cookies
    if cookies:
        save_cookies()

    # Gzip
    if response["headers"].get('content-encoding') == 'gzip':
        response["data"] = gzip.GzipFile(fileobj=BytesIO(response["data"])).read()

    # Binarios no se codifican ni se comprueba cloudflare, etc...
    if not is_binary(response):
        response['data'] = six.ensure_str(response['data'], errors='replace')

        if not no_decode:
            response["data"] = six.ensure_str(HTMLParser().unescape(
                six.ensure_text(response['data'], errors='replace')
            ))

        # Anti TestCookie
        if bypass_testcookie:
            if 'document.cookie="__test="+toHex(slowAES.decrypt(c,2,a,b))+"' in response['data']:
                a = scrapertools.find_single_match(response['data'], r'a=toNumbers\("([^"]+)"\)').decode("HEX")
                b = scrapertools.find_single_match(response['data'], r'b=toNumbers\("([^"]+)"\)').decode("HEX")
                c = scrapertools.find_single_match(response['data'], r'c=toNumbers\("([^"]+)"\)').decode("HEX")
                arguments['bypass_testcookie'] = False
                if not type(arguments['cookies']) == dict:
                    arguments['cookies'] = {'__test': aes.AESModeOfOperationCBC(a, b).decrypt(c).encode("HEX")}
                else:
                    arguments['cookies']['__test'] = aes.AESModeOfOperationCBC(a, b).decrypt(c).encode("HEX")
                response = downloadpage(**arguments).__dict__

        # Anti Cloudflare
        if bypass_cloudflare:
            response = retry_if_cloudflare(response, arguments)

    # Proxy Retry
    if use_proxy:
        response = retry_if_proxy_error(response, arguments)
    # No proxy detect error
    else:
        response = retry_with_proxy_if_error(response, arguments)

    return HTTPResponse(response)


def is_binary(response):
    logger.trace()

    text_content_types = [
        'text/html',
        'application/json',
        'text/javascript'
    ]
    content_type = response['headers'].get('content-type', '')

    if 'charset' in content_type:
        charset = response['headers']['content-type'].split('=')[1]
        if charset.lower() != 'utf-8':
            response['data'] = response['data'].decode(charset, errors='replace')
        return False

    content_type = content_type.split(' ')[0]
    if content_type in text_content_types:
        return False

    if isinstance(response['data'], six.binary_type):
        try:
            response['data'].decode('utf8')
        except UnicodeDecodeError:
            return True
        else:
            return False

    if isinstance(response['data'], six.text_type):
        return False

    if '\0' not in response['data']:
        return False

    return True


def config(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label='Configuración DNS/Proxy',
        action='dns_proxy',
        description='Permite configurar un servidor DNS y un servidor Proxy para esquivar bloqueos de operadoras'
    ))
    itemlist.append(item.clone(
        label='Canales que usan proxy',
        action='modules_proxy',
        mode='channels',
        description='Elige los canales que usarán proxy en sus conexiónes'
    ))
    itemlist.append(item.clone(
        label='Servidores que usan proxy',
        action='modules_proxy',
        mode='servers',
        description='Elige los servidores que usarán proxy en sus conexiónes'
    ))
    return itemlist


def modules_proxy(item):
    controls = list()

    if item.mode == 'channels':
        modules = moduletools.get_channels()
    else:
        modules = moduletools.get_servers()

    for module in modules:
        controls.append({
            'id': '/'.join((module['path'].split(os.sep)[-2:])),
            'type': 'bool',
            'label': module['name'],
            'default': module.get('proxy', False),
            'value': proxytools.is_proxy_enabled(module['path'])
        })

    platformtools.show_settings(callback="save_modules_proxy", title=item.label, controls=controls, item=item)
    return item


def save_modules_proxy(item, values):
    saved = settings.get_setting('proxy_modules', __file__) or {}
    saved.update(values)
    settings.set_setting('proxy_modules', saved, __file__)
    return item


def dns_proxy(item):
    platformtools.show_settings(callback="save_config", title=item.label)
    return item


def save_config(item, values):
    logger.trace()

    # Validar DNS
    if values['dns_mode'] == 3:
        if not validate_ip(values['primary_dns']) and not validate_ip(values['secondary_dns']):
            values.pop("dns_mode")
            values.pop('primary_dns')
            values.pop('secondary_dns')
            platformtools.dialog_ok('MediaExplorer', 'Debe especificar servidores DNS correctos')

    # Validar proxy_man
    if values['proxy_mode'] > 0 and values['proxy_tipo'] == 1:
        if not validate_ip_port(values['proxy_man']):
            values.pop("proxy_mode")
            values.pop('proxy_tipo')
            values.pop('proxy_man')
            platformtools.dialog_ok('MediaExplorer', 'Debe especificar un servidor proxy correcto')

    proxy_aut_search_now = values.pop('proxy_aut_search_now') and values["proxy_tipo"] == 2 and values['proxy_mode'] > 0
    settings.set_settings(values, __file__)

    if settings.get_setting('proxy_mode', __file__) > 0 and settings.get_setting('proxy_tipo', __file__) == 1:
        # Test proxy
        mode = settings.get_setting('proxy_mode', __file__)
        settings.set_setting('proxy_mode', 2, __file__)
        if not httptools.downloadpage('https://www.google.es', follow_redirects=False, only_headers=True).sucess:
            platformtools.dialog_ok(
                'MediaExplorer',
                'El proxy configurado parece no funcionar\n'
                'Comprueba la configuración o selecciona otro proxy'
            )
        settings.set_setting('proxy_mode', mode, __file__)

    # Buscar nuevo proxy automatico ahora?
    if proxy_aut_search_now:
        proxytools.search_proxies()

    return item
