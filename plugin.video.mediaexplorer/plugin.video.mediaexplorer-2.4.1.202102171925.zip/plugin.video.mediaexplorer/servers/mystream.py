# -*- coding: utf-8 -*-
from core.libs import *
from core.js import JS


def get_video_url(item):
    logger.trace()
    itemlist = []
    js = JS()

    # Descargamos los datos
    yield ResolveProgress(20, 0)
    data = httptools.downloadpage(item.url).data

    # Comprobamos si existe
    if "We are unable to find the video" in data:
        yield ResolveError(0)
        return

    # Extraemos el código JS
    yield ResolveProgress(40, 3)
    js_code = scrapertools.find_single_match(data, r'<script>([^<\$]+\$[^<]+)</script>').strip().split('\n')[0]

    # Creamos el entorno para JS
    code = """
    let result;
    if (this.document == undefined){
        document = {
            createElement: function(){
                return {
                    setAttribute: function(attr, value){
                        this[attr] = value;
                    }
                };
            }
        };
    };

    jQuery = function(){ 
        return { 
            append: function(el){result = el.src}
        };
    };
    %s
    python.sendResponse(result)
    """ % js_code

    # js2py da recurssion error sin no se modifica
    rl = sys.getrecursionlimit()
    sys.setrecursionlimit(25000)

    try:
        # Obtenemos la url
        url = js.run_js(code)
        sys.setrecursionlimit(rl)
    except Exception:
        logger.error()
        sys.setrecursionlimit(rl)
        yield ResolveError(8)
    else:
        itemlist.append(Video(url=url))
        yield itemlist
