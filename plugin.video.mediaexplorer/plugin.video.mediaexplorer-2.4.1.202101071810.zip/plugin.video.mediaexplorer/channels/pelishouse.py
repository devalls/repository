# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://pelishouse.com'

LNG = Languages({
    Languages.es: ['castellano', 'CASTELLANO'],
    Languages.la: ['latino', 'LATINO'],
    Languages.sub_es: ['subtitulado', 'SUBTITULADO']
})

QLT = Qualities({
    Qualities.hd_full: ['HD 1080P', '1080p'],
    Qualities.hd: ['HD', 'HD 720P', '720p'],
    Qualities.scr: ['TS']
})


def mainlist(item):
    logger.trace()
    itemlist = list()

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        thumb='thumb/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    new_item = item.clone(
        type='label',
        label="Series",
        category='tvshow',
        thumb='thumb/tvshow.png',
        icon='icon/tvshow.png',
        poster='poster/tvshow.png',
    )
    itemlist.append(new_item)
    itemlist.extend(menuseries(new_item))

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="movies",
        label="Novedades",
        url=HOST + "/movies",
        type="item",
        group=True,
        content_type='movies'))

    itemlist.append(item.clone(
        action="movies",
        label="Español",
        url=HOST + "/genre/castellano",
        type="item",
        group=True,
        lang=[Languages.es],
        content_type='movies'))

    itemlist.append(item.clone(
        action="movies",
        label="Latino",
        url=HOST + "/genre/latin",
        type="item",
        group=True,
        lang=[Languages.la],
        content_type='movies'))

    itemlist.append(item.clone(
        action="movies",
        label="Subtitulado",
        url=HOST + "/genre/peliculas-subtituladas",
        type="item",
        group=True,
        lang=[Languages.sub_es],
        content_type='movies'))

    itemlist.append(item.clone(
        action="generos",
        label="Géneros",
        url=HOST,
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        action="years",
        label="Años",
        url=HOST,
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        content_type='movies'
    ))

    return itemlist


def menuseries(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="tvshows",
        label="Novedades",
        url=HOST + "/tvshows",
        type="item",
        group=True,
        content_type='tvshows'))

    """itemlist.append(item.clone(
        action="newest_episodes",
        label="Nuevos episodios",
        url=HOST + "/episodes",
        type="item",
        group=True,
        content_type='episodes'))"""

    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        content_type='tvshows'
    ))

    return itemlist


def generos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = scrapertools.find_single_match(data, r'<ul class="genres scrolling">(.*?)</ul>')
    patron = r'<a href="([^"]+)" title="[^"]+">([^<]+)</a>'

    for url, title in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            label=title,
            url=url,
            action='movies',
            content_type='movies',
        ))

    return sorted(itemlist, key=lambda x: x.label)


def years(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = scrapertools.find_single_match(data, r'<ul class="releases scrolling">(.*?)</ul>')

    patron = r'<li><a href="([^"]+)">(\d+)</a></li>'

    for url, title in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            label=title,
            url=url,
            action='movies',
            content_type='movies',
        ))

    return sorted(itemlist, key=lambda x: x.label, reverse=True)


def search(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(HOST + '?s=%s' % item.query).data

    if item.category == 'movie':
        patron = r'<a href="([^"]+)"><img src="([^"]+)" alt="([^"]+)" /><span class="movies">Película</span>' \
                 r'.*?<span class="year">(\d+)</span>'
        for url, poster, title, year in scrapertools.find_multiple_matches(data, patron):
            itemlist.append(item.clone(
                title=title,
                year=year,
                poster=poster,
                type='movie',
                action='findvideos',
                url=url,
                content_type='servers'
            ))
    else:
        patron = r'<a href="([^"]+)"><img src="([^"]+)" alt="([^"]+)" /><span class="tvshows">TV</span>' \
                 r'.*?<span class="year">(\d+)</span>'
        for url, poster, title, year in scrapertools.find_multiple_matches(data, patron):
            title = scrapertools.find_single_match(title, r'Ver (.*?) Serie Online') or title
            itemlist.append(item.clone(
                tvshowtitle=title,
                title=title,
                year=year,
                poster=poster,
                type='tvshow',
                action='seasons',
                url=url,
                content_type='seasons'
            ))

    return itemlist


def movies(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)
    patron = r'<article id="post-\d+" class="item movies">.*?data-lazy-src="([^"]+)".*?' \
             r'(?:<span class="quality">([^<]+)</span>.*?)?<a href="([^"]+)">.*?<h4>([^<]+)</h4>.*?' \
             r'<span>(\d+)</span>.*?<div class="mta">(.*?)</article>'

    for poster, qlt, url, title, year, tags in scrapertools.find_multiple_matches(data, patron):
        langs = []

        if 'castellano' in tags:
            langs.append(LNG.get('castellano'))
        if 'subtitul' in tags:
            langs.append(LNG.get('subtitulado'))
        if 'latino' in tags:
            langs.append(LNG.get('latino'))

        itemlist.append(item.clone(
            title=title,
            year=year,
            poster=poster,
            type='movie',
            action='findvideos',
            quality=QLT.get(qlt),
            lang=langs,
            url=url,
            content_type='servers'
        ))

    # Paginador
    next_page = scrapertools.find_single_match(data, r'<a class=\'arrow_pag\' href="([^"]+)">')
    if next_page:
        itemlist.append(item.clone(type='next', url=next_page))

    return itemlist


def tvshows(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    patron = r'<article id="post-\d+" class="item tvshows">.*?data-lazy-src="([^"]+)".*?' \
             r'<a href="([^"]+)">.*?<h4>([^<]+)</h4>.*?<span>(\d+)</span>'

    for poster, url, title, year in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            tvshowtitle=title,
            title=title,
            year=year,
            poster=poster,
            type='tvshow',
            action='seasons',
            url=url,
            content_type='seasons'
        ))

    # Paginador
    next_page = scrapertools.find_single_match(
        data,
        r'<span class="current">\d+</span><a href=\'([^\']+)\' class="inactive">'
    )
    if next_page:
        itemlist.append(item.clone(type='next', url=next_page))

    return itemlist


def newest_episodes(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    patron = r'<article class="item se episodes" id="post-\d+">.*?data-lazy-src="([^"]+)".*?' \
             r'<span class="quality">([^<]+)</span>.*?href="([^"]+)">([^<]+)</a></h3>' \
             r'<span>T(\d+) E(\d+).*?<span class="serie">([^<]+)</span>'

    for thumb, qlt, url, title, season, episode, tvshow in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            episode=int(episode),
            season=int(season),
            tvshowtitle=tvshow,
            title=title,
            thumb=thumb,
            type='episode',
            action='findvideos',
            quality=QLT.get(qlt),
            url=url,
            content_type='servers'
        ))

    # Paginador
    next_page = scrapertools.find_single_match(
        data,
        r'<span class="current">\d+</span><a href=\'([^\']+)\' class="inactive">'
    )
    if next_page:
        itemlist.append(item.clone(type='next', url=next_page))

    return itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    logger.debug(data)
    patron = r"<span class='se-t[^']*'>(\d+)</span><span class='title'>([^<]+)"

    for season, label in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            label=label,
            season=int(season),
            type='season',
            action='episodes',
            content_type='episodes'
        ))

    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    patron = r'<li class=\'mark-\d+\'>.*?data-lazy-src="([^"]+)".*?' \
             r'class=\'numerando\'>(\d+) - (\d+).*?href=\'([^\']+)\'>([^<]+)'

    for thumb, season, episode, url, title in scrapertools.find_multiple_matches(data, patron):
        if int(season) != item.season:
            continue
        itemlist.append(item.clone(
            title=title,
            episode=int(episode),
            type='episode',
            action='findvideos',
            thumb=thumb,
            url=url,
            content_type='servers'
        ))

    return itemlist


def findvideos(item):
    logger.trace()
    itemlist = list()
    downloads = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    patron = r"<li id='player-option-\d+' class='dooplay_player_option' data-type='([^']+)' " \
             r"data-post='([^']+)' data-nume='([^'])+'>.*?<span class='title'>([^<]+)</span>"

    for _type, post, nume, tag in scrapertools.find_multiple_matches(data, patron):
        url = get_video_url(_type, post, nume)
        try:
            lng, qlt = tag.strip().split(' ')
        except Exception:
            logger.error()
            lng = qlt = ''

        itemlist.append(item.clone(
            url=urllib_parse.urljoin(item.url, url),
            type='server',
            server='pelishouse' if 'g-nula.top' in url else None,
            servername='PelisHouse' if 'g-nula.top' in url else None,
            lang=LNG.get(lng.strip()),
            quality=QLT.get(qlt.strip()),
            action='play'
        ))

    patron = r'<tr id=\'link-\d+\'>.*?data-lazy-src=".*?domain=([^"]+)".*?' \
             r'href=\'([^\']+)\'.*?class=\'quality\'>([^\<]+)</strong></td><td>([^\<]+)</td><td>'

    for server, url, qlt, lng in scrapertools.find_multiple_matches(data, patron):
        downloads.append(item.clone(
            url=urllib_parse.urljoin(item.url, url),
            type='server',
            server=server.split('.')[0],
            servername='PelisHouse' if server == 'g-nula.top' else None,
            lang=LNG.get(lng.lower()),
            quality=QLT.get(qlt.strip()),
            stream=False,
            action='play'
        ))

    downloads = servertools.get_servers_from_id(downloads)

    return servertools.get_servers_itemlist(itemlist) + downloads


def get_video_url(_type, post, nume):
    data = httptools.downloadpage(HOST + '/wp-json/dooplayer/v1/post/%s?type=%s&source=%s' % (
        post,
        _type,
        nume
    )).data
    return jsontools.load_json(data)['embed_url']


def play(item):
    logger.trace()
    itemlist = list()

    if item.url.startswith(HOST):
        data = httptools.downloadpage(item.url).data
        item.url = scrapertools.find_single_match(data, r'href="([^"]+)" class="btn"')

    if item.url.startswith('https://g-nula.top'):
        video_id = item.url.split('/')[-1]
        data = jsontools.load_json(httptools.downloadpage(
            'https://g-nula.top/api/source/%s' % video_id,
            post={
                'r': '',
                'd': 'g-nula.top'
            }
        ).data)
        for video in data['data']:
            url = httptools.downloadpage(video['file'], follow_redirects=False).headers['location']
            itemlist.append(
                Video(url=url, res=video['label'])
            )
        return sorted(itemlist, key=lambda i: int(i.res[:-1]), reverse=True)

    return servertools.normalize_url(item)
