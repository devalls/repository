# -*- coding: utf-8 -*-
# -*- protect
import sys
import os


if len(sys.argv) == 2:
    exec(compile(open(os.path.join(os.path.dirname(__file__), sys.argv[1]), "rb").read(), sys.argv[1], 'exec'))
else:
    # <protect>
    import datetime
    start_time = datetime.datetime.now()
    import logging

    import xbmc
    import xbmcgui
    import xbmcplugin

    from core import launcher
    from core.libs import *

    try:

        logger.debug('|--------------------------|')
        logger.debug('|-------MediaExplorer------|')
        logger.debug('|--------------------------|')

        argv = sys.argv[0]
        pluginName = xbmc.getInfoLabel("Container.PluginName")
        folderPath = xbmc.getInfoLabel("Container.FolderPath")
        folderName = xbmc.getInfoLabel("Container.FolderName")
        valid = False

        if not folderPath.startswith('plugin://'):
            valid = True
            # logger.debug('caso 1')

        elif folderName in ("", "Add-ons", "MediaExplorer"):
            valid = True
            # logger.debug('caso 2')

        elif sys.argv[2]:
            # Busqueda en favorites.xml: Solo algunos tipos estan permitidos
            with open(sysinfo.bookmarks_path, 'rb') as favorites:
                if folderPath in favorites.read():
                    if Item().fromurl(sys.argv[2]).type in ("movie", "tvshow", "season", "episode", "video"):
                        valid = True
                        # logger.debug('caso 3')

        if not valid:
            logger.debug("Intentando abrir MediaExplorer desde otro addon.")
            logger.debug(pluginName)
            logger.debug(folderPath)
            logger.debug(folderName)
            xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
            xbmc.executebuiltin('ActivateWindow(Videos,Addons,return)')
        else:
            if sys.argv[2]:
                item = Item().fromurl(sys.argv[2])
                if not item.folder:
                    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
                if item.strm:
                    logger.debug("Es un .strm, se reproduce un archivo vacío y se recarga...")
                    del item.strm
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xbmcgui.ListItem(
                        path=os.path.join(sysinfo.runtime_path, 'resources', 'nomedia')))
                    xbmc.Player().stop()

                    from core import library

                    item.path = filetools.join(settings.get_setting('library_path', library.__file__), item.path)

                    if not folderPath:  # Desde el home (Confluence)
                        if sysinfo.platform_version > 17:
                            time.sleep(1)
                        xbmc.executebuiltin("ActivateWindow(10025, 'Videos)")
                        xbmc.executebuiltin("ActivateWindow(10025, %s?%s, return)" % (sys.argv[0], item.tourl()))
                    else:
                        xbmc.executebuiltin("Container.Update(%s?%s)" % (sys.argv[0], item.tourl()))
                else:
                    launcher.run(item)
            else:
                if launcher.start():
                    launcher.run(
                        Item(channel='channelselector', action='mainlist', content_type='icons', category='all'))

            logging.shutdown()

    except Exception:
        logger.error()
        raise
    else:
        delta = datetime.datetime.now() - start_time
        logger.debug('|---------Terminado--------|')
        logger.debug('Tiempo: %d.%d segundos' % (delta.seconds, delta.microseconds / 1000))
        logger.debug('|--------------------------|')
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        platformtools.DialogProgressBG.close_all()
        platformtools.DialogProgress.close_all()
    # </protect>
