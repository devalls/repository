# -*- coding: utf-8 -*-
from core.libs import *
import jsbeautifier

def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    packed = scrapertools.find_single_match(data, "<script>.*?(eval.*?)</script>")
    unpacked = jsbeautifier.beautify(packed)
    sources = scrapertools.find_single_match(unpacked, 'sources:([^\]]+)')

    for url in scrapertools.find_multiple_matches(sources, 'file:\s?"([^"]+)'):
        itemlist.append(Video(url=url))

    return itemlist