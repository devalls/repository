# -*- coding: utf-8 -*-
from core.libs import *
import unicodedata

LNG = Languages({
    Languages.es: ['es']
})

QLT = Qualities({
    Qualities.hd_full: ['fullhd', 'microhd'],
    Qualities.uhd: ['cuatrok'],
    Qualities.m3d: ['tresd']
})


magnet = 'plugin://plugin.video.elementum/play?uri=magnet:?xt=urn:btih:'


def mainlist(item):
    logger.trace()
    itemlist = list()

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        thumb='thumb/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    new_item = item.clone(
        type='label',
        label="Series",
        category='tvshow',
        thumb='thumb/tvshow.png',
        icon='icon/tvshow.png',
        poster='poster/tvshow.png',
    )
    itemlist.append(new_item)
    itemlist.extend(menuseries(new_item))

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label="Películas aleatorias",
        action="movies",
        content_type='movies',
        type="item",
        group=True,
        url='https://raw.githubusercontent.com/darkozma/tacones/main/nuevo'
    ))

    itemlist.append(item.clone(
        label="Películas por orden alfabético",
        action="movies",
        content_type='movies',
        type="item",
        group=True,
        url='https://raw.githubusercontent.com/darkozma/tacones/main/nuevo'
    ))

    return itemlist


def menuseries(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label="Series aleatorias",
        action="tvshows",
        content_type='tvshows',
        type="item",
        group=True,
        url='https://pastebin.com/raw/Jqfs0jQt'
    ))

    itemlist.append(item.clone(
        label="Series por orden alfabético",
        action="tvshows",
        content_type='tvshows',
        type="item",
        group=True,
        url='https://pastebin.com/raw/Jqfs0jQt'
    ))

    return itemlist


@LimitResults
def movies(item):
    logger.trace()
    itemlist = list()
    
    if item.label == "Películas aleatorias":
        alea = "PA" 
    else:
        alea = "NO"
    
    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<microhd>([^<]+)</.*?<fullhd>([^<]+)</.*?<tresd>([^<]+)<' \
             r'/.*?<cuatrok>([^<]+)</.*?<thumbnail>([^<]+)</.*?<date>([^<]+)</.*?<info>([^<]+)</'
    
    for title, cal1, cal2, cal3, cal4, poster, year, plot in scrapertools.find_multiple_matches(data, patron):
        if cal1 != 'NA':
            cal = 'microhd'
            uri = cal1
        elif cal1 == 'NA' and cal2 != 'NA':
            cal = 'fullhd'
            uri = cal2
        elif cal1 == 'NA' and cal2 == 'NA' and cal3 != 'NA':
            cal = 'tresd'
            uri = cal3
        elif cal1 == 'NA' and cal2 == 'NA' and cal3 == 'NA' and cal4 != 'NA':
            cal = 'cuatrok'
            uri = cal4
        
        cal = QLT.get(cal)
        title = title.title()
        
        title = re.sub(r"ÑA", "ña", title)
        title = re.sub(r"ÑE", "ñe", title)
        title = re.sub(r"ÑI", "ñi", title)
        title = re.sub(r"ÑO", "ño", title)
        title = re.sub(r"ÑU", "ñu", title)
        
        if alea == "PA":
            item.alea = "PA"
        lang = LNG.get('es')

        if cal != 'cuatrok':
            itemlist.append(item.clone(
                title=title + ' [COLOR blue][%s][/COLOR] [%s] (%s)' % (year, lang, cal),
                url=magnet + uri,
                type='movie',
                poster=poster,
                plot=plot,
                lang=lang,
                year=year,
                action='play',
                quality=cal
            ))

    return sorted(itemlist) if item.alea == "PA" else itemlist


@LimitResults
def tvshows(item):
    logger.trace()
    itemlist = list()
    
    if item.label == "Series aleatorias":
        alea = "SA" 
    else:
        alea = "NO"
    
    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron = r"<item.*?title>([^<]+)<.*?title>(.*?)</item"

    for title, rest in scrapertools.find_multiple_matches(data, patron):
        title = scrapertools.find_single_match(title, r"\[COLOR white\]([^\[]+)\[/COLOR\]")
        poster = scrapertools.find_single_match(rest, r"<thumbnail>(.*?)</thumbnail>")
        link = scrapertools.find_single_match(rest, r"<link>(.*?)</link>")
        ext_link = scrapertools.find_single_match(rest, r"<externallink>(.*?)</externallink>")
        if "elementum" in link:
            url = link
        elif "pastebin" in ext_link:
            url = ext_link

        title = title.title()
        title = re.sub(r"ÑA", "ña", title)
        title = re.sub(r"ÑE", "ñe", title)
        title = re.sub(r"ÑI", "ñi", title)
        title = re.sub(r"ÑO", "ño", title)
        title = re.sub(r"ÑU", "ñu", title)
        
        if alea == "SA":
            item.alea = "SA"
        lang = LNG.get('es')

        itemlist.append(item.clone(
            tvshowtitle=title,
            url=url,
            title=title,
            lang=lang,
            poster=poster,
            type='tvshow',
            content_type='servers' if "elementum" in url else 'seasons',
            action='play' if "elementum" in url else 'seasons'
        ))

    return sorted(itemlist) if item.alea == "SA" else itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)<.*?itle>(.*?)</item'

    for title, rest in scrapertools.find_multiple_matches(data, patron):
        title = re.sub(r"\[COLOR red\]•\[/COLOR\]", "[COLOR gold]•[/COLOR]", title)
        #title = scrapertools.find_single_match(title, r'\[COLOR white\](.*?)\[/COLOR\]')
        #title1 = scrapertools.find_single_match(title, r'\[COLOR red\](.*?)\[/COLOR\]')
        season = scrapertools.find_single_match(title, r'\[COLOR red\].*?(\d+).*?\[/COLOR\]')
        link = scrapertools.find_single_match(rest, r'<link>(.*?)</link>')
        ext_link = scrapertools.find_single_match(rest, r'<externallink>(.*?)</externallink>')
        if link:
            if "elementum" in link:
                url = link
            else:
                url = ext_link
        else:
            url = ext_link
        if not url:
            url = scrapertools.find_single_match(rest, r"channels =.*?'([^']+)'")

        title = title.title()

        if "elementum" in url:
            title = re.sub(r"\[COLOR red\].*?\[/COLOR\] |\[.*?\]|•", "", title)
            title = title.strip().title()
            title = '[COLOR blue]Reproducir [/COLOR]' + title
            if 'ª' in title:
                title = re.sub(r"ª", "ª Temporada ", title)
            if 'º' in title:
                title = re.sub(r"º", "º Capítulo ", title)
        
        title = re.sub(r"ÑA", "ña", title)
        title = re.sub(r"ÑE", "ñe", title)
        title = re.sub(r"ÑI", "ñi", title)
        title = re.sub(r"ÑO", "ño", title)
        title = re.sub(r"ÑU", "ñu", title)

        title = re.sub(r"\[Color", "[COLOR", title)
        title = re.sub(r"Color\]", "COLOR]", title)
        title = re.sub(r"\[B\]|\[/B\]|•", "", title)

        itemlist.append(item.clone(
            action='play' if "elementum" in url else "episodes",
            title=title,
            season=season + ' ' + title,
            type='season',
            url=url,
            content_type='servers' if "elementum" in url else 'episodes'
        ))

    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)<.*?itle>(.*?)</item'

    for title, rest in scrapertools.find_multiple_matches(data, patron):
        season = scrapertools.find_single_match(title, r'\[COLOR red\].*?(\d+).*?/COLOR\]')
        episode = scrapertools.find_single_match(title, r'\[COLOR white\].*?(\d+).*?\[/COLOR\]')
        url = scrapertools.find_single_match(rest, r'<link>(.*?)</link>')
        title = scrapertools.find_single_match(title, r'\[COLOR white\]([^\[]+)\[/COLOR\]')
        
        title = re.sub(r"\[.*?\]", "", title.title())
        title = '[COLOR blue]Reproducir [/COLOR]' + title
        title = re.sub(r"ÑA", "ña", title)
        title = re.sub(r"ÑE", "ñe", title)
        title = re.sub(r"ÑI", "ñi", title)
        title = re.sub(r"ÑO", "ño", title)
        title = re.sub(r"ÑU", "ñu", title)
        
        itemlist.append(item.clone(
            action='play',
            title=title,
            #season=int(season),
            #episode=int(episode),
            type='episode',
            url=url
        ))

    return itemlist

