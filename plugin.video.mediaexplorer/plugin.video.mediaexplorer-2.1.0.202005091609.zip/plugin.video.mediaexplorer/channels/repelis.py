# -*- coding: utf-8 -*-
from core.libs import *

host = 'https://repelisgo.net'

LNG = Languages({
    Languages.es: ['es-es'],
    Languages.sub_es: ['en'],
    Languages.la: ['es-mx']
})

QLT = Qualities({
    Qualities.hd_full: ['high'],
    Qualities.hd: ['good'],
    Qualities.rip: ['low'],
})


def mainlist(item):
    logger.trace()

    itemlist = list()

    itemlist.append(item.clone(
        label="Novedades",
        category='movie',
        action='movies',
        content_type='movies',
        url=host + '/explorar',
        thumb='thumb/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    ))

    itemlist.append(item.clone(
        label="Géneros",
        category='movie',
        action='generos',
        content_type='items',
        url=host,
        thumb='thumb/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    ))

    itemlist.append(item.clone(
        label="Idiomas",
        category='movie',
        action='idiomas',
        content_type='items',
        url=host,
        thumb='thumb/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    ))

    itemlist.append(item.clone(
        label="Buscar",
        category='movie',
        action='search',
        content_type='movies',
        url=host,
        type='search',
        query=True
    ))

    return itemlist


def search(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(
        host + '/graph',
        post='{"query":"query ($term: String) {movies: allMovies(search: $term) {id slug title releaseDate poster}}",'
             '"variables":{"term":"%s"}}' % item.query,
        headers={
            'Content-Type': 'application/json;charset=utf-8'
        }

    ).data

    videos = jsontools.load_json(data)
    for movie in videos['data']['movies']:
        itemlist.append(item.clone(
            type='movie',
            title=movie['title'],
            year=movie['releaseDate'].split('-')[0],
            action='findvideos',
            url=host + '/pelicula/%s-%s' % (movie['slug'], movie['id']),
            poster=host + '/_images/posters/%s/180x270.jpg' % (movie['poster']),
            content_type='servers'
        ))

    return itemlist


def generos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    patron = '<a href="(?P<url>/genero/[^"]+)">(?P<label>[^<]+)</a>'
    for match in re.finditer(patron, data):
        itemlist.append(item.clone(
            label=match.group('label'),
            url=host + match.group('url'),
            action='movies',
            content_type='movies'
        ))

    return sorted(itemlist, key=lambda i: i.label)


def idiomas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label='Español',
        url=host + '/peliculas-castellano',
        action='movies',
        content_type='movies'
    ))

    itemlist.append(item.clone(
        label='Latino',
        url=host + '/peliculas-latino',
        action='movies',
        content_type='movies'
    ))

    itemlist.append(item.clone(
        label='Subtitulado',
        url=host + '/peliculas-subtituladas',
        action='movies',
        content_type='movies'
    ))

    return itemlist


def movies(item):
    logger.trace()

    itemlist = list()

    data = httptools.downloadpage(item.url).data

    videos = jsontools.load_json(scrapertools.find_single_match(data, r'window.__NUXT__=(.*?);</script>'))

    for movie in videos['data'][0]['movies']:
        itemlist.append(item.clone(
            type='movie',
            title=movie['title'],
            year=movie['releaseDate'].split('-')[0],
            action='findvideos',
            url=host + '/pelicula/%s-%s' % (movie['slug'], movie['id']),
            poster=host + '/_images/posters/%s/180x270.jpg' % (movie['poster']),
            content_type='servers'
        ))

    return itemlist


def findvideos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    servers = jsontools.load_json(scrapertools.find_single_match(data, r'window.__NUXT__=(.*?);</script>'))
    for server in servers['data'][0]['movie']['mirrors']:
        itemlist.append(item.clone(
            type='server',
            server=server['hostname'].split('.')[0],
            action='play',
            url=host + server['url'],
            lang=LNG.get(server['audio']),
            quality=QLT.get(server['quality']),
            stream=server['type'] == 'stream'

        ))
    itemlist = servertools.get_servers_from_id(itemlist)
    return itemlist


def play(item):
    logger.trace()
    if item.url.startswith(host):
        item.url = httptools.downloadpage(item.url, follow_redirects=False).headers.get('location')
    servertools.normalize_url(item)
