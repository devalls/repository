# -*- coding: utf-8 -*-
from core.libs import *
import js2py


def get_video_url(item):
    logger.trace()
    itemlist = []

    yield ResolveProgress(20, 0)
    data = httptools.downloadpage(item.url).data
    videokey = scrapertools.find_single_match(data, 'videokeyorig = "([^"]+)"')

    if not httptools.get_cookies('hqq.tv').get('gt'):
        yield ResolveProgress(30, 4)
        token = platformtools.show_recaptcha(
            "https://hqq.tv",
            "6Ldf5F0UAAAAALErn6bLEcv7JldhivPzb93Oy5t9",
            "watch_video"
        )
    else:
        token = ""

    yield ResolveProgress(40, 0)
    sh = js2py.eval_js(scrapertools.find_single_match(data, 'sh="";\n(.*?)</script>'))
    data = httptools.downloadpage(
        'https://hqq.tv/player/get_md5.php?st=%s&ver=4&secure=0&adb=0/&v=%s&token=%s&gt=&embed_from=0&wasmcheck=1' % (
            sh,
            videokey,
            token,
        ),
        headers={
            'Accept': '*/*',
        }).data

    json_data = jsontools.load_json(data)

    yield ResolveProgress(60, 2)
    url = un(json_data['obf_link'])
    itemlist.append(Video(url=url, headers={'Accept': '*/*'}))

    yield itemlist


def un(link):
    from six import unichr
    s2 = ''
    for i in range(1, len(link), 3):
        s2 += unichr(int(link[i:i + 3], 16))

    return 'https:' + s2 + '.mp4.m3u8'
