# -*- coding: utf-8 -*-
from core.libs import *
import jsbeautifier

def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data
    referer = scrapertools.find_single_match(data, '"Movie Streaming", "([^"]+)"')
    if not referer:
        return ResolveError(0)

    packed = scrapertools.find_single_match(data, "<script>.*?(eval.*?)</script>")
    unpacked = jsbeautifier.beautify(packed)

    src = scrapertools.find_single_match(unpacked, ",src.*?'([^']+)")
    if src:
        url = httptools.downloadpage(src, headers={'Referer': 'https://streamz.cc' + referer}, only_headers=True, follow_redirects=False).headers.get('location', '')
        if url:
            itemlist.append(Video(url=url))

    return itemlist