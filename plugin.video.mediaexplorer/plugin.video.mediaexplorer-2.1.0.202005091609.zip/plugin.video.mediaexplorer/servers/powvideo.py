# -*- coding: utf-8 -*-

import js2py
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = []

    # Obtenemos la redireccion
    item.url = httptools.downloadpage(item.url, follow_redirects=False).headers.get('location', item.url)

    # Generamos las URLS
    url = item.url.replace('embed', 'player')

    yield ResolveProgress(10, 0)
    data = httptools.downloadpage(item.url, headers={'Referer': item.referer}).data
    sitekey = scrapertools.find_single_match(data, "grecaptcha.render.*?sitekey: '([^']+)'")
    action = scrapertools.find_single_match(data, "grecaptcha.render.*?sitekey: '[^']+', '([^']+)'")

    yield ResolveProgress(20, 4)
    token = platformtools.show_recaptcha(
        siteurl=item.url,
        sitekey=sitekey,
        action=action,
        min_score='0.9',
        silent=True
    )

    # Descargamos los datos
    yield ResolveProgress(30, 0)
    data = httptools.downloadpage(url, headers={'referer': item.url}, post={
        'op': 'embed',
        'token': token
    }).data

    if "File was deleted" in data:
        yield ResolveError(0)
        return

    elif 'Video is processing now.' in data:
        yield ResolveError(1)
        return

    yield ResolveProgress(40, 3)
    unpacked = js2py.eval_js(
        scrapertools.find_single_match(data, "<script type=[\"']text/javascript[\"']>eval(.*?)</script>"))

    yield ResolveProgress(60, 1)
    sources = scrapertools.find_single_match(unpacked, r"sources=(.*?);")
    script = scrapertools.find_single_match(data, r'(var _0x[^=]+=[^\n]+ABCDEFGHIJKLMNOPQRSTUVWXYZ[^\n]+)')

    data = {}

    def J(name, value):
        name = name.to_python()
        value = value.to_python()

        if name in ('body', 'div:first'):
            return {'data': J}
        elif value is not None:
            data[name] = value
        else:
            return data.get(name)

    a = js2py.EvalJs({'$': J, 'navigator': {}})

    def _map(e, t, n):
        s = []
        for o in range(len(e)):
            i = t(e[o], o, n)
            s.append(i)
        return s

    a['$'].map = _map

    yield ResolveProgress(80, 2)
    sources = a.eval(script + "var image=''; var tracks = []; "
                              "var sources = %s; sources.size(); "
                              "sources" % sources.replace('src', 'file')
                     )

    for url in sources.to_list():
        url['file'] = url['file'].replace("rtmp://https://", 'rtmp://')
        itemlist.append(Video(
            url=url['file'],
            headers={
                'User-Agent': httptools.default_headers['User-Agent']
            }
        ))

    yield itemlist
