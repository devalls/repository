# -*- coding: utf-8 -*-

from core.libs import *
import js2py


def get_video_url(item):
    logger.trace()
    itemlist = []

    # Obtenemos la redireccion
    item.url = httptools.downloadpage(item.url, follow_redirects=False).headers.get('location', item.url)

    # Generamos las URLS
    url = item.url.replace('embed', 'player')

    yield ResolveProgress(10, 0)
    data = httptools.downloadpage(item.url, headers={'Referer': item.referer}).data
    sitekey = scrapertools.find_single_match(data, "grecaptcha.render.*?sitekey: '([^']+)'")
    action = scrapertools.find_single_match(data, "grecaptcha.render.*?sitekey: '[^']+', '([^']+)'")

    yield ResolveProgress(20, 4)
    token = platformtools.show_recaptcha(
        siteurl=item.url,
        sitekey=sitekey,
        action=action,
        min_score='0.9',
        silent=True
    )

    yield ResolveProgress(30, 0)
    httptools.downloadpage(item.url, only_headers=True)
    data = httptools.downloadpage(url, headers={'Referer': item.referer}, post={
        'op': 'embed',
        'token': token
    }).data

    if 'Video is processing now' in data:
        yield ResolveError(1)
        return

    if data == "File was deleted":
        yield ResolveError(0)
        return

    yield ResolveProgress(40, 3)
    unpacked = js2py.eval_js(
        scrapertools.find_single_match(data, "<script type=[\"']text/javascript[\"']>eval(.*?)</script>"))

    yield ResolveProgress(60, 1)
    sources = eval(scrapertools.find_single_match(unpacked, 'sources=(.*?);'))
    script = scrapertools.find_single_match(data, r'(var _0x[^=]+=[^\n]+ABCDEFGHIJKLMNOPQRSTUVWXYZ[^\n]+)')
    data = {}

    def J(name, value):
        name = name.to_python()
        value = value.to_python()
        if name in ('body', 'div:first'):
            return {'data': J}
        elif value is not None:
            data[name] = value
        else:
            return data.get(name)

    a = js2py.EvalJs({'$': J, 'navigator': {}})

    def _map(e, t, n):
        s = []
        for o in range(len(e)):
            i = t(e[o], o, n)
            s.append(i)
        return s

    a['$'].map = _map

    yield ResolveProgress(80, 2)
    sources = a.eval(script + "var sources = %s; sources.size();" % sources)

    for url in sources.to_list():
        itemlist.append(Video(url=url))

    yield itemlist
