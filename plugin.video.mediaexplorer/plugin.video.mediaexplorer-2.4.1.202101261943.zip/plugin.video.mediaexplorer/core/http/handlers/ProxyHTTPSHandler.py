# -*- coding: utf-8 -*-
from .HTTPSHandler import HTTPSConnection, HTTPSHandler
from .ProxyHTTPHandler import ProxyHTTPConnection


class ProxyHTTPSHandler(HTTPSHandler):
    """
    ProxyHTTPSHandler para poder usar servidores proxy Socks4, Socks4A, Socks5
    """
    handler_order = 100

    def __init__(self, proxy, version):
        HTTPSHandler.__init__(self, 0)
        self.proxy = proxy
        self.version = version

    def https_open(self, req):
        req._tunnel_host = req.host
        req.host = self.proxy
        return self.do_open(ProxyHTTPSConnection, req, version=self.version)


class ProxyHTTPSConnection(ProxyHTTPConnection, HTTPSConnection):
    def __init__(self, *args, **kwargs):
        self.version = kwargs.pop('version')
        HTTPSConnection.__init__(self, *args, **kwargs)
        ProxyHTTPConnection.__init__(self, *args, **kwargs)