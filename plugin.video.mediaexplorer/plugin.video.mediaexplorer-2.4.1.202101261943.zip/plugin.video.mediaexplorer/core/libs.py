# -*- coding: utf-8 -*-
"""
Conjunto de librerias de uso mas comun en MediaExplorer, permite importar las librerias mas comunes sin problemas de
imports recursivos que fallen.
uso:
    from core.libs import *

TODO: No sobreacargar, ya que con cada item que se abre se cargan todas las libreriras, para no afectar al rendimiento
      añadir solo las librerias de uso comun, otras librerias se pueden importar cuando sean necesarias
"""

# Librerias del sistema
import datetime
import inspect
import os
import re
import sys
import time
from threading import Lock, RLock

# Compatibilidad Python2 - Python3
import six
from six.moves import reduce
from six.moves import reload_module
from six.moves import urllib_parse

# Librerias de MediaExplorer
# Primero importamos las clases y funciones genericas para crear el objecto sysinfo necesario para otros modulos
from core.util import Thread, LimitResults, ResolveProgress, ResolveError, Resolver, ProxyDT
from core.util import sysinfo, change_units, call_api
from core.http.handlers import HTTPHandler, HTTPSHandler, HTTPRedirectHandler, ProxyHTTPHandler, ProxyHTTPSHandler, \
    WebProxyHTTPHandler, WebProxyHTTPSHandler, NoRedirectHandler
from core import bbdd, filetools, httptools, jsontools, logger, mediainfo
from core import moduletools, proxytools, scrapertools, servertools, settings
from core.item import Languages, Qualities, Item, Video, Language, Quality
from core.mediainfo import MediaInfo
from platformcode import platformtools, platformsettings

# Declaramos los objetos disponibles
__all__ = [
    'datetime',
    'inspect',
    'sys',
    'os',
    're',
    'time',
    'Lock',
    'RLock',
    'urllib_parse',
    'reduce',
    'reload_module',
    'six',
    'Thread', 'LimitResults', 'ResolveProgress', 'ResolveError', 'Resolver', 'change_units', 'call_api',
    'HTTPHandler', 'HTTPSHandler', 'HTTPRedirectHandler', 'ProxyHTTPHandler', 'ProxyHTTPSHandler',
    'WebProxyHTTPHandler', 'WebProxyHTTPSHandler', 'NoRedirectHandler',
    'sysinfo',
    'servertools',
    'settings',
    'logger',
    'jsontools',
    'moduletools',
    'scrapertools',
    'filetools',
    'Languages', 'Qualities', 'Item', 'Video', 'Language', 'Quality',
    'platformtools',
    'platformsettings',
    'httptools',
    'mediainfo',
    'MediaInfo',
    'bbdd',
    'proxytools'
]


# Reloads
def repair_imports():
    """
    Aquí es donde se hace la 'magia': En este modulo importamos todos los modulos que estarán disponibles cuando hagamos
    'from core.libs import *'

    El objetivo de esto es evitar problemas cuando varios modulos se imporan entre si.

    ¿Pero que pasa si un modulo (modulo X) de los que importamos aqui ejecuta a su vez 'from core.libs import *'?
    Pues que encore.libs se van importando en el orden que están los imports, cuando aqui importamos el 'modulo X' y
    este vuelve a importar core.libs en core.libs solo están disponibles los moudlos importados hasta el 'modulo X' y
    los siguientes no estaran disponibles para el 'modulo X'

    Lo que hacemos para solucionarlo es: Despues de importar todos los modulos, buscamos todos los modulos importados
    (que sean de MediaExplorer) y en caso no tener disponible alguno de los objetos importados se los añadimos.

    Para esto tenemos la variable __all__ que contiene un listado con todos los objetos (modulos, clases, funciones)
    que se importaran al hacer from core.libs import * si añadimos algun objeto en este modulo hay que añadirlo a la
    variable __all__ para que pueda importarse.

    Limitaciones:
        - Los modulos que importemos en este modulo que a la vez importen core.libs (o importer un tercer modulo que
        importe core.libs) puede que no tengan disponibles todos los objetos importados en el momento de importar el
        modulo por tanto no pueden usarse directamente en el modulo (si pueden usarse dentro de una función) si se
        necesita ejectuar algo al importar el modulo debe ponerse una función y llamar a esa función desde este modulo
        en la sección 'Inits' despues de repair_imports().

        - Las clases que derivan de otras, si los dos modulos (el que se crea la clase y en el que esta la clase de la
        que deriva) importan core.libs, puede darse el mismo problema (depende del orden de los imports), pero no me he
        encotrado ningun caso que cumpla esas condiciones, y no creo que se de ya que es un escenario poco probable.

    :return:
    """
    for obj in sys.modules.values():
        if not obj:
            continue
        module = inspect.getmodule(obj)
        if hasattr(module, '__file__') and module.__file__.startswith(sysinfo.runtime_path):
            for prop in __all__:
                if not hasattr(module, prop):
                    setattr(module, prop, getattr(sys.modules[__name__], prop))


# Añadir modulos en data al path
sys.path.append(os.path.join(sysinfo.data_path, 'modules', 'lib'))
sys.path.append(os.path.join(sysinfo.data_path, 'modules'))

# Inits
repair_imports()
logger.init_logger()
settings.check_directories()
httptools.load_cookies()
sysinfo.profile = platformtools.get_profile()[1]
bbdd.create()

# fix for datatetime.strptime returns None
if sys.version_info[0] < 3:
    datetime.datetime = ProxyDT
