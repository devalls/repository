# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://repelis.io'

LNG = Languages({
    Languages.es: ['es-es'],
    Languages.sub_es: ['en'],
    Languages.la: ['es-mx']
})

QLT = Qualities({
    Qualities.hd_full: ['high'],
    Qualities.hd: ['good'],
    Qualities.rip: ['low'],
})


def mainlist(item):
    logger.trace()

    itemlist = list()

    item.category='movie'
    item.thumb='thumb/movie.png'
    item.icon='icon/movie.png'
    item.poster='poster/movie.png'
    item.type="item"

    itemlist.append(item.clone(
        label="Novedades",
        action='movies',
        content_type='movies',
        url=HOST + '/explorar'
    ))


    itemlist.append(item.clone(
        action="movies",
        label="Castellano",
        url=HOST + '/peliculas-castellano',
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action='movies',
        label='Latino',
        url=HOST + '/peliculas-latino',
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action='movies',
        label='Subtitulado',
        url=HOST + '/peliculas-subtituladas',
        content_type='movies'
    ))

    itemlist.append(item.clone(
        label="Géneros",
        action='generos',
        content_type='items',
        url=HOST
    ))

    itemlist.append(item.clone(
        label="Buscar",
        action='search',
        content_type='movies',
        url=HOST,
        type='search',
        query=True
    ))

    return itemlist


def search(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(
        'https://repelis.io/graph/',
        post='{"query":"query ($term: String) {movies: allMovies(search: $term) {id slug title rating releaseDate released poster nowPlaying}}",'
             '"variables":{"term":"%s"}}' % item.query,
        headers={'Content-Type': 'application/json;charset=utf-8'}
    ).data

    videos = jsontools.load_json(data)
    for movie in videos['data']['movies']:
        itemlist.append(item.clone(
            type='movie',
            title=movie['title'],
            year=movie['releaseDate'].split('-')[0],
            action='findvideos',
            movieId=movie['id'],
            poster=HOST + '/_images/posters/%s/180x270.jpg' % (movie['poster']),
            content_type='servers'
        ))

    return itemlist


def generos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    patron = '<a href="(?P<url>/genero/[^"]+)">(?P<label>[^<]+)</a>'
    for match in re.finditer(patron, data):
        itemlist.append(item.clone(
            label=match.group('label'),
            url=HOST + match.group('url'),
            action='movies',
            content_type='movies'
        ))

    return sorted(itemlist, key=lambda i: i.label)


def movies(item):
    logger.trace()

    itemlist = list()
    data = httptools.downloadpage(item.url).data

    videos = jsontools.load_json(scrapertools.find_single_match(data, r'window.__NUXT__=(.*?);</script>'))

    for movie in videos['data'][0]['movies']:
        itemlist.append(item.clone(
            type='movie',
            title=movie['title'],
            year=movie['releaseDate'].split('-')[0],
            action='findvideos',
            url=HOST + '/pelicula/%s-%s' % (movie['slug'], movie['id']),
            poster=HOST + '/_images/posters/%s/180x270.jpg' % (movie['poster']),
            content_type='servers'
        ))

    """
    if itemlist:
        next_url = scrapertools.find_single_match(data, '<span>Anterior</span>.*?<a href="([^"]+)".*?<span>Siguiente</span>')
        if next_url:
            itemlist.append(item.clone(url=HOST + next_url, type='next'))
    """

    return itemlist


def findvideos(item):
    logger.trace()
    itemlist = list()

    if item.query:
        data = httptools.downloadpage('https://repelis.io/graph',
                                      post= '{"query":"query($movieId: ID!) {movie: Movie (id: $movieId) {mirrors { id quality audio type url hostname}}}",'
                                            '"variables":{"movieId":"%s"}}' % item.movieId,
                                      headers={'Content-Type': 'application/json;charset=utf-8'}
                                      ).data
        data = jsontools.load_json(data)
        mirrors = data['data']['movie']['mirrors']

    else:
        data = httptools.downloadpage(item.url).data
        data = jsontools.load_json(scrapertools.find_single_match(data, r'window.__NUXT__=(.*?);</script>'))
        mirrors = data['data'][0]['movie']['mirrors']

    for server in mirrors:
        itemlist.append(item.clone(
            type='server',
            server=server['hostname'].split('.')[0],
            action='play',
            url=HOST + server['url'],
            lang=LNG.get(server['audio']),
            quality=QLT.get(server['quality']),
            stream=server['type'] == 'stream'

        ))
    itemlist = servertools.get_servers_from_id(itemlist)
    return itemlist


def play(item):
    logger.trace()
    if item.url.startswith(HOST):
        item.url = httptools.downloadpage(item.url, follow_redirects=False).headers.get('location')
    servertools.normalize_url(item)
