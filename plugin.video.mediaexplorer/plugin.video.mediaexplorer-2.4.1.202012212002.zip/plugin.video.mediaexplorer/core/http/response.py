# -*- coding: utf-8 -*-
class HTTPResponse:
    """
    Clase que representa una respuesta de una solicitud http.
    """
    def __init__(self, response):
        self.sucess = None
        self.code = None
        self.error = None
        self.headers = None
        self.cookies = None
        self.data = None
        self.time = None
        self.url = None
        self.__dict__ = response


