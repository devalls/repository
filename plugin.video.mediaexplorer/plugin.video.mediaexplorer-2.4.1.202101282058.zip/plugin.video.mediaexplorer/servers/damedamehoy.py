# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = jsontools.load_json(httptools.downloadpage(item.url).data)
    itemlist.append(Video(url=data['file']))

    return itemlist
