# -*- coding: utf-8 -*-

from core.libs import *
from core.js import JS


def get_video_url(item):
    logger.trace()
    itemlist = []
    js = JS()

    # Obtenemos la redireccion
    item.url = httptools.downloadpage(item.url, follow_redirects=False).headers.get('location', item.url)

    # Generamos las URLS
    url = item.url.replace('embed', 'player')

    yield ResolveProgress(10, 0)
    data = httptools.downloadpage(item.url, headers={'Referer': item.referer}).data
    sitekey = scrapertools.find_single_match(data, "grecaptcha.render.*?sitekey: '([^']+)'")
    action = scrapertools.find_single_match(data, "grecaptcha.render.*?sitekey: '[^']+', '([^']+)'")

    yield ResolveProgress(20, 4)
    token = platformtools.show_recaptcha(
        siteurl=item.url,
        sitekey=sitekey,
        action=action,
        min_score='0.9',
        silent=True
    )

    if not token:
        yield ResolveError(7)
        return

    # Descargamos los datos
    yield ResolveProgress(30, 0)
    data = httptools.downloadpage(url, headers={'referer': item.url}, post={
        'op': 'embed',
        'token': token
    }).data

    if "File was deleted" in data:
        yield ResolveError(0)
        return

    elif 'Video is processing now.' in data:
        yield ResolveError(1)
        return

    yield ResolveProgress(40, 3)
    unpacked = js.run_js(
        "python.sendResponse(%s)" % scrapertools.find_single_match(
            data,
            r"<script type=[\"']text/javascript[\"']>eval(.*?)</script>"
        )
    )

    yield ResolveProgress(60, 1)
    sources = scrapertools.find_single_match(unpacked, r"sources=(.*?);")
    script = scrapertools.find_single_match(data, r'(var _0x[^=]+=[^\n]+ABCDEFGHIJKLMNOPQRSTUVWXYZ[^\n]+)')

    yield ResolveProgress(80, 2)
    code = """
        var data = {};
        $=function(a, b){
            if (['body', 'div:first'].indexOf(a) > -1){
                return {'data': $}
            }else if (b != undefined){
                data[a] = b
            }else{
                return data[a]
            }
        }
        $.map = function(e, t, n){
            s = []
            for (o=0; o<e.length; o++){
                s.push(t(e[o], o, n))
            }
            return s
        }
        %s
        var image=''; 
        var tracks = []; 
        var sources = %s
        sources.size();
        python.sendResponse(JSON.stringify(sources))""" % (script, sources.replace('src', 'file'))

    sources = jsontools.load_json(
        js.run_js(
            code,
            userAgent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0"  # Android
        )
    )

    for url in sources:
        url['file'] = url['file'].replace("rtmp://https://", 'rtmp://')
        itemlist.append(Video(url=url['file']))

    yield itemlist
