# -*- coding: utf-8 -*-
from core.libs import *
import jsbeautifier

def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data
    packed = scrapertools.find_single_match(data, "<script>.*?(eval.*?)</script>")
    unpacked = jsbeautifier.beautify(packed)
    url = scrapertools.find_single_match(unpacked, 'MDCore.(?:vsrc?1?|furl|wurl) = "(//[^"]+)')

    if url:
        itemlist.append(Video(url='https:' + url))

    return itemlist
