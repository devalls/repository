# -*- coding: utf-8 -*-
from core.libs import *
import jsbeautifier

def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    list_urls= []
    for packed in  scrapertools.find_multiple_matches(data, "<script>.*?(eval.*?)</script>"):
        if "function(p,a,c,k,e,d)" in packed:
            unpacked = jsbeautifier.beautify(packed)

            src = scrapertools.find_single_match(unpacked, ",src.*?'([^']+)")
            if src:
                url = httptools.downloadpage(src, only_headers=True, follow_redirects=False).headers.get('location', '')

                if url and url not in list_urls:
                    itemlist.append(Video(url=url))
                    list_urls.append(url)

    return itemlist