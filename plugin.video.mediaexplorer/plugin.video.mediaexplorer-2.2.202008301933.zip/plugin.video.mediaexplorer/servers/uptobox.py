# -*- coding: utf-8 -*-
from core.libs import *

def get_video_url(item):
    logger.trace()
    itemlist = []

    token = settings.get_setting('token', __file__)
    if not token:
        try:
            user = settings.get_setting('user', __file__)
            password = settings.get_setting('password', __file__)
            if user and password:
                httptools.downloadpage("https://uptobox.com/login?referer=homepage", post={'login':user,'password':password})
                data = httptools.downloadpage("https://uptobox.com/my_account").data
                token = scrapertools.find_single_match(data,"Token:\s*<span class='to-clipboard'><span class='none'>([^<]+)</span></span>")
                settings.set_setting('token',token,__file__)
            if not token:
                raise ()
        except:
            return ResolveError('Es necesario estar registrado en este servidor.')

    try:
        _url = 'https://uptobox.com/api/streaming?file_code=%s' % item.url
        data = httptools.downloadpage(_url).data

        pin = scrapertools.find_single_match(data,r'"pin":"([^"]+)')
        check_url =  scrapertools.find_single_match(data, r'"check_url":"([^"]+)').replace('\/', '/')

        _url = 'https://uptobox.com/api/user/pin/validate?token=%s' % token
        httptools.downloadpage(_url, post='{"pin": "%s"}' % pin).data
        js_data = jsontools.load_json(httptools.downloadpage(check_url).data)['data']
        #logger.debug(js_data)

        subtitles = list()
        for s in js_data.get('subs', []):
            subtitles.append(s['src'])

        lng = {'spa': 'Español ', 'fre': 'Frances ', 'eng': 'Inglés ', 'rus': 'Ruso ', 'ger': 'Aleman '}
        for res, v in js_data['streamLinks'].items():
            for l, scr in v.items():
                itemlist.append(Video(label="Ver el video: %s[%sp]" % (lng.get(l, ''), res),
                                      url=scr, res=res, subtitles=subtitles))

    except:
        return ResolveError(0)

            
    return itemlist
