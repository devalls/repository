# -*- coding: utf-8 -*-

import os, re, xbmcgui

from platformcode import config, logger, platformtools
from core.item import Item
from core import httptools, scrapertools, servertools, tmdb, jsontools


host = 'https://playdede.com/'

perpage = 30

class login_dialog(xbmcgui.WindowDialog):
    def __init__(self):
        avis = True
        if config.get_setting('playdede_username', 'playdede', default=False): 
            if config.get_setting('playdede_password', 'playdede', default=False):
                if config.get_setting('playdede_login', 'playdede', default=False):
                    avis = False

        if avis:
            self.login_result = False
            platformtools.dialog_ok("Recomendación Balandro - PlayDede", '[COLOR yellow]Sugerimos crear una nueva cuenta para registrarse en la web, no deberiais indicar ninguna de vuestras cuentas personales.[/COLOR]', 'Para más detalles al respecto, acceda a la Ayuda, apartado Uso, Información dominios que requieren registrase.')

        self.background = xbmcgui.ControlImage(250, 150, 800, 355, filename="https://raw.githubusercontent.com/romanvm/script.module.pyxbmct/master/script.module.pyxbmct/lib/pyxbmct/textures/estuary/AddonWindow/ContentPanel.png")
        self.addControl(self.background)
        self.icon = xbmcgui.ControlImage(265, 220, 225, 225, filename=config.get_thumb('playdede', 'thumb', 'channels'))
        self.addControl(self.icon)
        self.username = xbmcgui.ControlEdit(530, 320, 400, 120, 'Indicar su usuario: ', font='font13', textColor='0xDD171717', focusTexture="https://raw.githubusercontent.com/romanvm/script.module.pyxbmct/master/script.module.pyxbmct/lib/pyxbmct/textures/estuary/Edit/button-focus.png", noFocusTexture="https://raw.githubusercontent.com/romanvm/script.module.pyxbmct/master/script.module.pyxbmct/lib/pyxbmct/textures/estuary/Edit/black-back2.png")
        self.addControl(self.username)
        if platformtools.get_kodi_version()[1] >= 18:
            self.password = xbmcgui.ControlEdit(530, 320, 400, 120, 'Indicar la contraseña: ', font='font13', textColor='0xDD171717', focusTexture="https://raw.githubusercontent.com/romanvm/script.module.pyxbmct/master/script.module.pyxbmct/lib/pyxbmct/textures/estuary/Edit/button-focus.png", noFocusTexture="https://raw.githubusercontent.com/romanvm/script.module.pyxbmct/master/script.module.pyxbmct/lib/pyxbmct/textures/estuary/Edit/black-back2.png")
        else:
            self.password = xbmcgui.ControlEdit(530, 320, 400, 120, 'Indicar la contraseña: ', font='font13', textColor='0xDD171717', focusTexture="https://raw.githubusercontent.com/romanvm/script.module.pyxbmct/master/script.module.pyxbmct/lib/pyxbmct/textures/estuary/Edit/button-focus.png", noFocusTexture="https://raw.githubusercontent.com/romanvm/script.module.pyxbmct/master/script.module.pyxbmct/lib/pyxbmct/textures/estuary/Edit/black-back2.png", isPassword=True)

        self.buttonOk = xbmcgui.ControlButton(588, 460, 125, 25, 'Confirmar', alignment=6, focusTexture="https://raw.githubusercontent.com/romanvm/script.module.pyxbmct/master/script.module.pyxbmct/lib/pyxbmct/textures/estuary/Edit/button-focus.png", noFocusTexture="https://raw.githubusercontent.com/romanvm/script.module.pyxbmct/master/script.module.pyxbmct/lib/pyxbmct/textures/estuary/Edit/black-back2.png")
        self.buttonCancel = xbmcgui.ControlButton(720, 460, 125, 25, 'Cancelar', alignment=6, focusTexture="https://raw.githubusercontent.com/romanvm/script.module.pyxbmct/master/script.module.pyxbmct/lib/pyxbmct/textures/estuary/Edit/button-focus.png", noFocusTexture="https://raw.githubusercontent.com/romanvm/script.module.pyxbmct/master/script.module.pyxbmct/lib/pyxbmct/textures/estuary/Edit/black-back2.png")
        self.addControl(self.password)
        self.password.setVisible(True)
        self.password.controlUp(self.username)
        self.addControl(self.buttonOk)
        self.password.controlDown(self.buttonOk)
        self.username.setLabel('Indicar su usuario: ')
        if int(platformtools.get_kodi_version()[1]) >= 18:
            self.password.setType(xbmcgui.INPUT_TYPE_PASSWORD, 'Indicar la contraseña: ')

        self.password.setLabel('Indicar la contraseña: ')
        self.setFocus(self.username)
        self.username.controlUp(self.buttonOk)
        self.username.controlDown(self.password)
        self.buttonOk.controlUp(self.password)
        self.buttonOk.controlDown(self.username)
        self.buttonOk.controlRight(self.buttonCancel)
        self.buttonOk.controlLeft(self.buttonCancel)
        self.addControl(self.buttonCancel)
        self.buttonCancel.controlRight(self.buttonOk)
        self.buttonCancel.controlLeft(self.buttonOk)
        self.username.setPosition(500, 210)
        self.username.setWidth(500)
        self.username.setHeight(50)
        self.password.setPosition(500, 300)
        self.password.setWidth(500)
        self.password.setHeight(50)

        self.doModal()

        if self.username.getText() and self.password.getText():
            config.set_setting('playdede_username', self.username.getText(), 'playdede')
            config.set_setting('playdede_password', self.password.getText(), 'playdede')
            config.set_setting('playdede_login', True, 'playdede')
            self.login_result = True

    def onControl(self, control):
        control = control.getId()
        if control in range(3000, 30010):
            self.close()

def do_make_login_logout(url, post=None, headers=None):
    # ~ data = httptools.downloadpage(url, post=post, headers=headers).data
    data = httptools.downloadpage_proxy('playdede', url, post=post, headers=headers).data

    return data


def login(item):
    logger.info()

    status = config.get_setting('playdede_login', 'playdede', default=False)

    username = config.get_setting('playdede_username', 'playdede', default='')
    password = config.get_setting('playdede_password', 'playdede', default='')

    if not username or not password:
        login = login_dialog()
        if not login.login_result: return False

        if not item:
            platformtools.dialog_notification(config.__addon_name, '[COLOR yellow]Credenciales guardadas[/COLOR]')
            return False

    username = config.get_setting('playdede_username', 'playdede', default='')
    password = config.get_setting('playdede_password', 'playdede', default='')

    try:
       data = do_downloadpage(host)

       user = scrapertools.find_single_match(data, username).strip()

       if user:
           if username:
               if username in user:
                   if not status:
                       config.set_setting('playdede_login', True, 'playdede')
                   if not item:
                       platformtools.dialog_notification(config.__addon_name, '[COLOR chartreuse]Login correcto[/COLOR]')
                   return True

       if 'UserOn' in data:
           if not status:
               config.set_setting('playdede_login', True, 'playdede')
               if not item:
                   platformtools.dialog_notification(config.__addon_name, '[COLOR chartreuse]Login correcto[/COLOR]')
           return True
    except:
       platformtools.dialog_notification(config.__addon_name, '[COLOR red]Sin acceso a la Web[/COLOR]')
       return False

    post = {'user': username, 'pass': password, '_method': 'auth/login'}

    try:
       data = do_downloadpage(host + 'ajax.php', post=post)

       jdata = jsontools.load(data)

       if not jdata['alert']:
           platformtools.dialog_notification(config.__addon_name, '[COLOR chartreuse]Login correcto[/COLOR]')
           config.set_setting('playdede_login', True, 'playdede')
           return True
       elif bool(jdata['reload']):
           platformtools.dialog_notification(config.__addon_name, '[COLOR chartreuse]Login correcto[/COLOR]')
           config.set_setting('playdede_login', True, 'playdede')
           return True
       else:
           platformtools.dialog_notification(config.__addon_name, '[COLOR red]Login incorrecto[/COLOR]')
           return False
    except:
       platformtools.dialog_notification(config.__addon_name, '[COLOR red]Sin acceso al Login[/COLOR]')
       return False

    if not httptools.get_cookie(host, 'MoviesWebsite'):
        do_downloadpage(host)

    if httptools.get_cookie(host, 'utoken'):
        platformtools.dialog_notification(config.__addon_name, '[COLOR chartreuse]Login correcto[/COLOR]')
        config.set_setting('playdede_login', True, 'playdede')
        return True

    try:
       do_make_login_logout(host + 'ajax.php', post=post, headers={'Origin': host})
       do_make_login_logout(host)
    except:
       pass

    if httptools.get_cookie(host, 'utoken'):
        platformtools.dialog_notification(config.__addon_name, '[COLOR chartreuse]Login correcto[/COLOR]')
        config.set_setting('playdede_login', True, 'playdede')
        return True

    platformtools.dialog_notification(config.__addon_name, '[COLOR red]Login incorrecto[/COLOR]')
    return False


def logout(item):
    logger.info()

    url = "%slogout" %(host)

    data = do_make_login_logout(url)

    config.set_setting('playdede_login', False, 'playdede')

    platformtools.dialog_notification(config.__addon_name, '[COLOR yellow]Sesión cerrada[/COLOR]')
    return 


def item_configurar_proxies(item):
    plot = 'Es posible que para poder utilizar este canal necesites configurar algún proxy, ya que no es accesible desde algunos países/operadoras.'
    plot += '[CR]Si desde un navegador web no te funciona el sitio ' + host + ' necesitarás un proxy.'
    return item.clone( title = 'Configurar proxies a usar ...', action = 'configurar_proxies', folder=False, plot=plot, text_color='red' )

def configurar_proxies(item):
    from core import proxytools
    return proxytools.configurar_proxies_canal(item.channel, host)


def do_downloadpage(url, post=None, referer=None):
    # ~ por si viene de enlaces guardados posteriores
    if url.startswith('/'):  # ~ solo v. 2.0.0
        url = host + url[1:]

    headers = {}

    if referer:
        headers = {'Referer': referer}
    else:
        headers = {'Referer': host}

    timeout = None
    if '/?genre=' in url:
        timeout = 50

    # ~ data = httptools.downloadpage(url, post=post, headers=headers, raise_weberror=False).data
    data = httptools.downloadpage_proxy('playdede', url, post=post, headers=headers, raise_weberror=False, timeout=timeout).data

    if "data-showform='login'" in data:
        if not config.get_setting('playdede_login', 'playdede', default=False):
            platformtools.dialog_notification(config.__addon_name, '[COLOR yellow][B]Debe iniciar la sesión[/B][/COLOR]')

        login('')
        return do_downloadpage(url, post=post, referer=referer)

    return data


def mainlist(item):
    logger.info()
    itemlist = []

    if not config.get_setting('playdede_login', 'playdede', default=False):
        itemlist.append(item_configurar_proxies(item))

        itemlist.append(item.clone( title = '[COLOR teal]Iniciar sesión[/COLOR]', action = 'login' ))

    if config.get_setting('playdede_login', 'playdede', default=False):
        itemlist.append(item.clone( title = 'Películas', action = 'mainlist_pelis' ))
        itemlist.append(item.clone( title = 'Series', action = 'mainlist_series' ))
        itemlist.append(item.clone( title = 'Anime', action = 'mainlist_anime' ))

        itemlist.append(item.clone( title = 'Listas', action = 'list_listas', search_type = 'all' ))

        itemlist.append(item.clone( title = 'Buscar ...', action = 'search', search_type = 'all' ))

        itemlist.append(item_configurar_proxies(item))

        itemlist.append(item.clone( title = '[COLOR teal]Menú Usuario[/COLOR]', action = 'mainlist_login', search_type = 'all' ))

    return itemlist


def mainlist_pelis(item):
    logger.info()
    itemlist = []

    if not config.get_setting('playdede_login', 'playdede', default=False):
        itemlist.append(item_configurar_proxies(item))

        itemlist.append(item.clone( title = '[COLOR teal]Iniciar sesión[/COLOR]', action = 'login' ))

    if config.get_setting('playdede_login', 'playdede', default=False):
        itemlist.append(item.clone( title = 'Catálogo', action = 'list_all', url = host + 'peliculas/', search_type = 'movie' ))
        itemlist.append(item.clone( title = 'Estrenos', action = 'list_all', url = host + 'peliculas/estrenos/', search_type = 'movie' ))
        itemlist.append(item.clone( title = 'Más valoradas', action = 'list_all', url = host + 'peliculas/mejor-valoradas/', search_type = 'movie' ))

        itemlist.append(item.clone( title = 'Por género', action = 'generos', search_type = 'movie' ))
        itemlist.append(item.clone( title = 'Por año', action = 'anios', search_type = 'movie' ))

        itemlist.append(item.clone( title = 'Listas', action = 'list_listas', search_type = 'all' ))

        itemlist.append(item.clone( title = 'Buscar película ...', action = 'search', search_type = 'movie' ))

        itemlist.append(item_configurar_proxies(item))

        itemlist.append(item.clone( title = '[COLOR teal]Menú Usuario[/COLOR]', action = 'mainlist_login', search_type = 'all' ))

    return itemlist


def mainlist_series(item):
    logger.info()
    itemlist = []

    if not config.get_setting('playdede_login', 'playdede', default=False):
        itemlist.append(item_configurar_proxies(item))

        itemlist.append(item.clone( title = '[COLOR teal]Iniciar sesión[/COLOR]', action = 'login' ))

    if config.get_setting('playdede_login', 'playdede', default=False):
        filters = '?genre_id=0&language=0&sublanguage=0&quality=2'

        itemlist.append(item.clone( title = 'Catálogo', action = 'list_all', url = host + 'series/', search_type = 'tvshow' ))
        itemlist.append(item.clone( title = 'Novedades', action = 'list_all', url = host + 'series/novedades/', search_type = 'tvshow' ))
        itemlist.append(item.clone( title = 'Más valoradas', action = 'list_all', url = host + 'series/mejor-valoradas/', search_type = 'tvshow' ))

        itemlist.append(item.clone( title = 'Por género', action = 'generos', search_type = 'tvshow' ))
        itemlist.append(item.clone( title = 'Por año', action = 'anios', search_type = 'tvshow' ))

        itemlist.append(item.clone( title = 'Listas', action = 'list_listas', search_type = 'all' ))

        itemlist.append(item.clone( title = 'Buscar serie ...', action = 'search', search_type = 'tvshow' ))

        itemlist.append(item_configurar_proxies(item))

        itemlist.append(item.clone( title = '[COLOR teal]Menú Usuario[/COLOR]', action = 'mainlist_login', search_type = 'all' ))

    return itemlist


def mainlist_anime(item):
    logger.info()
    itemlist = []

    if not config.get_setting('playdede_login', 'playdede', default=False):
        itemlist.append(item_configurar_proxies(item))

        itemlist.append(item.clone( title = '[COLOR teal]Iniciar sesión[/COLOR]', action = 'login' ))

    if config.get_setting('playdede_login', 'playdede', default=False):
        itemlist.append(item.clone( title = 'Catálogo', action = 'list_all', url = host + 'animes/', search_type = 'tvshow' ))
        itemlist.append(item.clone( title = 'Novedades', action = 'list_all', url = host + 'animes/novedades/', search_type = 'tvshow' ))
        itemlist.append(item.clone( title = 'Más valoradas', action = 'list_all', url = host + 'animes/mejor-valoradas/', search_type = 'tvshow' ))

        itemlist.append(item.clone( title = 'Por género', action = 'generos', group = 'anime', search_type = 'tvshow' ))
        itemlist.append(item.clone( title = 'Por año', action = 'anios', group = 'anime', search_type = 'tvshow' ))

        itemlist.append(item.clone( title = 'Listas', action = 'list_listas', search_type = 'all' ))

        itemlist.append(item.clone( title = 'Buscar anime ...', action = 'search', search_type = 'tvshow' ))

        itemlist.append(item_configurar_proxies(item))

        itemlist.append(item.clone( title = '[COLOR teal]Menú Usuario[/COLOR]', action = 'mainlist_login', search_type = 'all' ))

    return itemlist


def mainlist_login(item):
    logger.info()
    itemlist = []

    if not config.get_setting('playdede_login', 'playdede', default=False):
        itemlist.append(item_configurar_proxies(item))

        itemlist.append(item.clone( title = '[COLOR teal]Iniciar nueva sesión[/COLOR]', action = 'login' ))

    if config.get_setting('playdede_login', 'playdede', default=False):
        itemlist.append(item.clone( title = '[COLOR chartreuse]Cerrar sesión[/COLOR]', action = 'logout' ))

    return itemlist


def generos(item):
    logger.info()
    itemlist = []

    if not item.group:
        if item.search_type == 'movie':
            url_generos = host + 'peliculas/'
        else:
            url_generos = host + 'series/'
    else:
        url_generos = host + 'animes/'

    data = do_downloadpage(url_generos)

    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    matches = re.compile('<li class="cfilter " data-type="genre" data-value="([^"]+)"><img src="[^"]+"><b>([^<]+)').findall(data)

    url_generos = url_generos  + "?genre="

    for genre_id, title in matches:
        url = url_generos + genre_id + "&year="

        itemlist.append(item.clone( title = title, action = 'list_all', url = url ))

    if item.search_type == 'movie':
        itemlist.append(item.clone( title = 'Aventura', action = 'list_all', url = url_generos + "aventura&year=" ))
        itemlist.append(item.clone( title = 'Documental', action = 'list_all', url = url_generos + "documental&year=" ))
        itemlist.append(item.clone( title = 'Fantasía', action = 'list_all', url = url_generos + "fantasia&year=" ))
        itemlist.append(item.clone( title = 'Historia', action = 'list_all', url = url_generos + "historia&year=" ))

    return sorted(itemlist,key=lambda x: x.title)


def anios(item):
    logger.info()
    itemlist = []

    tope_year = 1969

    if not item.group:
        if item.search_type == 'movie':
            url_anios = host + 'peliculas/'
        else:
            url_anios = host + 'series/'
    else:
        url_anios = host + 'animes/'

    url_anios = url_anios + '?genre=&year='

    from datetime import datetime
    current_year = int(datetime.today().year)

    for x in range(current_year, tope_year, -1):
        itemlist.append(item.clone( title = str(x), url = url_anios + str(x), action = 'list_all' ))

    return itemlist


def list_all(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 0

    data = do_downloadpage(item.url)

    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    matches = re.compile('<article id="([^"]+)".*?<a href="([^"]+)">.*?<img src="([^"]+).*?<p>(\d+)</p>\s*<h3>([^<]+)').findall(data)

    num_matches = len(matches)

    for id, url, thumb, year, title in matches[item.page * perpage:]:
        if not url or not title: continue

        if not item.search_type == "all":
            if item.search_type == "movie":
                if '/serie/' in url: continue
            else:
                if '/pelicula/' in url: continue

        if '/pelicula/' in url:
            sufijo = '' if item.search_type != 'all' else 'movie'

            itemlist.append(item.clone( action='findvideos', url=url, title=title, thumbnail=thumb, fmt_sufijo=sufijo,
                                        contentType='movie', contentTitle=title, infoLabels={'year': year} ))
        else:
            sufijo = '' if item.search_type != 'all' else 'tvshow'

            itemlist.append(item.clone( action='temporadas', url=url, title=title, thumbnail=thumb, fmt_sufijo=sufijo, 
                                        contentType = 'tvshow', contentSerieName = title, infoLabels={'year':year} ))

        if len(itemlist) >= perpage: break

    tmdb.set_infoLabels(itemlist)

    buscar_next = True
    if num_matches > perpage:
        hasta = (item.page * perpage) + perpage
        if hasta < num_matches:
            itemlist.append(item.clone( title = '>> Página siguiente', page = item.page + 1, action = 'list_all', text_color = 'coral' ))
            buscar_next = False

    if buscar_next:
        if itemlist:
            if '<div class="pagPlaydede">' in data:
                if 'Pagina Anterior' in data:
                    patron = '<div class="pagPlaydede">.*?Pagina Anterior.*?<a href="([^"]+)'
                else:
                    patron = '<div class="pagPlaydede"><a href="([^"]+)'

                next_url = scrapertools.find_single_match(data, patron)
                if next_url:
                    itemlist.append(item.clone( title = '>> Página siguiente', url = next_url, action = 'list_all', page = 0, text_color = 'coral' ))

    return itemlist


def list_listas(item):
    logger.info()
    itemlist = []

    if not item.url:
        url = host + 'listas/'
    else:
        url = item.url

    data = do_downloadpage(url)

    data = re.sub('\\n|\\r|\\t|\\s{2}|&nbsp;', '', data)

    matches = re.compile('<article>.*?<a href="([^"]+)"[^<]+<h2>([^<]+)</h2>').findall(data)

    for url, title in matches:
        itemlist.append(item.clone( action = 'list_all', title = title, url = url ))

    if itemlist:
        if '<div class="pagPlaydede">' in data:
            if 'Pagina Anterior' in data:
                patron = '<div class="pagPlaydede">.*?Pagina Anterior.*?<a href="([^"]+)'
            else:
                patron = '<div class="pagPlaydede"><a href="([^"]+)'

            next_url = scrapertools.find_single_match(data, patron)
            if next_url:
                itemlist.append(item.clone( title = '>> Página siguiente', url = next_url, action = 'list_listas', text_color = 'coral' ))

    return itemlist


def temporadas(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)

    matches = re.compile("<div class='clickSeason(?: clickAc| )' data-season='(\d+)'", re.DOTALL).findall(data)

    if len(matches) > 25:
        platformtools.dialog_notification('PlayDede', '[COLOR blue]Cargando Temporadas[/COLOR]')

    for tempo in matches:
        title = 'Temporada ' + tempo

        if len(matches) == 1:
            platformtools.dialog_notification(item.contentSerieName.replace('&#038;', '&'), 'solo [COLOR tan]' + title + '[/COLOR]')
            item.page = 0
            item.contentType = 'season'
            item.contentSeason = int(tempo)
            itemlist = episodios(item)
            return itemlist

        itemlist.append(item.clone( action = 'episodios', title = title, contentType = 'season', contentSeason = int(tempo), page = 0 ))

    tmdb.set_infoLabels(itemlist)

    return itemlist


def episodios(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 0
    perpage = 50

    data = do_downloadpage(item.url)

    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    data = scrapertools.find_single_match(data, "<div class='se-c' data-season='%d'(.*?)<\/div><\/div>" % (item.contentSeason))

    patron = '<a href="([^"]+)"><div class="imagen">'
    patron += '<img src="([^"]+)"><\/div>.*?<div class="epst">([^<]+)'
    patron += '<\/div><div class="numerando">([^<]+)'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for url, thumb, titulo, name in matches[item.page * perpage:]:
        s_e = scrapertools.get_season_and_episode(name)
        season = int(s_e.split("x")[0])
        episode = s_e.split("x")[1]

        title = str(season) + 'x' + str(episode) + ' ' + titulo

        itemlist.append(item.clone( action='findvideos', url = url, title = title, thumbnail=thumb,
                                    contentType = 'episode', contentSeason = season, contentEpisodeNumber=episode ))

        if len(itemlist) >= perpage:
            break

    tmdb.set_infoLabels(itemlist)

    if len(matches) > ((item.page + 1) * perpage):
        itemlist.append(item.clone( title=">> Página siguiente", action="episodios", page=item.page + 1, text_color='coral' ))

    return itemlist


def findvideos(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)

    data = re.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', data)

    # ~ Reproductor
    patron = '<div class="playerItem.*?data-lang="(.*?)" data-loadPlayer="(.*?)".*?<h3>(.*?)</h3>.*?">Calidad:.*?">(.*?)</span>'

    matches = re.compile(patron, re.DOTALL).findall(data)

    ses = 0

    for lang, sid, server, qlty in matches:
        ses += 1

        if not server or not sid: continue

        if lang.lower() == 'espsub':
            lang = 'Vose'

        lang = lang.capitalize()
        server = servertools.corregir_servidor(server)

        itemlist.append(Item( channel = item.channel, action = 'play', server = server, title = '', id = sid, language = lang, quality = qlty ))

    # ~ Enlaces
    bloque = scrapertools.find_single_match(data, '<div class="linkSorter">(.*?)<div class="contEP contepID_3">')

    matches = re.compile('data-quality="(.*?)" data-lang="(.*?)".*?href="(.*?)".*?<span>.*?">(.*?)</b>', re.DOTALL).findall(bloque)

    for qlty, lang, url, server in matches:
        ses += 1

        if not url or not server: continue

        if lang.lower() == 'espsub':
            lang = 'Vose'

        lang = lang.capitalize()
        server = servertools.corregir_servidor(server)

        itemlist.append(Item( channel = item.channel, action = 'play', server = server, title = '', url = url, language = lang, quality = qlty, other = 'E' ))

    # ~ Descargas
    bloque = scrapertools.find_single_match(data, '<div class="contEP contepID_3">(.*?)$')

    matches = re.compile('data-quality="(.*?)" data-lang="(.*?)".*?href="(.*?)".*?<span>.*?">(.*?)</b>', re.DOTALL).findall(bloque)

    for qlty, lang, url, server in matches:
        ses += 1

        if not url or not server: continue

        if lang.lower() == 'espsub':
            lang = 'Vose'

        lang = lang.capitalize()
        server = servertools.corregir_servidor(server)

        itemlist.append(Item( channel = item.channel, action = 'play', server = server, title = '', url = url, language = lang, quality = qlty, other = 'D' ))


    if not itemlist:
        if not ses == 0:
            platformtools.dialog_notification(config.__addon_name, '[COLOR tan][B]Sin enlaces Soportados[/B][/COLOR]')
            return

    return itemlist


def play(item):
    logger.info()
    itemlist = []

    url_play = ''

    if item.id:
        post = {'_method': 'getPlayer', 'id':item.id}
        data = do_downloadpage(host + 'ajax.php', post=post)

        url = scrapertools.find_single_match(data, r"src='([^']+)")
        url = url.replace('\\/', '/')

        if url:
            data = do_downloadpage(url)
            url_play = scrapertools.find_single_match(data, r"src='([^']+)")
    else:
        url_play = item.url

    if url_play:
        itemlist.append(item.clone(url = url_play.replace("\\/", "/")))

    return itemlist


def search(item, texto):
    logger.info()
    try:
        item.url = host + 'search/?s=' + texto.replace(" ", "+")
        return list_all(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []

