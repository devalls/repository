"""
    Plugin for executing programs
"""

import sys

# plugin constants
__plugin__ = "Simply Launcher for Kodi"
__author__ = "Tocinillo"
__version__ = "1.0.0"

if __name__ == "__main__":
    import resources.lib.simplylauncher as plugin
    plugin.Main()

sys.modules.clear()
