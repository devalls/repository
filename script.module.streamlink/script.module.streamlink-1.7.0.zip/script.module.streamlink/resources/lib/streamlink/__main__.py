if __name__ == "__main__":
    from streamlink_cli.main import main
    main()
