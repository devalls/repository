[batocera-themes](https://github.com/batocera-linux/batocera-themes)

The batocera emulationstation themes!
Credits

    Genetik57
    Fery65
    nadenislamarre
    jdorigao
    tcamargo

Special thanks to (For some resources) :

    Retropie (Community) -> https://github.com/RetroPie
    Recalbox (Community) -> https://gitlab.com/recalbox
